#!/usr/bin/env python

import numpy as np
from asd.utility.plot_tools_3d import *


def test_arrow3d():
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    arrow3d(ax)
    arrow3d(ax, length=2, width=0.02, head=0.1, headwidth=1.5, offset=[1,1,0],
            theta_x=40,  color="crimson")
    arrow3d(ax, length=1.4, width=0.03, head=0.15, headwidth=1.8, offset=[1,0.1,0],
            theta_x=-60, theta_z = 60,  color="limegreen")
    ax.set_xlim(0,1)
    ax.set_ylim(0,1)
    ax.set_zlim(0,1)
    ax.set_axis_off()
    plt.show()


def test_spiral():
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    kwargs = dict(length=0.5, width=0.02, head=0.1, headwidth=2, theta_z = 0)
    for i in range(10):
        kwargs.update(offset=[i,0,0],
        theta_x=i*360/10., 
        color=plt.cm.rainbow(i/10.))
        arrow3d(ax, **kwargs)
    ax.quiver(0,0,0,1,0,0,length=10,arrow_length_ratio=0.05)
    ax.set_xlim(0,10)
    ax.set_ylim(-1,1)
    ax.set_zlim(-1,1)
    ax.set_axis_off()
    plt.show()



def plot_diamond_cell(a=1.):
    diamond_conv = np.eye(3)
    diamond_prim = np.array([
    [1,0,1],
    [0,1,1],
    [1,1,0]])*a/2
    atoms = np.array([
    [0,0,0],
    [0,1/2,1/2],
    [1/2,1/2,0],
    [1/2,0,1/2],
    [1/4,1/4,1/4],
    [3/4,3/4,1/4],
    [1/4,3/4,3/4],
    [3/4,1/4,3/4]
    ])*a
    atoms_cart = np.dot(atoms,diamond_conv)

    fig = plot_parallelepiped(diamond_conv,vert_size=1,show=True)

latt = np.array([
[1,0,0],
[1,2,0],
[0,1,1]])

if __name__=='__main__':
    #test_spiral()
    #test_arrow3d()
    #plot_parallelepiped(latt)
    plot_diamond_cell(a=1)
