#!/usr/bin/env python

# this script is still under test

import numpy as np
import asd.mpi.mpi_tools as mt
from asd.core.log_general import *
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *
from asd.data_base.exchange_for_kagome import *


nx=6
ny=6
nz=1
lat_type='kagome'
latt,sites = build_latt(lat_type,nx,ny,nz,return_neigh=False)
nat=sites.shape[-2]

alpha=0.001
temp=0.1
dt=1e-2

log_handle=log_general(
n_log_conf=50,
n_log_magn=50)

nstep=10000


if __name__=='__main__':
    ham = build_ham(Bfield=np.zeros(3))

    sp_lat = np.zeros((nx,ny,nat,3))
    comm,size,rank,node = mt.get_mpi_handles()
    #if not rank: sp_lat = init_random(sp_lat)
    #sp_lat = comm.bcast(sp_lat)
    sp_lat[...,2] = 1.

    LLG = llg_solver(alpha=alpha,dt=dt,nstep=nstep,S_values=S_values,
    temperature=temp,lat_type=lat_type,
    conv_ener=1e-10,
    log_handle=log_handle)

    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat,verbosity=2)
