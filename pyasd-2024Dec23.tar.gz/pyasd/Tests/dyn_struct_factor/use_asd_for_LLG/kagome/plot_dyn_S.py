#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from asd.utility.Swq import *
from asd.utility.spin_visualize_tools import *
from llg import *
import pickle


def bandmap(dynS,bound=2,max_omega=2):
    xx,yy = np.mgrid[-2:2:100j,0:max_omega:100j]
    fig,ax=plt.subplots(1,1)
    kwargs = dict(cmap='hot')
    #im = ax.scatter(xx,yy,c=dynS.real,cmap='hot')
    kwargs.update(origin='lower',extent=[-bound,bound,0,max_omega],aspect='auto')
    im = ax.imshow(dynS.T.real,**kwargs)
    ax.set_xlabel('$q_x$')
    ax.set_ylabel('$S\ (\mathbf{q},\omega)\ /\ THz$')
    fig.colorbar(im,shrink=0.6)
    fig.tight_layout()
    fig.savefig('dyn_struct_factor',dpi=400)
    plt.show()


def qmap(dynS,nqx,nqy,omegas,target_omega=2,bound=2):
    dynS = dynS.reshape(nqx,nqy,nomega)
    xx,yy = np.mgrid[-2:2:100j,0:max_omega:100j]
    fig,ax=plt.subplots(1,1)
    kwargs = dict(cmap='hot',
    vmin=0,
    vmax=1)
    idx = np.argmin(abs(omegas-target_omega))
    cc = dynS[:,:,idx].real
    im = ax.imshow(cc,extent=[-bound,bound,-bound,bound],cmap='hot')
    fig.colorbar(im)
    ax.set_xlabel('$q_x$')
    ax.set_ylabel('$q_y$')
    fig.tight_layout()
    fig.savefig('S_qmap',dpi=400)
    plt.show()




comm,size,rank,node = mt.get_mpi_handles()
sites_cart = np.dot(sites,latt).reshape(-1,2)

nqx=21
nqy=21
bound=1

# for band map
qpt_cart = np.zeros((nqx,bound))
qpt_cart[:,0] = np.linspace(-bound,bound,nqx)

# for q-map
qpt_cart = gen_uniform_qmesh(nqx,nqy,bound)


max_omega=2
nomega=200
omegas = np.linspace(0,max_omega,nomega)


restart=False
time_step=dt*n_log_conf

if restart==False:
    confs = parse_ovf('spin_confs.ovf')[1]
    nconf = confs.shape[0]
    S_vectors, dynS = calc_dyn_structure_factor(confs,sites_cart,qpt_cart,dt=time_step,omegas=omegas)


if rank==0:
    nconf = len(S_vectors)
    times = np.arange(nconf)-nconf//2
    times = np.array(times,float) * time_step

    S_vectors = pickle.load(open('S_vectors.pickle','rb'))
    animate_S_vectors(S_vectors,times,nqx,nqy,comp='parallel')

    dynS = pickle.load(open('dyn_S.pickle','rb'))
    #bandmap(dynS,bound=2,max_omega=2)
    #qmap(dynS,nqx,nqy,omegas,3,2)
