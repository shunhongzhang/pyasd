#!/usr/bin/env python

# this script is still under test

import numpy as np
import asd.mpi.mpi_tools as mt
from asd.core.log_general import *
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *


nx=24
ny=24
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]

alpha=0.1
temp=0.01
dt=1e-2

log_handle=log_general(
n_log_conf=500,
n_log_magn=500)

nstep=20000

J1=1
J2=0
SIA=0.1
S_values=np.ones(1)
SIAs=np.array([SIA])
J1_iso = np.array([J1])
J2_iso = np.array([J2])
exch_1 = exchange_shell( neigh_idx[0], J1_iso, shell_name='1NN')
exch_2 = exchange_shell( neigh_idx[0], J2_iso, shell_name='2NN')


ham = spin_hamiltonian(S_values=S_values,
BL_SIA=[SIAs],
BL_exch=[exch_1],
iso_only=True)

if __name__=='__main__':
    sp_lat = np.zeros((nx,ny,nat,3))
    comm,size,rank,node = mt.get_mpi_handles()
    sp_lat[...,2] = 1.

    # thermalize with large damping
    kwargs = dict(alpha=alpha,dt=dt,nstep=nstep,
    S_values=S_values,
    temperature=temp,
    lat_type=lat_type,
    conv_ener=1e-12,
    log_handle=log_handle)

    LLG = llg_solver(**kwargs)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat,verbosity=2)

    # sampling with smaller damping
    kwargs.update(alpha=0.01,
    n_log_conf=100,n_log_magn=100,
    conv_ener=1e-12)

    LLG = llg_solver(**kwargs)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat,verbosity=2)
