#!/usr/bin/env python

# this script is still under test

import numpy as np
import asd.mpi.mpi_tools as mt
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *

nx=24
ny=1
nz=1
lat_type='chain'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]

J1 = 1
J2 = 0
SIA = 0.1
S_values=np.array([1/2])
J1_iso = np.array([J1])
Bfield=np.array([0,0,0])

temp=0.1
alpha=0.001
dt=1e-2
n_log_conf=100
n_log_magn=100
nstep=50000

exch_1 = exchange_shell( neigh_idx[0], J1_iso, shell_name = '1NN')


if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()

    ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,
    BL_SIA=[np.array([SIA])],
    BL_exch=[exch_1],iso_only=True,
    boundary_condition=[1,0,0])

    kwargs = dict(
    alpha=alpha,dt=dt,nstep=nstep,
    lat_type=lat_type,
    n_log_conf=n_log_conf,
    n_log_magn=n_log_magn,
    conv_ener=1e-12,
    log_topo_chg=False,
    temperature=temp,
    thermal_field_method=2,
    )

    sp_lat = np.zeros((nx,ny,nat,3))
    sp_lat[...,2] = 1.

    LLG = llg_solver(**kwargs)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat,verbosity=2)
