#!/usr/bin/env python

# this script is still under test

import numpy as np
import asd.mpi.mpi_tools as mt
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *

nx=2
ny=1
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]

S_values=np.array([1])
SIA=np.array([0])
J1_iso = np.array([0.1])
Bfield=np.array([0,0,0])

alpha=0.001
temp=0
dt=1e-2
n_log_conf=100
n_log_magn=100
nstep=15000

exch_1 = exchange_shell( neigh_idx[0][:,::2], J1_iso, shell_name = '1NN')

# initail tilt angle
theta = np.deg2rad(2)


if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()

    ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_SIA=[SIA],
    BL_exch=[exch_1],iso_only=True,
    boundary_condition=[1,0,0])

    kwargs = dict(
    alpha=alpha,dt=dt,nstep=nstep,
    temperature=temp,
    lat_type=lat_type,
    n_log_conf=n_log_conf,
    n_log_magn=n_log_magn,
    conv_ener=1e-12,
    log_topo_chg=False)

    for nx in range(1,3):
        sp_lat = np.zeros((nx,ny,nat,3))
        phis = np.linspace(0,1,nx,endpoint=False) *2*np.pi
        sp_lat[:,0,0,0] = np.sin(theta)*np.cos(phis)
        sp_lat[:,0,0,1] = np.sin(theta)*np.sin(phis)
        sp_lat[:,0,0,2] = np.cos(theta)

        kwargs.update(prefix='nx_{}'.format(nx))
        LLG = llg_solver(**kwargs)

        log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat,verbosity=2)
