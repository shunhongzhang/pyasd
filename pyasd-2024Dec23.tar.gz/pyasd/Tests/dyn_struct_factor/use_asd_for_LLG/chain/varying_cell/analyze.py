#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import *
from asd.utility.Swq import *
from asd.core.geometry import build_latt
from llg import nx,ny,nat
import matplotlib.pyplot as plt


PlanckConstant = 4.13566733e-15  # [eV s]
Hbar = PlanckConstant/(2*np.pi)  # [eV s]


def get_freq(nx):
    fil_ovf = 'nx_{}_spin_confs.ovf'.format(nx)
    prefix='nx_{}'.format(nx)
    spins = parse_ovf(fil_ovf)[1]
    nconf = spins.shape[0]
    sp_lat = np.swapaxes(spins.reshape(nconf,ny,nx,nat,3),1,2)
    times = np.loadtxt('{}_M.dat'.format(prefix))[:,0]
    angles = np.angle(sp_lat[:,0,0,0,0] + 1.j*sp_lat[:,0,0,0,1])
    dd = abs(angles[1:] - angles[:-1])
    idx = np.argmax(dd)
    freq = 1./times[idx]
    return idx,freq


def plot_spectra(nx_range=np.arange(2,10)):
    freqs = np.array([get_freq(nx)[1] for nx in nx_range]) # in THz
    magnon_energy = freqs*Hbar*1e12*1e3  # hbar*omega(k), in meV
    xx = 1./nx_range

    xx0 = np.linspace(0,0.5,100)
    analytic_magnon = 4*0.1*(1-np.cos(2*np.pi*xx0))/(2*np.pi)  # in meV
    analytic_freqs = analytic_magnon*1e-3/(Hbar*1e12)  # in THz

    fig,ax=plt.subplots(1,1)
    ax.plot(xx,magnon_energy,'o',label='LLG')
    ax.plot(xx0,analytic_magnon,label='anlytic')
    tax = ax.twinx()
    tax.plot(xx,freqs,'o',label='LLG')
    tax.plot(xx0,analytic_freqs,label='analytic')
    ax.legend()
    ax.set_xlabel('q')
    ax.set_ylabel('$\hbar\omega\ (q)\ \\mathrm{(meV)}$')
    tax.set_ylabel('$\omega\ (q)\ \mathrm{(THz)}$')
    fig.tight_layout()
    plt.show()


def analyze_corr_func(nx):
    fil_ovf = 'nx_{}_spin_confs.ovf'.format(nx)
    spins = parse_ovf(fil_ovf)[1]
    nconf = spins.shape[0]
    sp_lat = np.swapaxes(spins.reshape(nconf,ny,nx,nat,3),1,2)

    idx,freq = get_freq(nx)
    confs = np.array([sp_lat])

    confs_t = confs[:,idx]
    confs_0 = confs[:,0]
    ave_confs_0 = np.average(confs_0,axis=0)
    corr = calc_correlation_function(confs_t,confs_0,cutoff_x=nx,cutoff_y=0)
    idir = 1
    fig,ax=plt.subplots(1,1)
    ax.plot(np.arange(-nx,nx+1),corr[:,0,idir],'o-')
    ax.set_xticks(np.arange(-nx,nx+1,3))
    plt.show()



if __name__=='__main__':
    #plot_spectra()
    #analyze_corr_func(6)

    timestep = 1 # time spacing for Fourier transformation
    nomega = 401
    omegas = np.linspace(0,0.2,nomega)

    for nx in range(1,10):
        fil_ovf = 'nx_{}_spin_confs.ovf'.format(nx)
        print ('processing {}'.format(fil_ovf))
        spins = parse_ovf(fil_ovf)[1]
        nconf = spins.shape[0]
        sp_lat = np.swapaxes(spins.reshape(nconf,ny,nx,nat,3),1,2)
        confs = np.array([sp_lat])
        latt, sites = build_latt('square',nx,1,1,return_neigh=False)
        sites_cart = np.dot(sites,latt)
        qpts_cart = np.zeros((nx,2))
        qpts_cart[:,0] = np.arange(1,nx+1)/nx
        kwargs = dict(cutoff_x=9,cutoff_y=0,pickle_name='Swq_{}.pickle'.format(nx),verbosity=0)
        #Swq = calc_dyn_structure_factor(confs,sites_cart,qpts_cart,timestep,omegas,**kwargs)

    Swq = np.zeros((8,nomega,3),complex)
    for ix in range(2,10):
        Swq0 = pickle.load(open('Swq_{}.pickle'.format(ix),'rb'))
        Swq[ix-2] = Swq0[-2]

    nx=8
    qpts_cart = np.zeros((nx,2))
    qpts_cart[:,0] = np.arange(1,nx+1)/nx
    Swq = pickle.load(open('Swq_{}.pickle'.format(nx),'rb'))

    idir=0
    nq = len(qpts_cart)
    q_dists = np.tile(qpts_cart[:,0],(nomega,1)).T
    extent = [1./nx-0.5/nx,1+0.5/nx,np.min(omegas),np.max(omegas)]
    fig,ax=plt.subplots(1,1,figsize=(6,6))
    griddata = Swq[:,:,idir].T.real
    im = ax.imshow(griddata,extent=extent,origin='lower',aspect='auto')
    omega_grid = np.tile(omegas,(nq,1))
    #im = ax.scatter(q_dists,omega_grid,c=Swq[:,:,1].real,cmap='viridis',s=5)
    cbar = fig.colorbar(im,shrink=0.6)
    ax.set_xlabel('q')
    ax.set_ylabel('$\omega\ \mathrm{(THz)}$')
    ax.set_xticks(qpts_cart[:,0])
    ax.set_xticklabels(['{}/{}'.format(ii+1,nx) for ii in range(nx)])
    fig.tight_layout()
    plt.show()
