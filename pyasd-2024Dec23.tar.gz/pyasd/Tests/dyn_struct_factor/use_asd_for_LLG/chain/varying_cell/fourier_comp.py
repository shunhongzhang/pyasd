#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
    
timestep = 1 # time spacing for Fourier transformation
nomega = 101
omegas = np.linspace(0,2/timestep,nomega)
times  = np.linspace(-100,100,401)*timestep


if __name__=='__main__':
    omegas_grid,times_grid = np.meshgrid(omegas,times)
    time_phases = np.exp(2*1.j*np.pi * np.einsum('w,t->wt',omegas,times) )
    extent = [np.min(omegas),np.max(omegas),np.min(times),np.max(times)]
    data = time_phases.real.T
    fig,ax=plt.subplots(1,1)
    im = ax.imshow(data,origin='lower',extent=extent,aspect='auto')
    #im = ax.scatter(omegas_grid,times_grid,c=data,s=1)
    cbar = fig.colorbar(im,shrink=0.6)
    ax.set_xlim(np.min(omegas),np.max(omegas))
    ax.set_ylim(np.min(times),np.max(times))
    ax.set_xlabel('$\omega\ (ps)$')
    ax.set_ylabel('t (THz)')
    fig.tight_layout()
    plt.show()
