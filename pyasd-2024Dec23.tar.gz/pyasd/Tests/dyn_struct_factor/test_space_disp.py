#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from asd.core.geometry import *

def test_space_disp(latt,sites,space_disp,ii=3,jj=6,iat=0,jat=1):
    sites_cart = np.dot(sites,latt)
    title = 'site {} -> site {} + [{},{}]'.format(iat,jat,ii-cutoff_x,jj-cutoff_y)
    fig,ax = plt.subplots(1,1)
    ax.set_title(title)
    scat = [ax.scatter(sites_cart[:,:,i,0],sites_cart[:,:,i,1],label=str(i)) for i in range(nat)]
    ax.legend(handles=scat)
    quiver_kws = dict(units='x',pivot='tail',scale=1.05,width=0.02,headwidth=4,headlength=5)
    for ix,iy in np.ndindex(nx,ny):
        points = np.array([[0,0],[1,0],[1,1],[0,1],[0,0]]) + np.array([ix,iy])
        points = np.dot(points,latt)
        ax.plot(*tuple(points.T),ls='--',alpha=0.5,c='g',zorder=-1)
        disp = space_disp[ii,jj,iat,jat]
        ax.quiver(*tuple(sites_cart[ix,iy,iat]),*tuple(disp),**quiver_kws)
    ax.set_aspect('equal')
    ax.set_axis_off()
    fig.tight_layout()
    plt.show()


def test_space_phases(qpt_cart,space_disp):
    space_phases = np.exp(2.j*np.pi * np.einsum('qi,xyabi-> qxyab',qpt_cart, space_disp) )
    data = space_phases[0,:,:,0,1].real
    fig,ax = plt.subplots(1,1)
    im = ax.imshow(data.T,origin='lower',aspect='equal')
    fig.colorbar(im,shrink=0.6)
    ax.set_axis_off()
    plt.show()


qpt_cart = np.array([[0.1,0.1]])


cutoff_x = 4
cutoff_y = 4
nx=6
ny=6
lat_type='honeycomb'
#lat_type='square'
#lat_type='triangular'
latt,sites = build_latt(lat_type,nx,ny,1,return_neigh=False)
nat,ndim = sites.shape[-2:]

if __name__=='__main__':
    space_disp = calc_space_disp(latt,sites,cutoff_x,cutoff_y)
    test_space_disp(latt,sites,space_disp,ii=4,jj=6,iat=0,jat=1)
    ##test_space_phases(qpt_cart,space_disp)
