#!/usr/bin/env python

#===============================================
#
# Simulate the exchange bias effect
# Shunhong Zhang <szhang2@ustc.edu.cn>
# Dec 27 2021
#
#================================================

from spirit import io,log,state,geometry,system,hamiltonian,simulation,parameters,configuration,chain
import os

# in the convention of Spirit code
# negative for AFM, positive for FM
J1 = 1
J2 = 0.5

# for Single-ion anisotropy (SIA)
# negative (positive) favors in-plane (out-of-plane)
SIA = 0.1

temp=0.1
tag = 'T_{:.2f}'.format(temp)

nx=20
ny=20
nimage=1
n_iteration=60000
n_log_iteration=100
fil_cfg = '../input.cfg'

if __name__=='__main__':
    os.system('rm T* Log* 2>/dev/null')
    with state.State(fil_cfg) as p_state:
        geometry.set_n_cells(p_state,[nx,ny,1],idx_image=-1)
        geometry.set_mu_s(p_state, 1, idx_image=-1)
        hamiltonian.set_boundary_conditions(p_state,[1,0,0],idx_image=-1)
        hamiltonian.set_exchange(p_state, 2, [J1,J2], idx_image=-1)
        hamiltonian.set_anisotropy(p_state, SIA, [0,0,1], idx_image=-1)
        configuration.plus_z(p_state,idx_image=-1)
        parameters.llg.set_output_tag(p_state, tag, idx_image=-1)
        parameters.llg.set_output_folder(p_state, '.', idx_image=-1)
        parameters.llg.set_iterations(p_state, n_iteration, n_log_iteration, idx_image=-1)
        parameters.llg.set_output_configuration(p_state, 0, 1, 3, idx_image=-1)
        parameters.llg.set_output_energy(p_state, 0, 1, idx_image=-1)
        parameters.llg.set_output_general(p_state, 1, 0, 0, idx_image=-1)
        parameters.llg.set_temperature(p_state, temp, idx_image=-1)
        parameters.llg.set_damping(p_state, 0.001, idx_image=-1)
        parameters.llg.set_timestep(p_state, 0.001, idx_image=-1)
        system.update_data(p_state, idx_image=-1)
        simulation.start(p_state, simulation.METHOD_LLG, simulation.SOLVER_DEPONDT, idx_image=-1)
