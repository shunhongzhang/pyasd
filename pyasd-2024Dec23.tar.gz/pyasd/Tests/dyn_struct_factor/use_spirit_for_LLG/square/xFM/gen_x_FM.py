#!/usr/bin/env python

import numpy as np
from asd.core.geometry import build_latt
from asd.utility.spin_visualize_tools import *


nx=20
ny=20
nz=1
latt,sites = build_latt('chain',nx,ny,nz,return_neigh=False)
nat=sites.shape[-2]
sp_lat=np.zeros((nx,ny,nat,3))
sp_lat[...,0]=1
params = gen_params_for_ovf(nx,ny,nz)
spins = np.swapaxes(sp_lat,0,1).reshape(-1,3)
write_ovf(params,spins,'xFM_conf.ovf')

superlatt = np.dot([[nx,0],[0,ny]],latt)
sites_cart=np.dot(sites,latt)
quiver_kws.update(scale=1.2,width=0.1)
kwargs=dict(show=True,colorbar_orientation='vertical',quiver_kws=quiver_kws,
superlatt=superlatt,colorbar_shrink=0.4,scatter_size=15,colorful_quiver=True)
plot_spin_2d(sites_cart,sp_lat,**kwargs)
