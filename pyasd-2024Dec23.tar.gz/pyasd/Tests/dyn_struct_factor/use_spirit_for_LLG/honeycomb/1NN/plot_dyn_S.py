#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from asd.core.geometry import *
from asd.utility.Swq import *
from asd.utility.spin_visualize_tools import *
import pickle
import asd.mpi.mpi_tools as mt
from llg import nx,ny,J1,J2,SIA


def main(time_spacing=0.1,lat_type='square',nq=200,nomega=400,
    prefix='Ensemble',fil_key='Spins-archive.ovf',
    cutoff_x=5,cutoff_y=5,start_conf=0,restart=True):

    latt,sites = build_latt(lat_type,1,1,1,return_neigh=False)
    nat=sites.shape[-2]
    rcell = np.linalg.inv(latt).T  # in 2pi
    q_path,labels=get_qpath_2D_latt(lat_type)
    qpt_cart,q_dists,q_nodes = gen_qpts_from_path(q_path,rcell,nq)
    analytic_spectra = analytic_spin_wave_FM(lat_type,qpt_cart,J1,J2,SIA)
    max_omega = np.max(analytic_spectra)*1.1

    if not restart:
        omegas = np.linspace(0,max_omega,nomega)
        confs = mpi_get_confs_t(nx,ny,nat,prefix,fil_key,start_conf=start_conf)
        kwargs = dict(time_spacing=time_spacing,omegas=omegas,
        cutoff_x=cutoff_x,cutoff_y=cutoff_y,verbosity=2)
        if lat_type=='chain': kwargs.update(cutoff_y=0,cutoff_x=10)
        dynS = calc_dyn_structure_factor(confs,latt,sites,qpt_cart,**kwargs)

    if rank==0:
        if J2==0: output='{}_1NN'.format(lat_type)
        else: output='{}_2NN'.format(lat_type)
        Swq = pickle.load(open('Swq.pickle','rb'))
        fig,ax = bandmap(Swq,q_dists,q_nodes,labels,max_omega,'xy',True,analytic_spectra,output)


comm,size,rank,node = mt.get_mpi_handles()

params = dict(
time_spacing=0.1,   # time spacing for configurations, in ps
#lat_type='chain',
#lat_type='square',
lat_type='honeycomb',
#lat_type='triangular',
start_conf=500,
cutoff_x=3,
cutoff_y=3,
prefix='Ensemble',
#fil_key='spin_confs.ovf',
fil_key='*Spins-archive.ovf',
restart=False,
)

if __name__=='__main__':
    main(**params)
