#!/usr/bin/env python

# note: we found that changing images and llg_seed
# cannot generate true randomness in the finite-temperature simulations
# we therefore add a small change to the temperature
# this help generate different samples for ensemble average

import numpy as np
import os

n_ensemble=4

for i in range(n_ensemble):
    idir = 'Ensemble_{}'.format(i)
    os.mkdir(idir)
    os.system('cp input.cfg llg.py {}'.format(idir))
    os.chdir(idir)
    #os.system('sed -i "s/nimage=1/nimage={}/g" llg.py'.format(i+1))
    #os.system('sed -i  "s/llg_seed                20006/llg_seed {}/g" input.cfg'.format(np.random.randint(50000)))
    temp_line = os.popen('grep temp= llg.py').readline().rstrip('\n')
    os.system('sed -i "s/{}/temp={:5.3f}/g" llg.py'.format(temp_line,0.1+i/1000))
    os.system('python llg.py > out&')
    os.chdir('..')
