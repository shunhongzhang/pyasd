#!/usr/bin/env python

import numpy as np
import os

n_ensemble=4

for i in range(n_ensemble):
    idir = 'Ensemble_{}'.format(i)
    os.mkdir(idir)
    os.system('cp input.cfg llg.py {}'.format(idir))
    os.chdir(idir)
    os.system('sed -i "s/temp=0.1/temp={:5.3f}/g" llg.py'.format(0.1+i/1000))
    os.system('python llg.py > out&')
    os.chdir('..')
