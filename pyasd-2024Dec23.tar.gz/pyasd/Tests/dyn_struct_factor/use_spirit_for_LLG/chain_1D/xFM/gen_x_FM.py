#!/usr/bin/env python

import numpy as np
from asd.core.geometry import build_latt
from asd.utility.spin_visualize_tools import *


nx=40
ny=1
nz=1
latt,sites = build_latt('chain',nx,ny,nz,return_neigh=False)
nat=sites.shape[-2]
sp_lat=np.zeros((nx,ny,nat,3))
sp_lat[...,0]=1
params = gen_params_for_ovf(nx,ny,nz)
spins = np.swapaxes(sp_lat,0,1).reshape(-1,3)
write_ovf(params,spins,'xFM_conf.ovf')

sites_cart=np.dot(sites,latt)
kwargs=dict(show=True,colorbar_orientation='horizontal',latt=latt,colorbar_shrink=0.6,scatter_size=30)
#plot_spin_2d(sites_cart,sp_lat,**kwargs)
