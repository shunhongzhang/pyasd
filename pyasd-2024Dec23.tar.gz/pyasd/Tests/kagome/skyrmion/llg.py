#!/usr/bin/env python3

import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.data_base.exchange_for_kagome import *
from asd.core.spin_configurations import *
from asd.core.topological_charge import get_tri_simplices
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt

nx=8
ny=8

latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat = sites.shape[2]
sites_cart = np.dot(sites,latt)


log_handle = log_general(
n_log_conf=200,
n_log_magn=200,
log_topo_chg=True,
tri_simplices = get_tri_simplices(sites_cart),
outdir='kagome_SKX',
)

llg_kws = dict(dt=1e-3,
nstep=5000,
S_values=S_values,
temperature=0.01,
lat_type=lat_type,
conv_ener=1e-9,
log_handle=log_handle,
start_conf='as_input')

ham = spin_hamiltonian(
S_values=S_values,BL_SIA=[SIA],
BL_exch=[exch_1],
exchange_in_matrix=True)


if __name__=='__main__':
    sp_lat = np.zeros((nx,ny,nat,3),float)
    sp_lat = init_spin_latt_skyrmion(sp_lat,latt,sites,3)
    LLG = llg_solver(**llg_kws)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
