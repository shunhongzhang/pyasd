# some scripts for fast test of the code

four_state_method: some examples showing how to extract exchanges by four-state method (DFT)
OVF: test ovf library
mpi: test some MPI-enabled parallelization tools
3d_plog: some 3D plotting functions


mag_conf: test generation of specific chiral magnetic structures
total_energy: test total energy calculations for specific configuration, benchmark to Spirit
LLG: test LLG simulations on spin lattice, using the llg_solver class
advanced_LLG: LLG simulations with advanced setup, using the llg_solver_adv class
damping_only: damping-only LLG simulation, as an energy minimizer
Monte_Carlo: monte carlo simulations for sampling the energy surface, including PTMC
gneb: Geodesic Nudged elastic band method for estimating the energy barrier of spin systems
spin_correlations: spin-spin correlations
dyn_struct_factor: dynamic structure factor, related to magnons
