#!/usr/bin/env python

import numpy as np
import ovf
import matplotlib.pyplot as plt
from asd.core.constants import kB
from asd.utility.mag_thermal import logarithmic_magnetization
from scipy.optimize import curve_fit
from mc import *


def plot_MC_results(temp_list,ens,mms,start_conf,guss_Tc_beta=(10,0.3)):
    enes = np.average(ens[:,start_conf:],axis=1)
    C_v = (np.average(ens[:,start_conf:]**2) - enes**2)/(temp_list**2)
    mags = np.average(mms[:,start_conf:],axis=1)
    popt,pcov = curve_fit(logarithmic_magnetization,temp_list,mags,guess_Tc_beta)
    print ('Estimated Tc = {:.3f}'.format(popt[0]))
    xx = np.linspace(0,np.max(temp_list),501)
    yy = logarithmic_magnetization(xx,*tuple(popt))
    y1 = logarithmic_magnetization(xx,popt[0],np.pi**2*3/128)
    label = '$M=M(0)(1-T/T_C)^\\beta,\ \\beta={:.3f}$'.format(popt[1])

    Tc_analytic = 0.8816*J1/kB
    E_analytic = -2 + kB*temp_list/J1/2

    fig,ax=plt.subplots(2,1,sharex=True,figsize=(6,7))
    ax[0].axvline(Tc_analytic,ls='--',c='C6',alpha=0.5,zorder=-1,label='$0.8816J/k_B$')
 
    ax[1].plot(temp_list,enes,'C1o')
    ax[1].plot(temp_list,E_analytic,'C6-')
    ax[0].plot(temp_list,mags,'C2o')
    ax[0].plot(xx,yy,'C3-',label=label)
    ax[0].plot(xx,y1,'C4--',label='analytic, $\\beta={:.3f}$'.format(np.pi**2*3/128))
    ax[0].legend()
    ax[0].set_yticks([0,0.5,1])
    ax[1].set_yticks([-2,-1,0])
    ax[0].set_ylabel('M/Ms')
    ax[1].set_ylabel('E (meV/site)')
    ax[1].set_xlabel('T (K)')
    tax = ax[1].twinx()
    tax.plot(temp_list,C_v,'C4o-')
    fig.tight_layout()
    plt.show()


def get_MC_Data(temp_list):
    ens=[]
    mgs = []
    for temperature in temp_list:
        mfile = '{}/T_{:.1f}_M.dat'.format(outdir,temperature)
        if not os.path.isfile(mfile): continue
        data = np.loadtxt(mfile,skiprows=3)
        ens.append(data[:,1])
        mgs.append(data[:,2:])

    ens = np.array(ens)
    mgs = np.array(mgs)
    mms = np.linalg.norm(mgs,axis=2)
    return ens,mgs,mms


def display_snapshot(sites_cart,kws,T=1,status='final'):
    from asd.utility.spin_visualize_tools import plot_spin_2d
    fil_ovf = '{}/T_{:.1f}_{}_spin_confs.ovf'.format(outdir,T,status)
    with ovf.ovf_file(fil_ovf) as ovf_file:
        segment = ovf.ovf_segment()
        ovf_file.read_segment_header(0,segment)
        data = np.zeros((segment.N,segment.valuedim))
        sp_lat = np.zeros((nx,ny,nat,segment.valuedim),dtype=np.dtype('f'))
        ovf_file.read_segment_data(0,segment,data)
        ovf_file.read_segment_data(0,segment,sp_lat)
        np.testing.assert_allclose(data,sp_lat.reshape(-1,segment.valuedim))
    kws.update(title='T = {:.2f}, {}'.format(T,status),figname='T_{:.2f}_{}_MC.png'.format(T,status))
    plot_spin_2d(sites_cart,sp_lat,**kws)



sites_cart = np.dot(sites,latt)
kws = dict(
superlatt = np.dot(np.diag([nx,ny]),latt),
scatter_size=30,
colorbar_shrink=0.5,
colorbar_orientation='vertical',
color_mapping='phi_full',
show=True,
save=True)

outdir='Potts_MC'
start_conf = 20
guess_Tc_beta=(12,0.3)

 
if __name__=='__main__':
    ens,mgs,mms = get_MC_Data(temp_list)
    #plot_MC_results(temp_list[:len(ens)],ens,mms,start_conf,guess_Tc_beta)
    display_snapshot(sites_cart,kws,T=1,status='initial')
