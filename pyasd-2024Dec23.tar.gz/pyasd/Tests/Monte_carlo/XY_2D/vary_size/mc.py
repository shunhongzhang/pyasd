#!/usr/bin/env python3

import os
import numpy as np
from asd.core.log_general import log_general
from asd.core.hamiltonian import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import exchange_shell
from asd.core.spin_configurations import *
from asd.core.monte_carlo import *
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt


class XY_exchange_shell():
    def __init__(self,neigh_idx,J,shell_name='XY_shell'):
        self._neigh_idx = neigh_idx
        self._J = J
        self._shell_name = shell_name


    def calc_shell_exch_energy(self,sp_lat,boundary_condition=[1,1],parallel=False):
        from asd.core.shell_exchange import get_latt_idx
        shape = sp_lat.shape
        nx,ny,nz,nat,idx = get_latt_idx(shape)
        assert nz==1, 'XY shell exchange requires nz==1! Now: nz = {}'.format(nz)
        ntask = len(idx)
        start,last = (0,ntask)
        if parallel and enable_mpi: start,last = mt.assign_task(ntask,size,rank)
        E_exch = 0.
        for idx0 in idx[start:last]:
            iat = idx0[-1]
            n_i = sp_lat[tuple(idx0)]
            for j,idx_n in enumerate(self._neigh_idx[iat]):
                idx1 = calc_neigh_bond_idx(idx0,idx_n,shape,boundary_condition)
                if idx1 is not None:
                    n_j = sp_lat[tuple(idx1)]
                    E_exch -= np.dot(np.dot(n_i,self._J[iat,j]),n_j)
        if parallel: E_exch = comm.allreduce(E_exch)
        return E_exch/2


    def calc_local_exchange_energy(self,sp_lat,site_idx,boundary_condition=[1,1,1]):
        shape=sp_lat.shape
        E_local = 0.
        iat = site_idx[-1]
        n_i = sp_lat[tuple(site_idx)]
        for j,idx_n in enumerate(self._neigh_idx[iat]):
            idx1 = calc_neigh_bond_idx(site_idx,idx_n,shape,boundary_condition)
            if idx1 is None: continue
            n_j = sp_lat[tuple(idx1)]
            if self._J is not None: E_local -= np.dot(np.dot(n_i,self._J[iat,j]),n_j)
            else: E_local -= self._J_iso[iat]*np.dot(n_i,n_j)
        return E_local
 
nx=24
ny=24
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]
Bfield=np.array([0,0,0])


J1 = 1.
J_XY = np.tile(np.eye(2),(1,4,1,1)) * J1
S_values = np.ones(1)
exch_1 = XY_exchange_shell(neigh_idx[0], J_XY, shell_name='1NN')



log_handle = log_general(
n_log_conf=500,
n_log_magn=100,
log_conf=False,
outdir='XY_MC',
)

kwargs = dict(
group_x=3,
group_y=3,
group_z=1,
mcs=5000,
start_conf='random',
sample_method='XY',
#start_conf='zFM',
log_handle=log_handle,
verbosity=2,
temperature=3,
)

ham = spin_hamiltonian(
Bfield=np.zeros(2),
S_values=S_values,
general_exch = [exch_1],
iso_only=False,
boundary_condition=[1,1])

MC = MC_controller(**kwargs)

L_list = np.arange(10,50,5,int)

if __name__=='__main__':
    for ii,L in enumerate(L_list):
        sp_lat = np.zeros((L,L,nat,2),float)

        log_handle = log_general(
        n_log_conf=500,
        n_log_magn=100,
        log_conf=True,
        prefix = 'L_{}'.format(L),
        remove_existing_outdir=(ii==0),
        outdir='XY_MC',
        )
        MC.set_log_handle(log_handle)
        MC.run_parallel_monte_carlo(ham,sp_lat)

