#!/usr/bin/env python

import numpy as np
import ovf
import matplotlib.pyplot as plt
from asd.core.constants import kB
from asd.utility.mag_thermal import logarithmic_magnetization
from scipy.optimize import curve_fit
from mc import *


def plot_MC_results(L_list,ens,mms,start_conf):
    enes = np.average(ens[:,start_conf:],axis=1)
    mags = np.average(mms[:,start_conf:],axis=1)
    mags_square = np.average(mms[:,start_conf:]**2,axis=1)
    label_2 = '$N^{-\\frac{k_B T\ /\ J}{4\pi}}$'
    label_1 = '$1-{-\\frac{k_B T\ /\ J}{8\pi}}(lnN+ln2)$'


    fig,ax=plt.subplots(2,1,sharex=True,figsize=(6,7))
    ax[1].plot(L_list,mags_square,'C1o-')
    ax[0].plot(L_list,mags,'C2o')
    ax[0].set_ylabel('$\langle M \\rangle/M_s$')
    ax[1].set_ylabel('$\langle M^2 \\rangle$')
    ax[1].set_xlabel('L')
    ax[1].set_xticks(np.arange(10,40,5))
    xx = np.linspace(10,50,1001)
    y1 = 1 - kB*MC._temperature/J1/(8*np.pi)*(np.log(xx**2)+np.log(2))
    y2 = np.power(xx**2,-kB*MC._temperature/J1/(4*np.pi))
    ax[0].plot(xx,y1,'C5--',label=label_1)
    ax[0].legend(fontsize=16)
    ax[1].plot(xx,y2,'C5--',label=label_2)
    ax[1].legend(fontsize=16)
    fig.tight_layout()
    plt.show()


def get_MC_Data(L_list):
    ens=[]
    mgs = []
    for L in L_list:
        mfile = '{}/L_{}_M.dat'.format(outdir,L)
        if not os.path.isfile(mfile): exit('{} not found!'.format(mfile))
        data = np.loadtxt(mfile,skiprows=3)
        ens.append(data[:,1])
        mgs.append(data[:,2:])

    ens = np.array(ens)
    mgs = np.array(mgs)
    mms = np.linalg.norm(mgs,axis=2)
    return ens,mgs,mms


def display_snapshot(kws,L=35):
    from asd.utility.spin_visualize_tools import plot_spin_2d
    latt,sites = build_latt(lat_type,L,L,1,return_neigh=False)
    sites_cart = np.dot(sites,latt)
    fil_ovf = '{}/L_{}_final_spin_confs.ovf'.format(outdir,L)
    with ovf.ovf_file(fil_ovf) as ovf_file:
        segment = ovf.ovf_segment()
        ovf_file.read_segment_header(0,segment)
        data = np.zeros((segment.N,segment.valuedim))
        sp_lat = np.zeros((L,L,nat,segment.valuedim),dtype=np.dtype('f'))
        ovf_file.read_segment_data(0,segment,data)
        ovf_file.read_segment_data(0,segment,sp_lat)
        np.testing.assert_allclose(data,sp_lat.reshape(-1,segment.valuedim))
    kws.update(title='L = {}'.format(L),figname='L_{}_MC.png'.format(L),superlatt=np.dot(np.diag([L,L]),latt))
    plot_spin_2d(sites_cart,sp_lat,**kws)



kws = dict(
scatter_size=30,
colorbar_shrink=0.5,
colorbar_orientation='vertical',
color_mapping='phi',
show=True,
save=True)

outdir='XY_MC'
start_conf = 35

L_list = L_list[:6]
 
if __name__=='__main__':
    ens,mgs,mms = get_MC_Data(L_list)
    #plot_MC_results(L_list[:len(ens)],ens,mms,start_conf)
    display_snapshot(kws,L=35)
