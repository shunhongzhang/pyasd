#!/usr/bin/env python3

import os
import numpy as np
from asd.core.hamiltonian import *
from asd.data_base.exchange_for_RuCl3 import *
from asd.core.geometry import build_latt
from asd.core.spin_configurations import *
from asd.core.topological_charge import get_tri_simplices
from asd.core.log_general import log_general
from asd.core.monte_carlo import *
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt

nx=8
ny=8
lat_type='honeycomb'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[2]
Hz_list = np.arange(0,10,2)
ncore_per_group = 6

sites_cart = np.dot(sites,latt)
tri_simplices = get_tri_simplices(sites_cart)

log_handle = log_general(
n_log_conf=100,
n_log_magn=100,
log_topo_chg=True,
tri_simplices=tri_simplices,
log_conf=False,
single_ovf=True,
)



kwargs = dict(
temperature=2,
group_x=2,
group_y=2,
mcs=500,
log_handle=log_handle,
start_conf='zfm',
)



if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    ngroup = size//ncore_per_group
    sp_lat = np.zeros((nx,ny,nat,3),float)

    for iH,Hz in enumerate(Hz_list):
        rank_group = range((iH%ngroup)*ncore_per_group,(iH%ngroup+1)*ncore_per_group)

        ham = spin_hamiltonian(
        Bfield=np.array([1,1,1])*Hz/np.sqrt(3),S_values=S_values,BL_SIA=[SIA],
        BL_exch = [exch_1,exch_3],
        exchange_in_matrix = True)

        kwargs.update( verbosity=1 + (0 in rank_group) )
        MC = MC_controller(**kwargs)
        MC.run_parallel_monte_carlo(ham,sp_lat)

