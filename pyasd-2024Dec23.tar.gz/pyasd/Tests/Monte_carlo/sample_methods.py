#!/usr/bin/env python

# test several distinct methods to 
# propose a random spin vector
# 1. random
# 2. Ising
# 3. Gaussian
# 4. small_step
#
# for details see
# J. Phys. Condens. Matter 
# 26, 103202 (2014)
# 31, 095802 (2019)
#
# Shunhong Zhang, Aug 28, 20201

import numpy as np
import matplotlib.pyplot as plt
from asd.core.random_vectors import *
import asd.mpi.mpi_tools as mt


def get_sphere_grid(theta_step=0.5,phi_step=0.5):
    thetas,phis = np.mgrid[0:180.01:theta_step,0:360.01:phi_step]
    c1 = np.cos(np.deg2rad(thetas))
    s1 = np.sin(np.deg2rad(thetas))
    c2 = np.cos(np.deg2rad(phis))
    s2 = np.sin(np.deg2rad(phis))
    Rvec = np.array([s1*c2,s1*s2,c1])
    return Rvec


def visualize_spins_on_sphere(spins,vec0=None,title='random unit spins'):
    Rvec = get_sphere_grid()
    X,Y,Z = Rvec*0.98  # for viewing the scatters more clearly

    import matplotlib as mpl
    from mpl_toolkits.mplot3d import Axes3D

    fig = plt.figure()
    ax = Axes3D(fig)
    surf=ax.plot_surface(X,Y,Z, facecolor='lightblue',edgecolor='none',
    alpha=0.4,
    shade=True,linewidth=0.2,
    antialiased=False,
    cstride=20,rstride=20)
    ax.scatter(spins[:,0],spins[:,1],spins[:,2],c='r',zorder=1,s=1)
    if vec0 is not None: ax.scatter(*tuple(vec0*1.05),c='yellow',zorder=3,s=20)
    ax.grid(False)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_zticks([])
    ax.set_title(title)


def calc_azimuthal_angle(spins,vv):
    dot_p = np.dot(spins,vv)
    dot_p[np.where(abs(dot_p)>1)] = np.sign(dot_p[np.where(abs(dot_p)>1)])
    theta = np.arccos(dot_p)
    return theta


def calc_polar_angle(spins,vv):
    v3 = vv/np.linalg.norm(vv)
    mat = np.eye(3)
    mat[2] = v3
    if np.linalg.det(mat)<0: mat[1] *= -1
    mat[0] = mat[0] - np.dot(mat[0],v3)*v3
    mat[0]/= np.linalg.norm(mat[0])
    mat[1] = np.cross(mat[2],mat[0])
    x = np.dot(spins,mat[0])
    y = np.dot(spins,mat[1])
    phi = np.angle(x+1.j*y)+np.pi
    dot_p = np.dot(spins,v3)
    phi[np.where(abs(abs(dot_p)-1)<1e-5)] = 0.
    return phi


def test_one_method(sigma=0.5,nn=5000,sample_method='Gaussian'):
    if rank==0: print ('Test sampling method: {}'.format(sample_method))

    sigmas = np.append(np.arange(0,5,0.5),np.arange(5,80,5))
    start,last = mt.assign_task(len(sigmas),size,rank)
    ave_thetas = np.zeros(last-start)
    ave_phis = np.zeros(last-start)
    sm = sample_method.lower()
    for j,sigma in enumerate(sigmas[start:last]):
        vec0 = gen_normal_random_spin()

        if   sm=='gaussian':   spins = np.array([gen_Gaussian_random_spin(vec0,sigma) for i in range(nn)])
        elif sm=='small_step': spins = np.array([gen_small_step_random_spin(vec0,sigma) for i in range(nn)])
        elif sm=='random':     spins = gen_normal_random_spin(nn)
        elif sm=='ising':      spins = np.array([gen_Ising_random_spin()*vec0 for i in range(nn)])
        elif sm=='sph_random': spins = gen_spherical_random_spin(nn)
        elif sm=='normal_scaler': spins = np.random.normal(size=(nn,3))

        ave_thetas[j] = np.rad2deg(np.average(calc_azimuthal_angle(spins,vec0)))
        ave_phis[j] = np.rad2deg(np.average(calc_polar_angle(spins,vec0)))
        ave_phis[np.where(ave_phis>=360)] -= 360
        if rank==0: print ('{:3d} of {}'.format(j+1,last-start))
        if sm=='random' or sm=='sph_random': vec0=None
        #if sigma==0.5: visualize_spins_on_sphere(spins,vec0, '{}: $\sigma$ = {:5.2f}'.format(sample_method,sigma))



    ave_thetas = comm.gather(ave_thetas,root=0)
    ave_phis = comm.gather(ave_phis,root=0)

    if rank==0: 
        ave_thetas = np.concatenate(ave_thetas,axis=0)
        ave_phis = np.concatenate(ave_phis,axis=0)
        if sm == 'sph_random':
            print ('\nImportant note: spherical random vector sampling\n')
            print ('is non-uniformly distributed on the 2-sphere')
            print ('As you can see near the poles the density is higher\n')
        angles_vs_sigma(sigmas,ave_thetas,ave_phis,sample_method)


def angles_vs_sigma(sigmas,ave_thetas,ave_phis,sample_method):
    fmt = 'sigma = {:5.2f} , theta = {:8.4f} , phi = {:8.4f}'
    print ('-'*60)
    for j in range(len(ave_phis)): 
        print (fmt.format(sigmas[j],ave_thetas[j],ave_phis[j]))
    print ('-'*60+'\n')

    fig,ax=plt.subplots(1,1)
    ax.plot(sigmas,ave_thetas,'o-',label='$<\\theta>$')
    ax.plot(sigmas,ave_phis,'s-',label='$<\phi>$')
    yt = np.arange(0,370,90)
    for y in yt: ax.axhline(y,ls='--',alpha=0.5,zorder=-1)
    ax.set_yticks(yt)
    ax.set_xticks(np.arange(0,100,30))
    ax.set_xlabel('$\sigma$')
    ax.set_ylabel('$<\mathrm{\phi}>,<\mathrm{\\theta}>$')
    ax.legend()
    ax.set_title(sample_method)
    fig.tight_layout()
    plt.show()


def hist_norms(n=10000):
    vecs = np.random.normal(size=(n,3))
    norms = np.linalg.norm(vecs,axis=1)
    fig,ax=plt.subplots(1,1)
    ax.hist(norms,bins=100,range=[0,np.max(norms)])
    ax.set_xlabel('|v|')
    ax.set_ylabel('n')
    plt.show()


methods=['random','Ising','Gaussian','small_step','sph_random']
#methods=['normal_scaler']

if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    for method in methods:
        test_one_method(sample_method=method)
