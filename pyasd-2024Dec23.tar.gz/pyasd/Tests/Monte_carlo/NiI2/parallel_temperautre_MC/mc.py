#!/usr/bin/env python

import numpy as np
from asd.core.hamiltonian import *
from asd.core.log_general import log_general
from asd.core.topological_charge import get_tri_simplices
from asd.data_base.exchange_for_NiI2 import *
from asd.core.geometry import build_latt
from asd.core.spin_configurations import *
from asd.mpi.monte_carlo import *
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt

nx=8
ny=8
lat_type='triangular'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[2]
Bfield=np.array([0,0,40])

sites_cart = np.dot(sites,latt)
tri_simplices = get_tri_simplices(sites_cart)

log_handle = log_general(
n_log_conf=100,
n_log_magn=100,
log_topo_chg=True,
tri_simplices=tri_simplices,
)


kwargs = dict(
mcs=500,
adaptive=True,
temperature=1,
log_handle=log_handle,
start_conf='random')

ham = spin_hamiltonian(
Bfield=Bfield,S_values=S_values,BL_SIA=[SIA],
BL_exch = [exch_1,exch_2,exch_3],
exchange_in_matrix = True)

MC = MC_controller(**kwargs)
 

if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    sp_lat = np.zeros((nx,ny,nat,3),float)

    log_handle.set_outdir('PTMC_results')
    kwargs.update(parallel_temperatures=np.arange(1,6,2),log_handle=log_handle)
    PTMC = PTMC_controller(**kwargs)
    PTMC.run_Parallel_Temperature_Monte_Carlo(ham,sp_lat)
