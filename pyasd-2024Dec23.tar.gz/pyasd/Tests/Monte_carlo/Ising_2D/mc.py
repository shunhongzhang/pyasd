#!/usr/bin/env python3

import os
import numpy as np
from asd.core.hamiltonian import *
from asd.core.log_general import log_general
from asd.core.geometry import build_latt
from asd.core.spin_configurations import *
from asd.core.shell_exchange import *
from asd.core.monte_carlo import *
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt

nx=20
ny=20
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[2]
Bfield=np.array([0,0,0])

temp_list = np.arange(5,60,5)
temp_list = np.append(1,temp_list)

S_values = np.array([1.])
SIA = np.zeros(1)
J1_iso = np.array([1])
exch_1 = exchange_shell( neigh_idx[0], J1_iso, shell_name = '1NN')

ham = spin_hamiltonian(
Bfield=Bfield,
S_values=S_values,
BL_SIA=[SIA],
BL_exch = [exch_1],
iso_only=True)

ncore_per_group = 1


kwargs = dict(
group_x=nx,
group_y=ny,
mcs=3000,
sample_method='Ising',
start_conf='zFM',
)



if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    ngroup = size//ncore_per_group
    if ngroup==0: exit('Not sufficient cores invoked!')
    sp_lat = np.zeros((nx,ny,nat,3))

    for itemp,temp in enumerate(temp_list):
        rank_group = range((itemp%ngroup)*ncore_per_group,(itemp%ngroup+1)*ncore_per_group)
        if rank in rank_group: temperature = temp
        else: temperature=0

        log_handle = log_general(
        n_log_conf=100,
        n_log_magn=100,
        outdir='MC_Ising',
        remove_existing_outdir=True,
        prefix = 'T_{:.1f}'.format(temp),
        )

        kwargs.update( 
        verbosity=1 + (0 in rank_group), 
        temperature = temperature,
        log_handle = log_handle,
        rank_group = rank_group )

        MC = MC_controller(**kwargs)
        print (MC._remove_existing_outdir)
    
        MC.run_parallel_monte_carlo(ham,sp_lat)

