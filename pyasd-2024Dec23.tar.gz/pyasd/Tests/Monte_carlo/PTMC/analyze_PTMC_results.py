#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from ptMC import *


def plot_PTMC_results(PTMC):
    fig,ax=plt.subplots(2,1,sharex=True,figsize=(5,6))
    for iepoch in range(PTMC._nepoch):
        all_energies, all_magnetizations = PTMC.get_PTMC_results_one_epoch(iepoch)
        enes = np.average(all_energies,axis=1)
        mags = np.average([np.linalg.norm(mm,axis=1) for mm in all_magnetizations],axis=1)
        ax[0].plot(mags,'o-',label='Ep {}'.format(iepoch))
        ax[1].plot(enes,'s-',label='Ep {}'.format(iepoch))
    for axx in ax: axx.legend()
    ax[1].set_xlabel('T (K)')
    ax[0].set_ylabel('M')
    ax[1].set_ylabel('E')
    fig.tight_layout()
    fig.savefig('square_PTMC',dpi=300)
    plt.show()


if __name__=='__main__':
    plot_PTMC_results(PTMC)
