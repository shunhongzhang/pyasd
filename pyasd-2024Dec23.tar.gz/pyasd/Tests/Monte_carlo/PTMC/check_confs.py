#!/usr/bin/env python

import pickle
import numpy as np
from asd.utility.spin_visualize_tools import *
import os
from ptMC import latt,sites

sites_cart = np.dot(sites,latt)

outdir = 'PTMC_results'

iepoch=1
itemp = 3
fil_1 = '{}/Ep_{}_itemp_{}_initial_confs.ovf'.format(outdir,iepoch,itemp)
#fil_1 = '{}/Ep_{}_itemp_{}_final_confs.ovf'.format(outdir,iepoch,itemp)
params1,spins1 = parse_ovf(fil_1,parse_params=True)
E1 = float(os.popen('grep Etot {}'.format(fil_1)).readlines()[0].split()[-2])

print (fil_1)
ntemp = 5
for itemp in range(ntemp):
    fil_2 = '{}/Ep_{}_itemp_{}_initial_confs.ovf'.format(outdir,iepoch,itemp)
    #fil_2 = '{}/Ep_{}_itemp_{}_confs.ovf'.format(outdir,iepoch-1,itemp)
    if os.path.isfile(fil_2)==False: print ('{} not found'.format(fil_2)); continue
    spins2 = parse_ovf(fil_2,parse_params=True)[1]
    E2 = float(os.popen('grep Etot {}'.format(fil_2)).readlines()[0].split()[-2])
    flag = np.allclose(spins1,spins2)
    print (fil_2,flag)
