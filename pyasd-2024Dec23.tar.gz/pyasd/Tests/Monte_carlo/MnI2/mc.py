#!/usr/bin/env python3

import numpy as np
from asd.core.hamiltonian import *
from asd.data_base.exchange_for_MnI2 import *
from asd.core.geometry import build_latt
from asd.core.spin_configurations import *
from asd.core.topological_charge import get_tri_simplices
from asd.core.monte_carlo import *
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt

nx=9
ny=9
lat_type='triangular'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[2]
Bfield=np.array([0,0,1])*0
temp=0.5

sites_cart = np.dot(sites,latt)
tri_simplices = get_tri_simplices(sites_cart)

log_handle = log_general(
n_log_conf=100,
n_log_magn=100,
log_topo_chg=True,
tri_simplices=tri_simplices,
)


kwargs = dict(
mcs=200,
sample_method='Gaussian',
start_conf='random',
log_handle = log_handle,
)

if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    sp_lat = np.zeros((nx,ny,nat,3),float)

    #ham = build_modified_ham(exch_1,exch_2,exch_3,Bfield=Bfield,iso_shell=[2,3])
    ham = build_ham(Bfield=Bfield)
    
    #run_monte_carlo(ham,sp_lat,**kwargs)
    #run_parallel_monte_carlo(ham,sp_lat,**kwargs)

    MC = MC_controller(**kwargs)
    #MC.run_monte_carlo(ham,sp_lat)
    MC.run_parallel_monte_carlo(ham,sp_lat)

