#!/usr/bin/env python3

import os
import numpy as np
from asd.core.topological_charge import calc_topo_chg
from asd.data_base.exchange_for_NiI2 import *
from asd.utility.spin_visualize_tools import *
import matplotlib.pyplot as plt
from mc import *

def plot_lowest_energy_snapshot(repeat_x=1,repeat_y=1):
    import glob
    ovfs=sorted(glob.glob('snapshots/*ovf'))
    ens = np.array([os.popen('grep "Etot =" {}'.format(fil)).readline().rstrip('\n').split()[-2] for fil in ovfs],float)
    idx=np.argmin(ens)
    plot_snapshot(ovfs[idx],tag='E = {:8.3f} meV/site'.format(ens[idx]),repeat_x=repeat_x,repeat_y=repeat_y)
    

def plot_snapshot(fil_ovf,tag=None,repeat_x=1,repeat_y=1):
    spins = parse_ovf(fil_ovf)[1]
    shape = spins.shape
    if len(shape)==2: 
        sp_lat = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)
    else: 
        nconf = shape[0]
        sp_lat = np.swapaxes(spins.reshape(nconf,ny,nx,nat,3),1,2)
        sp_lat = sp_lat[-1]
    sites_repeat = get_repeated_sites(sites,repeat_x,repeat_y)
    sites_cart = np.dot(sites_repeat,latt)
    sp_lat = get_repeated_conf(sp_lat,repeat_x,repeat_y)
    tri,Q_distri,Q = calc_topo_chg(sites_cart,sp_lat,spatial_resolved=True)
    title = 'Q = {:5.2f}'.format(Q)
    if tag is not None: title = '{}, '.format(tag)+title

    quiver_kws = dict(units='x',pivot='mid',scale=0.8,width=0.3)
    kwargs = dict(scatter_size=50,latt=latt,title=title,show=False,quiver_kws=quiver_kws)
    plot_spin_2d(sites_cart,sp_lat,**kwargs)
    plot_spin_2d(sites_cart,sp_lat,tri=tri,Q_distri=Q_distri,color_mapping='Q_full',**kwargs)
    plt.show()


if __name__=='__main__':
    #plot_lowest_energy_snapshot(repeat_x=1,repeat_y=1)
    rr=2
    plot_snapshot(sorted(glob.glob('snapshots/*ovf'))[-1],tag='final conf',repeat_x=rr,repeat_y=rr)
