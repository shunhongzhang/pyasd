#!/usr/bin/env python3

import os
import numpy as np
from asd.core.hamiltonian import *
from asd.data_base.exchange_for_Gd2C import *
from asd.core.geometry import build_latt
from asd.core.spin_configurations import *
from asd.core.log_general import *
from asd.core.monte_carlo import *
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt

nx=8
ny=8
lat_type='honeycomb'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[2]
Bfield=np.array([0,0,0])
temp_list = np.arange(1,101,10)
temp_list = [2,3]

ncore_per_group = 4


kwargs = dict(
temperature=0.1,
group_x=2,
group_y=2,
mcs=500,
start_conf='random',
sample_method='small_step',
)

if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    ngroup = size//ncore_per_group
    sp_lat = np.zeros((nx,ny,nat,3),float)

    ham = spin_hamiltonian(
    Bfield=Bfield,S_values=S_values,BL_SIA=[SIA],
    BL_exch = [exch_1,exch_2,exch_3],
    iso_only=True)

    for itemp,temp in enumerate(temp_list):
        rank_group = range((itemp%ngroup)*ncore_per_group,(itemp%ngroup+1)*ncore_per_group)
        if rank in rank_group: temperature = temp
        else: temperature=0

        log_handle = log_general(
        prefix='temp_{}'.format(itemp),
        log_conf=False,
        single_ovf=True,
        log_ham_file='hamiltonian.dat',
        outdir='.',
        n_log_magn=50,
        log_file='log_{}'.format(itemp),
        )

        kwargs.update(
        temperature = temperature,
        verbosity=1 + (itemp == 0),
        log_handle = log_handle,
        rank_group = rank_group,)

        MC = MC_controller(**kwargs)
        MC.run_parallel_monte_carlo(ham,sp_lat)
