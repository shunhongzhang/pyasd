#!/usr/bin/env python3

import os
import numpy as np
from asd.core.topological_charge import calc_topo_chg
from asd.data_base.exchange_for_NiI2 import *
from asd.utility.spin_visualize_tools import *
from asd.utility.mag_thermal import *
import matplotlib.pyplot as plt
import importlib
import re

def get_args():
    from asd.utility.asd_arguments import add_mc_arguments,add_switch_arguments
    import argparse
    parser = argparse.ArgumentParser(prog='asd_arguments.py', description = 'post-processing of llg')
    add_mc_arguments(parser)
    add_switch_arguments(parser)
    args = parser.parse_args()
    return args


def plot_lowest_energy_snapshot(repeat_x=1,repeat_y=1,outdir='snapshots'):
    import glob
    ovfs=sorted(glob.glob('{}/*ovf'.format(outdir)))
    ens = np.array([os.popen('grep "Etot =" {}'.format(fil)).readline().rstrip('\n').split()[-2] for fil in ovfs],float)
    idx=np.argmin(ens)
    plot_snapshot(ovfs[idx],tag='E = {:8.3f} meV/site'.format(ens[idx]),repeat_x=repeat_x,repeat_y=repeat_y)
    

def plot_snapshot(fil_ovf,tag=None,repeat_x=1,repeat_y=1):
    spins = parse_ovf(fil_ovf)[1]
    try:
        sp_lat = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)
    except:
        sp_lat = np.swapaxes(spins[-1].reshape(ny,nx,nat,3),0,1)
    sites_repeat = get_repeated_sites(sites,repeat_x,repeat_y)
    sites_cart = np.dot(sites_repeat,latt)
    sp_lat = get_repeated_conf(sp_lat,repeat_x,repeat_y)
    title = '{} '.format(tag)
    quiver_kws = dict(units='x',pivot='mid',scale=0.8,width=0.3)
    plot_spin_2d(sites_cart,sp_lat,scatter_size=30,latt=latt,title=title,show=False,quiver_kws=quiver_kws)

    try:
        tri,Q_distri,Q = calc_topo_chg(sites_cart,sp_lat,spatial_resolved=True)
        title += 'Q = {:5.2f}'.format(Q)
        plot_spin_2d(sites_cart,sp_lat,scatter_size=30,arrow_scale=0.8,arrow_width=0.3,latt=latt,title=title,show=False,tri=tri,Q_distri=Q_distri,color_mapping='Q_full')
    except:
        pass
    plt.show()


def get_snapshot_confs(outdir='snapshots'):
    import glob
    ovfs=sorted(glob.glob('{}/*ovf'.format(outdir)))
    if len(ovfs)==1:
        all_spins = parse_ovf(ovfs[0])[1]
    else:
        all_spins = []
        for fil_ovf in ovfs: 
            spins = parse_ovf(fil_ovf)[1]
            all_spins.append(spins)
    all_spins = np.array(all_spins)
    return all_spins


def get_mag_en_from_log(outdir='snapshots',log_file='log_0',start_conf_idx=30):
    lines = open('{}/{}'.format(outdir,log_file)).readlines()
    idx = np.where([re.search('#',line) for line in lines])[0]
    data = np.array([lines[ii].split()[1:] for ii in idx],float)
    assert data.shape[0]>start_conf_idx, "no. of snapshots ({}) < start_conf_idx ({})".format(data.shape[0],start_conf_idx)
    data = data[start_conf_idx:]
    E  = np.average(data[:,1])
    E2 = np.average(data[:,1]**2)
    mm = np.linalg.norm(data[:,-2:],axis=1)
    m1 = np.average(mm)
    m2 = np.average(mm**2)
    m4 = np.average(mm**4)
    return m1,m2,m4,E,E2


def plot_magnetization(temp_list,start_conf_idx=30):
    mm = []
    for itemp,temp in enumerate(temp_list):
        all_spins = get_snapshot_confs('snapshots_{}'.format(itemp))
        mm.append(np.average(all_spins[start_conf_idx:],axis=(0,1)))
    mm=np.array(mm)
    magnetization = np.linalg.norm(mm,axis=1)
    fig,ax=plt.subplots(1,1)
    ax.plot(temp_list,magnetization)
    ax.set_xlabel('T')
    ax.set_ylabel('M')
    plt.show()


def plot_thermal(temp_list,start_conf_idx=30):
    data = []
    for itemp,temp in enumerate(temp_list):
        data.append(get_mag_en_from_log(outdir='.',log_file='log_{}'.format(itemp),start_conf_idx=start_conf_idx))
    data = np.array(data)
    m1,m2,m4,E,E2 = data.T 
    M,chi,C_v,u4 = calc_thermodynamic_properties(temp_list,m1,m2,m4,E,E2)
    plot_thermodynamic_properties(temp_list,M,chi,E,C_v,figname='therm_prop')
        

if __name__=='__main__':
    args = get_args()
    mc = importlib.import_module(args.mc_file.rstrip('.py'))
    temp_list = mc.temp_list
    nx=mc.nx
    ny=mc.ny
    nat=mc.nat
    sites=mc.sites

    plot_thermal(temp_list,start_conf_idx=args.start_conf_idx)
    #plot_lowest_energy_snapshot(repeat_x=2,repeat_y=2,outdir='snapshots_0')
    #get_snapshot_confs('snapshots_0')
    #plot_magnetization(temp_list)
    #all_spins = get_snapshot_confs('snapshots_0')
    #plot_snapshot('snapshots_12/MCS_spin_confs.ovf')
