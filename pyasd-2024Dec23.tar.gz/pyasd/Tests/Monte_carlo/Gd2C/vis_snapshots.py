#!/usr/bin/env python3

import os
import numpy as np
from asd.core.topological_charge import calc_topo_chg
from asd.data_base.exchange_for_NiI2 import *
from asd.utility.spin_visualize_tools import *
import matplotlib.pyplot as plt
from mc import *

def plot_lowest_energy_snapshot(repeat_x=1,repeat_y=1,outdir='snapshots'):
    import glob
    ovfs=sorted(glob.glob('{}/*spin_confs.ovf'.format(outdir)))
    ens = np.array([os.popen('grep "Etot =" {}'.format(fil)).readline().rstrip('\n').split()[-2] for fil in ovfs],float)
    idx=np.argmin(ens)
    file_ovf = ovfs[idx]
    plot_snapshot(file_ovf,tag='E = {:8.3f} meV/site'.format(ens[idx]),repeat_x=repeat_x,repeat_y=repeat_y)
    

def plot_snapshot(fil_ovf,tag=None,repeat_x=1,repeat_y=1,outdir='snapshots'):
    spins = parse_ovf(fil_ovf)[1]
    sp_lat = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)
    sites_repeat = get_repeated_sites(sites,repeat_x,repeat_y)
    sites_cart = np.dot(sites_repeat,latt)
    sp_lat = get_repeated_conf(sp_lat,repeat_x,repeat_y)
    tri,Q_distri,Q = calc_topo_chg(sp_lat,sites_cart,spatial_resolved=True)
    title = 'Q = {:5.2f}'.format(Q)
    if tag is not None: title = '{}, '.format(tag)+title

    #quiver_kws = dict(scale=0.8,width=0.3,units='x',pivot='mid')
    kws = dict(scatter_size=30,quiver_kws=quiver_kws,title=title,show=False,
    colorbar_shrink=0.3,colorbar_orientation='vertical',colorbar_axes_position=[0.7,0.5,0.02,0.25])
    plot_spin_2d(sites_cart,sp_lat,**kws)
    kws.update(tri=tri,Q_distri=Q_distri,color_mapping='Q_full',show=True)
    plot_spin_2d(sites_cart,sp_lat,**kws)


if __name__=='__main__':
    plot_lowest_energy_snapshot(repeat_x=2,repeat_y=2,outdir='.')
