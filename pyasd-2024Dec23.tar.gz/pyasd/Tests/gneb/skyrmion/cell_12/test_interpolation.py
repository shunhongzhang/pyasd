#!/usr/bin/env python

# this script is still under test

import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.gneb import *
from asd.core.spin_configurations import *
from asd.utility.ovf_tools import parse_ovf
from asd.utility.spin_visualize_tools import plot_spin_2d,quiver_kws
from asd.core.geometry import build_latt


nx=12
ny=12
nat=1

latt,sites = build_latt('square',nx,ny,1,return_neigh=False)

fmt = '{:12.8f} '*3

if __name__=='__main__':
    spins = parse_ovf('Spirit_relaxed_skyrmion.ovf1')[1]
    conf_init = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)
    conf_finl = np.zeros_like(conf_init)
    conf_finl[...,2] = 1.

    nimage = 8
    confs = linear_interpolate_images(conf_init,conf_finl,nimage)
    quiver_kws.update(scale=0.3)
    kwargs = dict(scatter_size=20,quiver_kws=quiver_kws)
    sites_cart = np.dot(sites,latt)
    plot_spin_2d(sites_cart,confs[-1],show=False,**kwargs,title='final image from interpolatation')
    plot_spin_2d(sites_cart,conf_finl,show=True, **kwargs,title='final image')
 
    for nimage in range(10,50,10):
        confs = linear_interpolate_images(conf_init,conf_finl,nimage)
        #print (nimage,np.allclose(confs[-1],conf_finl))

        norm1 = np.average(confs[-1],axis=(0,1,2))
        norm2 = np.average(conf_finl,axis=(0,1,2))
        print (nimage,fmt.format(*tuple(norm1)))
        print (nimage,fmt.format(*tuple(norm2)))

        diff = confs[-1] - conf_finl
        max1 = np.max(diff,axis=(0,1,2))
        #print (('{:4d} '+fmt).format(nimage,*tuple(max1)))
