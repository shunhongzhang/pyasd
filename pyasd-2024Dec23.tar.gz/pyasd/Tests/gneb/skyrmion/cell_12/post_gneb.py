#!/usr/bin/env python

# this script is still under test

import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.gneb import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *
from skyrmion_gneb import nx


ny=nx
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]

ite = 100
ite_ci = 100

outdir='GNEB_results'
prefix='GNEB'
start_idx=0
jump=1

if __name__ == '__main__':
    iters = np.loadtxt('{}/{}_dist.dat'.format(outdir,prefix))[:,0]
    dists = np.loadtxt('{}/{}_dist.dat'.format(outdir,prefix))[:,1:]
    eners = np.loadtxt('{}/{}_ener.dat'.format(outdir,prefix))[:,1:]
    #dists_ci = np.loadtxt('{}/{}_dist_ci.dat'.format(outdir,prefix))
    #eners_ci = np.loadtxt('{}/{}_ener_ci.dat'.format(outdir,prefix))[:,1:]

    labels = ['GNEB, iter {:.0f}'.format(item) for item in iters[start_idx::jump]]
    #view_en_profile([dists[ite],dists_ci[ite_ci]],[eners[ite],eners_ci[ite_ci]],['GNEB','ci-GNEB'],interpolate=True)
    view_en_profile(dists[start_idx::jump],eners[start_idx::jump],labels,save=True)
    #view_en_profile(dists_ci[:,1:],eners_ci,['ci-GNEB, iter {:.0f}'.format(item) for item in dists_ci[:,0]])
    #view_en_profile([dists],[eners],['GNEB'])

    exit()
    kwargs=dict(scatter_size=30)
    animate_NEB_evolution(ite,latt,sites,climb_image=False,kwargs=kwargs,outdir=outdir,prefix=prefix)
    #animate_NEB_evolution(ite,latt,sites,climb_image=True,kwargs=kwargs,outdir=outdir)
