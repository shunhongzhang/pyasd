#!/usr/bin/env python

# this script is still under test

import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.gneb import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *
from asd.core.log_general import log_general
from asd.core.topological_charge import get_tri_simplices


nx=20
ny=nx
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]


S_values=np.array([1])
SIA=np.array([0.5])
DM=0.6
J1_iso = np.ones(1)
J1_sym_xyz = np.tile(np.eye(3),(1,4,1,1))

DM1_rpz = np.array([[-DM,0,0]])
DM1_xyz = get_exchange_xyz(DM1_rpz,rotvecs[0])

exch_1 = exchange_shell( neigh_idx[0], J1_iso, DM_xyz = DM1_xyz, shell_name = '1NN')

ham = spin_hamiltonian(S_values=S_values,BL_SIA=[SIA],
BL_exch=[exch_1])


log_handle = log_general(
outdir='GNEB',
prefix='GNEB',
n_log_magn = 20,
n_log_conf = 20,
tri_simplices = get_tri_simplices(np.dot(sites,latt)),
log_topo_chg=True,
)

gneb_kwargs = dict(
niter=100,
pre_ci_niter=-1,
nimage=6,
spring_const=20,
relax_init_final_images=False,
fix_boundary=True,
rot_step=0.005,
parallel_mode = 'sites',
log_handle = log_handle,
)

if __name__=='__main__':
    spins = parse_ovf('Spirit_relaxed_skyrmion.ovf1')[1]
    conf_init = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)
    conf_finl = np.zeros_like(conf_init)
    conf_finl[...,2] = 1.

    confs,dists,ens = mpi_run_gneb(ham,conf_init,conf_finl,**gneb_kwargs)

    log_handle._n_log_conf=30
    gneb_kwargs.update(pre_ci_niter=0,
    niter=100,
    spring_const=10,
    parallel_mode='sites',
    read_images_from_file='GNEB/GNEB_spin_confs_iter_100.ovf',
    log_handle = log_handle)

    confs_ci,dists_ci,ens_ci = run_parallel_gneb(ham,conf_init,conf_finl,**gneb_kwargs)
