#!/usr/bin/env python

import os
import sys
import numpy as np

from spirit import state,io,log,system,parameters,chain
from spirit import geometry,configuration,hamiltonian
from spirit import simulation,quantities,transition
from asd.utility.spirit_tool import verbose_quantities

nx=20
ny=nx

skyr_name="skyrmion-Bloch"
phase=90

achiral=False
quiet=False

noi=11

if __name__=='__main__':
    os.system('rm -r output* Log.txt 2>/dev/null')
    os.mkdir('output')

    with state.State(quiet=quiet) as p_state:

        log.send(p_state, log.LEVEL_ALL, log.SENDER_ALL, "Performing skyrmion diffusion calculation with {} images".format(noi))
        ### Set the length of the chain
        chain.image_to_clipboard(p_state)
        chain.set_length(p_state, noi)

        for idx in range(noi):

            geometry.set_n_cells(p_state,[nx,ny,1])
            geometry.set_mu_s(p_state,2)

            hamiltonian.set_boundary_conditions(p_state, [1,1,0])
            hamiltonian.set_anisotropy(p_state, 0.5, [0,0,1])
            hamiltonian.set_exchange(p_state, 1, [1])
            hamiltonian.set_dmi(p_state, 1, [0.6], chirality=-1)

            parameters.llg.set_iterations(p_state, 80000, 1000)
            parameters.llg.set_output_tag(p_state,'sqr_skyrmion')
            parameters.llg.set_output_folder(p_state, 'output')
            parameters.llg.set_output_configuration(p_state, False, True, 3)
            parameters.llg.set_output_general(p_state,1,1,1)
            parameters.llg.set_output_energy(p_state,0,1,0,1,1)

        io.image_read(p_state, 'init.ovf', idx_image_inchain=0)
        io.image_read(p_state, 'finl.ovf', idx_image_inchain=-1)
        transition.homogeneous(p_state, 0, noi-1)

        system.update_data(p_state)
        #verbose_quantities(p_state,'output/'+skyr_name+'-initial')

        GNEB = simulation.METHOD_GNEB
        VP = simulation.SOLVER_VP # Velocity projection minimiser

        parameters.gneb.set_output_energies(p_state,0,1,1,1)
        parameters.gneb.set_output_folder(p_state,'output')
        parameters.gneb.set_output_chain(p_state,1,3)
        parameters.gneb.set_output_general(p_state,1,0,1)
        ### Initial relaxation of transition path
        simulation.start(p_state, GNEB, VP, n_iterations=10000)
        ### Full relaxation with climbing image
        parameters.gneb.set_image_type_automatically(p_state)
        simulation.start(p_state, GNEB, VP)

        ### Calculate the energy barrier of the transition
        E = chain.get_energy(p_state)
        delta = max(E) - E[0]
        log.send(p_state, log.LEVEL_ALL, log.SENDER_ALL, "Energy barrier: {} meV".format(delta))
