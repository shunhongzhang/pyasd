#!/usr/bin/env python

# this script is still under test

import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.gneb import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *
from skyrmion_gneb import nx


ny=nx
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]

ite = 100
ite_ci = 600

iters = np.arange(0,ite+1,20)
iters_ci = np.arange(0,ite_ci+1,60)

if __name__ == '__main__':
    dists = np.loadtxt('dist.dat')[:,1:]
    ens = np.loadtxt('ener.dat')[:,1:]
    dists_ci = np.loadtxt('dist_ci.dat')[:,1:]
    ens_ci = np.loadtxt('ener_ci.dat')[:,1:]

    view_en_profile([dists[ite],dists_ci[ite_ci]],[ens[ite],ens_ci[ite_ci]],['GNEB','ci-GNEB'],interpolate=True)
    view_en_profile(dists[iters],ens[iters],['GNEB, iter {}'.format(item) for item in iters])
    view_en_profile(dists_ci[iters_ci],ens_ci[iters_ci],['ci-GNEB, iter {}'.format(item) for item in iters_ci])
    #view_en_profile([dists],[ens],['GNEB'])
    kwargs=dict(scatter_size=30)
    #animate_NEB_evolution(ite,latt,sites,climb_image=False,kwargs=kwargs)
    #animate_NEB_evolution(ite,latt,sites,climb_image=True,kwargs=kwargs)
