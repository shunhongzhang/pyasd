#!/usr/bin/env python

# Test GNEB method 
# finding minimum energy path (MEP) for a single-spin system
# with multiple single-ion anisotropy axis
# Shunhong Zhang
# szhang2@ustc.edu.cn
# Mar 05 2022
# 
# Important Note:
# we have three different methods to calculate the geodesic distance
# cosines/haversine/Vincenty, you can refer to
# Computer Physics Communications 196, 335 (2015)
# for details
# According to our tests, the spring constant required to
# realized approximate equi-spacing of images
# is quite different for these three methods
# for consines/Vincenty, spring_const = 5 is enough
# for haversine, large spring_const (~100) is required


import numpy as np
import matplotlib.pyplot as plt
from asd.core.log_general import log_general
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.gneb import *


def map_MAE_3d(nat,mae_kwargs,ens=None,show=False):
    sp_lat=np.zeros((1,1,nat,3))
    mae_kwargs.update(show=False,alpha=0.5,display_mode='3d')
    ens_map,fig = ham.map_MAE_3d(sp_lat,**mae_kwargs)
    if ens is None: return fig
    Rvec = np.zeros((nimage+2,3))
    ens_normalized = ens[-1] + abs(np.min(ens[-1]))
    for ii in range(nimage+2):
        Rvec[ii] = confs[ii,0,0,0]*ens_normalized[ii]*1.1
    fig.axes[0].scatter(*tuple(Rvec.T),color='m',s=60,zorder=2)
    fig.axes[0].plot(*tuple(Rvec.T),c='g')
    if show: plt.show()
    return fig


def map_MAE_2d(nat,mae_kwargs,confs=None,show=False):
    sp_lat=np.zeros((1,1,nat,3))
    mae_kwargs.update(show=False,display_mode='2d')
    ens_map,fig = ham.map_MAE_3d(sp_lat,**mae_kwargs)
    if confs is None: return fig
    thetas = np.arccos(confs[:,0,0,0,2])
    phis = np.angle(confs[:,0,0,0,0]+1.j*confs[:,0,0,0,1])
    thetas = np.rad2deg(thetas)
    phis = np.rad2deg(phis)
    phis[ np.where(phis<-90) ] += 360
    fig.axes[0].plot(phis,thetas,'o-',c='m',ms=4)
    for ii in [0,-1]: fig.axes[0].scatter(phis[ii],thetas[ii],marker='*',s=50,c='r',zorder=3)
    if show: plt.show()
    return fig


def display_single_spin_images(confs):
    from asd.core.geometry import build_latt
    from asd.utility.spin_visualize_tools import quiver_kws,plot_spin_2d
    latt,sites = build_latt('chain',confs.shape[0],1,1,return_neigh=False)
    quiver_kws.update(scale=1,width=0.1,headlength=5,)
    kwargs = dict(
    scatter_size=50,
    quiver_kws=quiver_kws,
    latt = latt,
    colorbar_orientation='auto',
    show=True)
    plot_spin_2d(np.dot(sites,latt),confs[:,0,0,0],**kwargs)


S_values = np.array([1/2])
SIA = [
np.array([-0.3]),
np.array([ 0.5]),
np.array([ 0.6])
]

SIA_axis = [
np.array([[ 0, 0, 1]]),
np.array([[-1, 0, 1]]),
np.array([[ 1, 0, 1]])
]

ham = spin_hamiltonian(
Bfield = np.array([0,0,2]),
S_values=S_values,
BL_SIA=SIA,
BL_SIA_axis = SIA_axis,
boundary_condition=[0,0,0],
)


nx=1
ny=1
nat=1

mae_kwargs=dict(
show=True,
map_shape=True,
show_minima=False,
savefig=False,
display_mode='3d',
alpha=0.5,
)


conf_init = np.zeros((nx,ny,nat,3))
conf_finl = np.zeros((nx,ny,nat,3))
conf_init[...,0] = 1.
conf_finl[...,0] = -1.


log_handle = log_general(
outdir='images',
prefix='GNEB',
n_log_conf=100,
n_log_ener=100,
)



#=====================================================================================
# Important Note:
# according to our tests, larger spring_const requires
# smaller rot_step so that the landscape can be carefully searched
# large niter is also required for convergence to MEP
# 
# For spring_const<10: rot_step=0.010, niter =  500 can achieve convergence
# For spring_const=50: rot_step=0.005, niter = 2000 are required for convergence
#=====================================================================================

gneb_kwargs = dict(
niter=2000,
pre_ci_niter=-1,
nimage=34,
spring_const=50,
relax_init_final_images=False,
rot_step=0.005,
final_image_from_interpolation=True,
log_handle = log_handle,
)

fil_conf = '{}/GNEB_spin_confs_iter_{}.ovf'.format(log_handle._outdir,str(gneb_kwargs['niter']).zfill(3))

 

if __name__=='__main__':
    GNEB = GNEB_controller(**gneb_kwargs)
    #confs,dists,ens = GNEB.run_gneb(ham,conf_init,conf_finl)

    gneb_kwargs.update(pre_ci_niter=0,
    read_images_from_file=fil_conf,)
    GNEB = GNEB_controller(**gneb_kwargs)
    #confs_ci,dists_ci,ens_ci = GNEB.run_gneb(ham,conf_init,conf_finl)

    gneb_kwargs.update(pre_ci_niter=-1,read_images_from_file=None,
    #parallel_mode = 'images',
    )
    GNEB = GNEB_controller(**gneb_kwargs)
    confs,dists,ens = GNEB.run_gneb(ham,conf_init,conf_finl)
    #confs,dists,ens = GNEB.run_parallel_gneb(ham,conf_init,conf_finl)

    log_handle._remove_existing_outdir=False
    gneb_kwargs.update(pre_ci_niter=0,
    read_images_from_file=fil_conf,log_handle=log_handle)
    GNEB = GNEB_controller(**gneb_kwargs)
    #confs_ci,dists_ci,ens_ci = GNEB.run_parallel_gneb(ham,conf_init,conf_finl)
    confs_ci,dists_ci,ens_ci = GNEB.run_gneb(ham,conf_init,conf_finl)
