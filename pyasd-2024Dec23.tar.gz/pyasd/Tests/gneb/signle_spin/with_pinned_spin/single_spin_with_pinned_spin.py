#!/usr/bin/env python

# try to reproduce the example of 
# PRB 99, 224414 (2019)
# a moving spin interacting with a fixed one
# via Heisenberg exchange and DM interaction
# as well as a single-ion anisotropy in reduce symmetry
# the energy surface is mapped to a sphere
# representing the orientation of the moving spin

import numpy as np
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.constants import muB
from asd.core.gneb import *
from asd.core.log_general import log_general
from asd.utility.plot_tools_3d import *
import matplotlib.pyplot as plt
import asd.mpi.mpi_tools as mt


def get_energy_landscape(Rvec,pinned_spin):
    eners = np.zeros((ntheta,nphi))
    for itheta,iphi in np.ndindex(ntheta,nphi):
        n_i = Rvec[:,itheta,iphi]
        eners[itheta,iphi]  = -SIA0 * np.dot(n_i,SIA_axis[0])**2
        eners[itheta,iphi] += -J_iso[0]*np.dot(n_i,pinned_spin)
        eners[itheta,iphi] += -np.dot(DM[0,0],np.cross(n_i,pinned_spin))
    return eners

 
def get_energy_landscape_by_ham(ham,Rvec,pinned_spin):
    sp_lat = np.zeros((2,1,1,3))
    sp_lat[1,0,0]=pinned_spin
    eners = np.zeros((ntheta,nphi))
    for itheta,iphi in np.ndindex(ntheta,nphi):
        n_i = Rvec[:,itheta,iphi]
        sp_lat[0,0,0] = n_i
        B_eff_SIA = ham.calc_SIA_exch_field(sp_lat,[0,0,0])
        B_eff_exc = ham.calc_local_B_eff(sp_lat,[0,0,0])
        B_eff = B_eff_exc - B_eff_SIA
        eners[itheta,iphi] = -np.dot(n_i,B_eff)*ham._S_values[0]*ham._g_factor*muB
        eners[itheta,iphi]+= -SIA0 * np.dot(n_i,SIA_axis[0])**2
    return eners


# Rvec_0 is in shape of (npoint,3)
def mpi_get_energy_landscape_by_ham(ham,Rvec_0,pinned_spin):
    comm,size,rank,node = mt.get_mpi_handles()
    sp_lat = np.zeros((2,1,1,3))
    sp_lat[1,0,0]=pinned_spin
    eners = np.zeros((ntheta,nphi))
    start,last = mt.assign_task(len(Rvec_0),size,rank)
    eners = np.zeros(last-start)
    for ii in range(start,last):
        n_i = Rvec_0[ii]
        sp_lat[0,0,0] = n_i
        B_eff_SIA = ham.calc_SIA_exch_field(sp_lat,[0,0,0])
        B_eff_exc = ham.calc_local_B_eff(sp_lat,[0,0,0])
        B_eff = B_eff_exc - B_eff_SIA
        eners[ii-start]  = -np.dot(n_i,B_eff)*ham._S_values[0]*ham._g_factor*muB
        eners[ii-start] += -SIA0 * np.dot(n_i,SIA_axis[0])**2
    eners = comm.allgather(eners)
    eners = np.concatenate(eners,axis=0)
    return eners




def compare_landscapes():
    eners_1 = get_energy_landscape(Rvec,pinned_spin)
    eners_2 = get_energy_landscape_by_ham(ham,Rvec,pinned_spin)
    print (np.allclose(eners_1,eners_2))
    x0,y0,fig = map_sphere_on_2d_Kavrayskiy(eners_1,show=False,cmap='RdYlBu_r',title='Direct calculation')
    x0,y0,fig = map_sphere_on_2d_Kavrayskiy(eners_2,show=True, cmap='RdYlBu_r',title='From Hamiltonian')



r2 = np.sqrt(2)
r3 = np.sqrt(3)
latt,sites,neigh_idx,rotvecs = build_latt('chain',1,1,1,return_neigh=True)
neigh = neigh_idx[0][:,1:]

J = 1
J_iso = np.array([J])
DM = -np.array([[[0,0,J]]])
SIA0 = 4*J
SIA = [np.array([SIA0])]
axis = np.array([0,1,-1])
#axis = np.array([0,-1,1])  # for conv=2
SIA_axis = np.array([axis])

exch = exchange_shell(neigh, J_iso, DM_xyz = DM, shell_name = '1NN')

ham = spin_hamiltonian(
S_values = np.array([1/2]),
BL_SIA = SIA,
BL_SIA_axis = [SIA_axis],
BL_exch = [exch],
boundary_condition=[0,0,0],
)

# the reference did not provide the pinned spin
# we assume it to be along z direction
pinned_spin = np.array([0,0,1.])
pinned_spin/= np.linalg.norm(pinned_spin)


nphi = 240
ntheta = 120
thetas,phis,Rvec = gen_grid_points_on_sphere(nphi,ntheta,conv=1)

log_handle = log_general(
prefix='GNEB',
n_log_conf=100,
n_log_ener=100,
)

nimage=30

kwargs = dict(
nimage=nimage,
niter=800,
pre_ci_niter=-1,
spring_const=0.5,
rot_step=0.005,
pinned_idx=[[1,0,0]],
parallel_mode='images',
log_handle=log_handle,
)

comm,size,rank,node = mt.get_mpi_handles()

if __name__=='__main__':
    #compare_landscapes()
    #eners = get_energy_landscape_by_ham(ham,Rvec,pinned_spin)

    Rvec_0 = Rvec.reshape(3,-1).T
    eners = mpi_get_energy_landscape_by_ham(ham,Rvec_0,pinned_spin)
    eners = eners.reshape(ntheta,nphi)
 
    itheta1,iphi1 = np.where(eners == np.min(eners))
    itheta2,iphi2 = np.where(eners == np.min(eners[:,:nphi//2]))

    conf_init = np.zeros((2,1,1,3))
    conf_finl = np.zeros((2,1,1,3))
    conf_init[1,0,0] = pinned_spin
    conf_finl[1,0,0] = pinned_spin
    conf_init[0,0,0] = Rvec[:,itheta2,iphi2][:,0]
    conf_finl[0,0,0] = Rvec[:,itheta1,iphi1][:,0]
    confs = linear_interpolate_images(conf_init,conf_finl,nimage)

    GNEB = GNEB_controller(**kwargs)
    confs_gneb,dists_gneb,eners_gneb = GNEB.run_parallel_gneb(ham,conf_init,conf_finl)
    #eners_path = mpi_get_energy_landscape_by_ham(ham,confs_gneb[:,0,0,0],pinned_spin)
 
    if rank==0:
        x0,y0,fig = map_sphere_on_2d_Kavrayskiy(eners,show=False, cmap='RdYlBu_r')
        images = np.array([Cartesian_to_Kavaryskiy(*tuple(conf[0,0,0])) for conf in confs])
        fig.axes[0].plot(*tuple(images.T),'o--',c='m')
        images_gneb = np.array([Cartesian_to_Kavaryskiy(*tuple(conf[0,0,0])) for conf in confs_gneb])
        fig.axes[0].plot(*tuple(images_gneb.T),'^-',c='darkgreen',markersize=5)
        view_en_profile([dists_gneb],[eners_gneb])
        iters = np.loadtxt('GNEB_dist.dat')[:,0]
        dists = np.loadtxt('GNEB_dist.dat')[:,1:]
        eners = np.loadtxt('GNEB_ener.dat')[:,1:]
        labels = ['iter {}'.format(item) for item in iters]
        view_en_profile(dists,eners,labels)
        plt.show()
