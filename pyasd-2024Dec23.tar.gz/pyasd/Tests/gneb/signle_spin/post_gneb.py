#!/usr/bin/env python

import os
import numpy as np
import matplotlib.pyplot as plt
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.gneb import view_en_profile
from asd.utility.ovf_tools import parse_ovf
from asd.utility.spin_visualize_tools import plot_spin_2d
from test_GNEB_single_spin import gneb_kwargs,nat,ham,log_handle


def map_MAE_3d(nat,mae_kwargs,confs=None,eners=None,show=False):
    sp_lat=np.zeros((1,1,nat,3))
    mae_kwargs.update(show=False,alpha=0.5,display_mode='3d')
    eners_map,fig = ham.map_MAE_3d(sp_lat,**mae_kwargs)
    if eners is None: return fig
    nimage = confs.shape[0]
    Rvec = np.zeros((nimage,3))
    eners_normalized = eners + abs(np.min(eners))
    for ii in range(nimage):
        Rvec[ii] = confs[ii,0,0,0]*1.02
        if mae_kwargs['map_shape']: Rvec[ii] *= eners_normalized[ii]
    fig.axes[0].scatter(*tuple(Rvec.T),color='m',s=60,zorder=5)
    fig.axes[0].plot(*tuple(Rvec.T),c='g')
    if show: plt.show()
    return fig


def map_MAE_2d(nat,mae_kwargs,confs=None,show=False,title='GNEB'):
    sp_lat=np.zeros((1,1,nat,3))
    thetas = np.arccos(confs[:,0,0,0,2])
    phis = np.angle(confs[:,0,0,0,0]+1.j*confs[:,0,0,0,1])
    thetas = np.rad2deg(thetas)
    phis = np.rad2deg(phis)
    #phis[ np.where(phis<-90) ] += 360
    phis[ np.where(phis<5) ] += 360
    mae_kwargs.update(show=False,display_mode='2d') #(phis=phis,thetas=thetas)
    eners_map,fig = ham.map_MAE_3d(sp_lat,**mae_kwargs)
    if confs is None: return fig
    fig.axes[0].plot(phis,thetas,'o-',c='m',ms=4)
    fig.axes[0].set_title(title)
    for ii in [0,-1]: fig.axes[0].scatter(phis[ii],thetas[ii],marker='*',s=50,c='r',zorder=3)
    if show: plt.show()
    return fig


def display_single_spin_images(confs,show=False):
    from asd.core.geometry import build_latt
    from asd.utility.spin_visualize_tools import quiver_kws,plot_spin_2d
    latt,sites = build_latt('chain',confs.shape[0],1,1,return_neigh=False)
    quiver_kws.update(scale=1,width=0.1,headlength=5,)
    kwargs = dict(
    scatter_size=50,
    quiver_kws=quiver_kws,
    latt = latt,
    colorbar_orientation='auto',
    show=show)
    plot_spin_2d(np.dot(sites,latt),confs,**kwargs)


def animate_NEB_evolution(niter,nimage,nx=1,ny=1,nat=1,fil_conf='GNEB_confs.ovf'):
    from asd.core.geometry import build_latt
    from asd.utility.spin_visualize_tools import quiver_kws,make_ani,parse_ovf
    import glob

    latt,sites = build_latt('chain',nimage+2,1,1,return_neigh=False)
    sites_cart = np.dot(sites,latt)
    quiver_kws.update(scale=1.5,width=0.1,headlength=5,)
    superlatt = np.dot([[nimage+2,0],[0,1]],latt)

    kwargs = dict(
    scatter_size=80,
    quiver_kws=quiver_kws,
    latt=latt,
    #colorbar_orientation='auto',
    )

    fils = glob.glob('GNEB_confs_ci*ovf')
    fils = sorted(fils)
    confs = []
    titles = []
    for fil_conf in fils:
        ite = fil_conf.split('_')[-1].rstrip('.ovf')
        spins = parse_ovf(fil_conf)[1]
        confs.append( spins.reshape(nimage+2,nx,ny,nat,3) )
        titles.append('Iter {}'.format(ite))
    confs = np.array(confs)
    kwargs.update(titles=titles)
    make_ani(sites_cart,confs,**kwargs)

mae_kwargs=dict(
show=False,
map_shape=False,
show_minima=False,
savefig=False,
display_mode='3d',
alpha=0.5,
)

ite=-1
jump = 4
outdir=log_handle._outdir

if __name__=='__main__':
    assert os.path.isfile('{}/GNEB_dist.dat'.format(outdir)),'GNEB_dist.dat not found!'
    assert os.path.isfile('{}/GNEB_dist_ci.dat'.format(outdir)),'GNEB_dist_ci.dat not found!'
 
    iters = np.loadtxt('{}/GNEB_dist.dat'.format(outdir))[:,0]
    dists = np.loadtxt('{}/GNEB_dist.dat'.format(outdir))[:,1:]
    eners = np.loadtxt('{}/GNEB_ener.dat'.format(outdir))[:,1:]
    dists_ci = np.loadtxt('{}/GNEB_dist_ci.dat'.format(outdir))[:,1:]
    eners_ci = np.loadtxt('{}/GNEB_ener_ci.dat'.format(outdir))[:,1:]

    view_en_profile([dists[ite],dists_ci[ite]],[eners[ite],eners_ci[ite]],['GNEB','ci-GNEB']) 
    labels = ['GNEB, iter {:.0f}'.format(item) for item in iters]
    view_en_profile(dists[::jump],eners[::jump],labels[::jump])
    labels = ['ci-{}'.format(item) for item in labels]
    view_en_profile(dists_ci[::jump],eners_ci[::jump],labels[::jump])
    #animate_NEB_evolution(gneb_kwargs['niter'],gneb_kwargs['nimage'],nx=1,ny=1)

    spins = parse_ovf('{}/GNEB_spin_confs_iter_{}.ovf'.format(outdir,str(gneb_kwargs['niter']).zfill(3)))[1]
    confs = spins.reshape(-1,1,1,1,3)
    #display_single_spin_images(confs)
    map_MAE_2d(nat,mae_kwargs,confs=confs,show=True,title='GNEB')
    #map_MAE_3d(nat,mae_kwargs,confs=confs,eners=eners_ci,show=True)

    spins = parse_ovf('{}/GNEB_spin_confs_ci_iter_{}.ovf'.format(outdir,str(gneb_kwargs['niter']).zfill(3)))[1]
    confs = spins.reshape(-1,1,1,1,3)
    #display_single_spin_images(confs)
    map_MAE_2d(nat,mae_kwargs,confs=confs,show=True,title='climb-image GNEB')
    #map_MAE_3d(nat,mae_kwargs,confs=confs,eners=eners_ci,show=True)
