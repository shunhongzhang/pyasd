#!/usr/bin/env python

# create a complex hypothetical energy surface
# for a single spin by using
# superposition of Gaussian functions
# The Hamiltonian is 
#
# H = \Sum_{i}[c_i*np.exp(-((1-n_i \dot v_i)^2/(2*sigma_i^2))]
# where i is the index of Gaussian function, v_i is a vector
# c_i and sigma_i are real numbers
#
# See manual of Spirit and 
# Phys. Rev. B 99, 224414 (2019)
# Appenditheta G for details

# see also
# Phys. Rev. Lett. 121, 197202 (2018)

import numpy as np
import matplotlib.pyplot as plt
from asd.utility.plot_tools_3d import *

# table I from the PRB paper, appenditheta G
table_1 = '''
-110 0.06 -0.20  0.00 -0.90
 080 0.15 -1.00  0.20 -0.20
-090 0.10  1.00 -0.20 -0.10
 009 0.03  0.80  0.50 -0.80
 015 0.07  0.80 -0.50 -0.70
-090 0.10  0.50  1.20 -0.40
-090 0.10  0.20 -0.90 -0.40'''


# table I of Supp Mater of PRL paper
table_2 = '''
-1.10 0.06 -0.20  0.00 -0.90
 0.80 0.15 -1.00  0.20 -0.20
-0.90 0.10  1.00 -0.20 -0.10
 0.09 0.03  0.80  0.50 -0.80
 0.13 0.03  0.80 -0.50 -0.70
-0.90 0.10  0.50  1.20 -0.40
-0.90 0.10  0.20 -0.90 -0.40'''


def gen_gaussian_landscape(n_i,params_set,gaussian_method=1):
    # following Phys. Rev. B 99, 224414 (2019), Spirit_code
    def single_gaussian_1(n_i,params): return params[0] * np.exp( -(1-np.dot(n_i,params[2:]))**2 / (2*params[1]**2) )

    # following Computer Physics Communications 196, 335 (2015)
    def single_gaussian_2(n_i,params): return params[0] * np.exp( -(np.dot(n_i,params[2:]))**2 / (2*params[1]**2) )

    if gaussian_method==1: return np.sum([single_gaussian_1(n_i,params) for params in params_set])
    if gaussian_method==2: return np.sum([single_gaussian_2(n_i,params) for params in params_set])



def gen_gaussian_field_on_sphere(params,nphi=100,ntheta=80,gaussian_method=1):
    thetas,phis,Rvec = gen_grid_points_on_sphere(nphi,ntheta)
    H = np.zeros((ntheta,nphi))
    for itheta,iphi in np.ndindex(ntheta,nphi):
        H[itheta,iphi] = gen_gaussian_landscape(Rvec[:,itheta,iphi],params,gaussian_method)
    return H


def map_gaussian_ham(params,nphi=150,ntheta=120,cmap='viridis'):
    import matplotlib as mpl
    from mpl_toolkits.mplot3d import Axes3D
    H = gen_gaussian_field_on_sphere(params,nphi,ntheta)
    #map_3d_surface(H,show=True,alpha=1,cmap=cmap)
    map_sphere_on_2d(H,show=True,cmap='rainbow')


params_1 = np.array(table_1.split(),float).reshape(-1,5)
params_2 = np.array(table_2.split(),float).reshape(-1,5)

# Appendix E of 
# Computer Physics Communications 196, 335 (2015)
params_3a = np.loadtxt('Table_3.txt1',skiprows=3)
ngaussian = len(params_3a)
params_3 = np.zeros((ngaussian,5))
params_3[:,:2] = params_3a[:,:2]
params_3[:,2] = np.cos(params_3a[:,3]) * np.sin(params_3a[:,3])
params_3[:,3] = np.sin(params_3a[:,3]) * np.sin(params_3a[:,3])
params_3[:,4] = np.cos(params_3a[:,2])
header = 'n_gaussians {}\ngaussians'.format(ngaussian)
np.savetxt('Gaussian_3.txt',params_3,fmt='%14.6f',header=header)


if __name__=='__main__':
    #map_gaussian_ham(params_1,60,50)
    #map_gaussian_ham(params_2,60,50)
    map_gaussian_ham(params_3,60,50,cmap='jet')
