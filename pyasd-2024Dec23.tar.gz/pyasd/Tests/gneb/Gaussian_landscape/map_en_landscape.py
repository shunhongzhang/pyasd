#!/usr/bin/env python

import os
import numpy as np
from asd.utility.plot_tools_3d import *
from asd.utility.spin_visualize_tools import *
from spirit import state,io,log,system,parameters
from spirit import geometry,configuration,hamiltonian
from test_Gaussian_ham import *


nx=1
ny=1

quiet=True

nphi=100
ntheta=50
thetas,phis,Rvec = gen_grid_points_on_sphere(nphi,ntheta)
eners = np.zeros((ntheta,nphi)) 
params = gen_params_for_ovf(1,1,1)
fil_ovf = 'theta_phi.ovf'

H = gen_gaussian_field_on_sphere(params_3,nphi,ntheta,gaussian_method=1)

if __name__=='__main__':
    os.system('rm -r output* Log.txt 2>/dev/null')
    os.mkdir('output')

    with state.State('input.cfg',quiet=quiet) as p_state:
        geometry.set_n_cells(p_state,[nx,ny,1])
        hamiltonian.set_boundary_conditions(p_state, [0,0,0])

        for ii,jj in np.ndindex(ntheta,nphi):
            conf = np.zeros((1,1,1,3))
            conf[0,0,0] = Rvec[:,ii,jj]
            spins = conf.reshape(-1,3)
            write_ovf(params,spins,fil_ovf)             
            io.image_read(p_state, fil_ovf)
            system.update_data(p_state)
            eners[ii,jj] = system.get_energy(p_state)

    #map_sphere_on_2d(eners,show=False,cmap='rainbow')
    #map_sphere_on_2d(H,show=True,cmap='rainbow')

    map_sphere_on_2d_Kavrayskiy(eners,show=False)
    map_sphere_on_2d_Kavrayskiy(H,show=True)

    #map_3d_surface(eners,show=False,cmap='viridis')
    #map_3d_surface(H,show=True,cmap='viridis')
