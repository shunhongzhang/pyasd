#!/usr/bin/env python3

import os
import numpy as np
from asd.core.log_general import log_general
from asd.core.hamiltonian import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import exchange_shell
from asd.core.spin_configurations import *
from asd.core.llg_simple import llg_solver
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt

nx=3
ny=3
nz=3
lat_type='simple cubic'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]
Bfield=np.array([0,0,0])
temp_list = np.arange(1,51,5)


S_values = np.ones(1)
SIA = np.ones(1)*0.1
exch_1 = exchange_shell(neigh_idx[0], np.ones(1), shell_name='1NN')


log_handle = log_general(
n_log_conf=500,
n_log_magn=100,
)

kwargs = dict(
S_values=S_values,
alpha=0.1,
dt=1e-2,
log_handle=log_handle,
)


if __name__=='__main__':
    sp_lat = np.zeros((nx,ny,nz,nat,3),float)

    ham = spin_hamiltonian(
    Bfield=Bfield,S_values=S_values,BL_SIA=[SIA],
    BL_exch = [exch_1],
    iso_only=True,boundary_condition=[1,1,1])

    for temperature in temp_list:
        kwargs.update(  temperature = temperature )
        LLG = llg_solver(**kwargs)
        #LLG.mpi_llg_simulation(ham,sp_lat)
        LLG.mpi_llg_simulation_shared_memory(ham,sp_lat)
