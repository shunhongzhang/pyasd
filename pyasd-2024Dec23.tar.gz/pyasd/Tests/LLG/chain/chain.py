#!/usr/bin/env python

from asd.core.shell_exchange import *
from asd.core.geometry   import *
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.spin_configurations import *
import numpy as np
import matplotlib.pyplot as plt
import asd.mpi.mpi_tools as mt

nx=24
latt,sites = build_latt('square',nx,1,1,return_neigh=False)

S_values = np.array([1./2])
SIA = np.zeros(1)
J1_iso = np.zeros(1)
J1_sym = - np.eye(3)
J1_sym_xyz = np.array([[J1_sym,J1_sym]])
DM1_xyz = np.zeros((1,2,3))
Kitaev1_mag = np.zeros(1)
Kitaev1_xyz = np.zeros((1,2,3))
neigh_idx[0] = np.array([[[-1,0,0],[1,0,0]]])

b=1/muB/(S_values[0]*2)*3
H = np.array([0,0,1])*b

exch_1 = exchange_shell( neigh_idx[0], J1_iso, J1_sym_xyz, DM1_xyz, Kitaev1_mag, Kitaev1_xyz, '1NN')

ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_exch=[exch_1],exchange_in_matrix=True)

LLG = llg_solver(nstep=50000)
comm,size,rank,node = mt.get_mpi_handles()

if __name__=='__main__':
    sp_lat = np.zeros((nx,1,1,3))
    if not rank: sp_lat = init_random(sp_lat)
    sp_lat = comm.bcast(sp_lat)
    LLG.mpi_llg_simulation(ham,sp_lat)
