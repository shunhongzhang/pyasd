#!/usr/bin/env python3

import numpy as np
from asd.core.hamiltonian import *
from asd.core.llg_simple import *
from asd.core.geometry import build_latt
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.spin_configurations import *
import asd.mpi.mpi_tools as mt

lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,1,1,1)
nat = sites.shape[-2]
S_values = np.ones(1)*0.5 # S=1/2, M = 1 muB
SIA = np.ones(1)*0.2

# in our convention, negative for AFM, positive for FM
J1_iso = np.ones(1)
exch_1 = exchange_shell( neigh_idx[0], J1_iso, shell_name='1NN')

nx=30
ny=30
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)

kwargs = dict(
temperature=1,
alpha=0.3,
dt=1e-2,
nstep=40000,
S_values=S_values,
lat_type=lat_type,
n_log_conf=4000,
n_log_magn=400,
conv_ener=1e-8,
damping_only=False,
log_topo_chg=False,
thermal_field_method=1)


if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    sp_lat = np.zeros((nx,ny,nat,3),float)
    #if not rank:  sp_lat = init_random(sp_lat)
    #sp_lat = comm.bcast(sp_lat,root=0)
    sp_lat[...,2] = 1

    ham = spin_hamiltonian(
    S_values=S_values,
    BL_SIA=[SIA],
    BL_exch = [exch_1],
    iso_only=True)

    LLG = llg_solver(**kwargs)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
