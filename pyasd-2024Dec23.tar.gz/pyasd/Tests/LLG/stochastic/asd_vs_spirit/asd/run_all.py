#!/usr/bin/env python

import numpy as np
import os
import re

temp_list = np.arange(1,15)
ntemp = len(temp_list)

if __name__=='__main__':
    lines = open('llg.py').readlines()
    idx = np.where([re.search('temperature',line) for line in lines])[0][0]
    temp_line = lines[idx].rstrip('\n')
    for itemp in range(ntemp):
        temp = temp_list[itemp]
        cdir = 'temp_{}'.format(itemp)
        os.mkdir(cdir)
        os.system('cp llg.py job.sh {}'.format(cdir))
        os.chdir(cdir)
        repl = 'sed -i "s/{}/temperature={:.2f},/g" llg.py'.format(temp_line,temp)
        os.system(repl)
        os.system('chmod +x llg.py')
        #os.system('sbatch job.sh')
        os.system('./llg.py > temp_{}.out &'.format(itemp))
        os.chdir('..')
