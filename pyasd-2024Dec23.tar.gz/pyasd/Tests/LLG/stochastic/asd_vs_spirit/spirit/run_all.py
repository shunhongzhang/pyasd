#!/usr/bin/env python

import numpy as np
import os
import sys
import asd.mpi.mpi_tools as mt

temp_list = np.arange(1,25,2)
ntemp = len(temp_list)

comm,size,rank,node = mt.get_mpi_handles()
start,last = mt.assign_task(ntemp,size,rank)

if __name__=='__main__':
    for itemp in range(start,last):
        temp = temp_list[itemp]
        cdir = 'temp_{}'.format(itemp)
        print ('rank {} works on {}'.format(rank,cdir))
        sys.stdout.flush()
        os.mkdir(cdir)
        os.system('cp llg.py temp_{}'.format(itemp))
        os.chdir(cdir)
        repl = 'sed -i "s/temp=1/temp={:.2f}/g" llg.py'.format(temp)
        os.system(repl)
        os.system('chmod +x llg.py')
        os.system('./llg.py > mylog &') 
        os.chdir('..')
