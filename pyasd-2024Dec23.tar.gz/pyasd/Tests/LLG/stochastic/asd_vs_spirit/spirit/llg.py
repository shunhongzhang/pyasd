#!/usr/bin/env python

#===============================================
#
# Simulate the exchange bias effect
# Shunhong Zhang <szhang2@ustc.edu.cn>
# Jun 13 2021
#
#================================================

from spirit import io,log,state,geometry,system,hamiltonian,simulation,parameters,configuration
import os
import numpy as np

#if not os.path.isdir('output'): os.mkdir('output')

SIA = 0.2
J1 = 1
nx=30
ny=30

# for Single-ion anisotropy (SIA)
# negative (positive) favors in-plane (out-of-plane)
#SIA = 0.021

temp=1


if __name__=='__main__':
    with state.State() as p_state:
        geometry.set_n_cells(p_state, [nx, ny, 1])
        hamiltonian.set_boundary_conditions(p_state,[1,1,0])
        hamiltonian.set_exchange(p_state, 1, [J1])
        hamiltonian.set_anisotropy(p_state, SIA, [0,0,1])
        configuration.random(p_state)
        tag = 'temp_{:.2f}'.format(temp)
        parameters.llg.set_output_tag(p_state, tag)
        parameters.llg.set_output_folder(p_state, '.')
        parameters.llg.set_iterations(p_state, 100000, 1000)
        parameters.llg.set_output_configuration(p_state, 0, 1, 3)
        parameters.llg.set_output_energy(p_state, 0, 1)
        parameters.llg.set_output_general(p_state, 1, 0, 0)
        parameters.llg.set_temperature(p_state, temp)
        parameters.llg.set_damping(p_state, 0.2)
        parameters.llg.set_timestep(p_state, 0.01)
        system.update_data(p_state)
        simulation.start(p_state, simulation.METHOD_LLG, simulation.SOLVER_DEPONDT)
