Test stochastic LLG simulations
with finite temperature

The temperature effect is simulated by a stochastic field
added to the ordinary Zeeman field
Technically it is realized by exerting a white noise at
each of the three Cartersian directions of each spin site


Specifically, here we use a square lattice 
with nearest FM coupling and a small single-ion anisotropy
simulate the temperature dependent magnetization
and the magnetic phase transition


============================================
!!!!!!!!!!!!! Important Note !!!!!!!!!!!!!!

for the pyasd code, a large alpha (damping parameter)
is required to overcome the energy barrier at low temperature
and converge the spin configuration to the FM state

This could lead to underestimation of transition temperature
A possible way to mitigate such problem is performing a two-step simulation
i.e. at each temperature first run a large-alpha simulation to 
reach equilibrium and then a small-alpha simulation for sampling
