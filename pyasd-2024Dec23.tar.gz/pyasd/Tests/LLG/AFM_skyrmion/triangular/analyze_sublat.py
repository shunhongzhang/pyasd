#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import *
from llg import *

fil = 'final_spin_confs.ovf'
spins = parse_ovf(fil)[1]
print(nat)
sp_lat = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)
sites_cart = np.dot(sites,latt)
iat = 0
plot_spin_2d(sp_lat[:,:,iat],sites_cart[:,:,iat],show=True,title='sublat {}'.format(iat))
