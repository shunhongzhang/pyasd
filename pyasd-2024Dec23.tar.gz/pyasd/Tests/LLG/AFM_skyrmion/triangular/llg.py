#!/usr/bin/env python

# antiferromagnetic skyrmion lattice
# stabilized by nearest Heisenberg exchange and DM interactions
# Reference: 
# Rosales et al. Phys. Rev. B 92, 214439 (2015),  Bloch-type DM
# Diaz et al. Phys. Rev. Lett. 122, 187203 (2019), Neel-type DM
#
# by Shunhong Zhang
# szhang2@ustc.edu.cn
# Nov 12 2021


import asd.mpi.mpi_tools as mt
import numpy as np
from asd.utility.spin_visualize_tools import plot_spin_2d
from asd.core.log_general import log_general
from asd.core.spin_configurations import *
from asd.core.geometry import build_latt
from asd.core.hamiltonian import *
from asd.core.llg_simple  import *
from asd.core.shell_exchange import *
from asd.core.constants import *
from scipy.spatial.transform import Rotation as RT


lat_type='triangular'
nx=7
ny=7
nz=1
data = build_latt(lat_type,nx,ny,nz,return_neigh=True)
latt,sites,neigh_idx,rotvecs = data
nat=sites.shape[2]

H = np.array([0,0,1])*2.5/muB/2
S_values = np.ones(1)
SIA = np.ones(1)*0.
J1_iso = -np.ones(1)

# DM vector is Neel-type! normal to the bond
DM1_rpz = -np.array([[0,1,0]])*0.5
vecs = np.array([[0,0,i] for i in range(6)])*np.pi/3
mats = RT.from_rotvec(vecs).as_matrix()
DM1_xyz = np.dot(mats,DM1_rpz.T).reshape(1,6,3)
exch_1 = exchange_shell(neigh_idx[0], J1_iso, DM_xyz=DM1_xyz, shell_name='1NN')

ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_SIA=[SIA],BL_exch=[exch_1],iso_only=True)

log_handle = log_general(
n_log_conf=500,
n_log_magn=500,
)

llg_kwargs = dict(
alpha=0.1,
dt=1e-2,
nstep=40000,
S_values=S_values,
temperature=0,
lat_type=lat_type,
conv_ener=1e-8, 
damping_only=True,
log_handle = log_handle)

LLG = llg_solver(**llg_kwargs)

comm,size,rank,node = mt.get_mpi_handles()

if __name__=='__main__':
    sp_lat = np.zeros((nx,ny,nat,3),float)
    if not rank: sp_lat = init_random(sp_lat)
    sp_lat = comm.bcast(sp_lat)

    LLG.mpi_llg_simulation(ham,sp_lat)
