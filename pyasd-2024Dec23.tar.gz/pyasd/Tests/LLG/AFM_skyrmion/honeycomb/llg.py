#!/usr/bin/env python

# antiferromagnetic skyrmion lattice
# stabilized by nearest Heisenberg exchange and DM interactions
# Shunhong Zhang
# szhang2@ustc.edu.cn
# Nov 12 2021


import asd.mpi.mpi_tools as mt
import numpy as np
from asd.utility.spin_visualize_tools import plot_spin_2d
from asd.core.log_general import log_general
from asd.core.spin_configurations import *
from asd.core.geometry import build_latt
from asd.core.hamiltonian import *
from asd.core.llg_simple  import *
from asd.core.shell_exchange import *


def AFM_energy(ham):
    print (ham._H)
    for idir in range(3):
        sp_lat = np.zeros((1,1,2,3),float)
        sp_lat[:,:,0,idir] = 1
        sp_lat[:,:,1,idir] = -1
        en = ham.calc_total_E(sp_lat)/2
        print ('dir {}, en = {:10.5} meV/site'.format(idir,en))

lat_type='honeycomb'
nx=10
ny=10
nz=1
data = build_latt(lat_type,nx,ny,nz,return_neigh=True)
latt,sites,neigh_idx,rotvecs = data
nat=sites.shape[2]
skyr_radius=4

H = np.array([0,0,1])*0.2
S_values = np.ones(2)
SIA = np.ones(2)*0.
J1_iso = -np.ones(2)
DM1_rpz = np.array([[0,1,0],[0,-1,0]])*0.5
DM1_xyz = get_exchange_xyz(DM1_rpz,rotvecs[0])
exch_1 = exchange_shell(neigh_idx[0], J1_iso, DM_xyz=DM1_xyz, shell_name='1NN')

ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_SIA=[SIA],BL_exch=[exch_1],iso_only=True)

AFM_energy(ham)
exit()

log_handle = log_general(
n_log_conf=500,
n_log_magn=500,
)

llg_kwargs = dict(
alpha=0.1,
dt=1e-2,
nstep=20000,
S_values=S_values,
temperature=0,
lat_type=lat_type,
conv_ener=1e-8, 
damping_only=True,
log_handle=log_handle)

LLG = llg_solver(**llg_kwargs)

comm,size,rank,node = mt.get_mpi_handles()

if __name__=='__main__':
    sp_lat = np.zeros((nx,ny,nat,3),float)
    sp_lat[:,:,:1] = init_spin_latt_skyrmion(sp_lat[:,:,:1],latt,sites[:,:,:1],skyr_radius,sk_type='Bloch')
    sp_lat[:,:,1:] = -sp_lat[:,:,:1]
    sites_cart = np.dot(sites,latt)
    quiver_kws = dict(scale=1.2,units='x',pivot='mid',headwidth=4,headaxislength=4)
    if not rank: plot_spin_2d(sites_cart,sp_lat,show=True,scatter_size=30,title='honeycomb AFM-skyrmion',latt=latt,quiver_kws=quiver_kws)

    LLG.mpi_llg_simulation(ham,sp_lat)
