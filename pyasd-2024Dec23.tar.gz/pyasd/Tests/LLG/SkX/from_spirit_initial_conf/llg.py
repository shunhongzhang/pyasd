#!/usr/bin/env python3

import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.log_general import log_general
from asd.core.llg_simple import *
from asd.core.geometry import build_latt
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.data_base.exchange_for_skx import *
import asd.mpi.mpi_tools as mt

nx=20
ny=20
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[2]

Bfield=np.array([0,0,2])

log_handle = log_general(
n_log_conf=5000,
n_log_magn=1000,
log_topo_chg=True,
)

kwargs=dict(
alpha=0.1,
temperature=0.,
dt=1e-3,
S_values=S_values,
nstep=200000,
conv_ener=1e-10,
latt=latt,
sites=sites,
log_handle = log_handle,
)

ham = spin_hamiltonian(Bfield=Bfield,
S_values=S_values,
BL_SIA=[SIA],
BL_exch=[exch_1])


if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    sp_lat = np.zeros((nx,ny,nat,3),float)
    if not rank:  
        spins = parse_ovf('Spirit_initial.ovf1')[1]
        sp_lat = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)
    sp_lat = comm.bcast(sp_lat,root=0)

    LLG = llg_solver(**kwargs)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
