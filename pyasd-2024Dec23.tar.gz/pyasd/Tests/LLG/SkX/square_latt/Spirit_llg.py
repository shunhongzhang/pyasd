#!/usr/bin/env python3

import os
import sys
import time
import numpy as np

from spirit import state
from spirit import configuration
from spirit import simulation
from spirit import io
from spirit import quantities
from spirit import parameters
from spirit import hamiltonian
from spirit import system



cfgfile = "input.cfg"
if not os.path.isdir('output'): os.mkdir('output')
quiet = False
stime=time.time()

Hmax =  10
Hstep = 2
H1 = np.arange(Hmax, -Hmax-0.01, -Hstep)
H_list = np.append(H1[:-1], H1[::-1])
#print (H_list)

if __name__=='__main__':
    with state.State(cfgfile, quiet) as p_state:
        ### Read Image from file
        # spinsfile = "input/spins.ovf"
        # io.image_from_file(state.get(), spinsfile, idx_image=0);

        ### First image is homogeneous with a skyrmion in the center
        configuration.random(p_state, idx_image=0)
        #configuration.skyrmion(p_state, 5.0, phase=-90.0, idx_image=0)
        #tc = quantities.get_topological_charge(p_state)
        #print ('topological charge=',tc)

        parameters.llg.set_output_configuration(p_state, False, False, 3)

        ### LLG dynamics simulation
        LLG = simulation.METHOD_LLG
        DEPONDT = simulation.SOLVER_DEPONDT

        for iH, H in enumerate(H_list):
            cdir = 'H_{}'.format(iH)
            os.mkdir(cdir)
            parameters.llg.set_output_folder(p_state, cdir)
            hamiltonian.set_field(p_state, H, [0,0,1])
            system.update_data(p_state)
            simulation.start(p_state, LLG, DEPONDT)

    print ('Time used: {:10.5f} s'.format(time.time()-stime))
