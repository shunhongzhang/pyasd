#!/usr/bin/env python

import numpy as np
from asd.core.geometry import build_latt
from asd.utility.ovf_tools import parse_ovf
from asd.utility.spin_visualize_tools import *
from Spirit_llg import *


nx=16
ny=16
latt, sites = build_latt('square', nx, ny, 1, latt_const=1, return_neigh=False)
sites_cart = np.dot(sites, latt)
nat = sites.shape[-2]

if os.path.isdir('ovfs'): os.system('rm -r ovfs')
os.mkdir('ovfs')

kws = dict(
quiver_kws=quiver_kws,
colorbar_shrink=0.5,
colorbar_orientation='vertical',
scatter_size=50,
show=True,
#latt=latt,
)
mags = np.zeros((len(H_list),3))

count=0
for iH, H in enumerate(H_list):
    cdir = 'H_{}'.format(iH)
    fil_ovf = '{}/skx_Image-00_Spins-final.ovf'.format(cdir)
    if os.path.isfile(fil_ovf)==False: continue
    else: count += 1
    os.system('cp {} ovfs/spin_confs_{}.ovf'.format(fil_ovf, iH))
    params, spins = parse_ovf(fil_ovf)
    mags[iH] = np.average(spins,axis=0)
    print ('{:3d} {:6.3f} {:10.5f}'.format(iH, H, mags[iH,2]))
    sp_lat = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)    
    if iH==7:
        plot_spin_2d(sites_cart, sp_lat, **kws) 



#exit()
fig, ax = plt.subplots(1,1)
ax.plot(H_list[:count], mags[:count,2])
ax.set_xlabel('H')
ax.set_ylabel('M')
fig.tight_layout()
plt.show()
