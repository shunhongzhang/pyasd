#!/usr/bin/env python

from asd.core.shell_exchange import *
from asd.core.log_general import *
from asd.core.geometry   import *
from asd.core.hamiltonian import *
from asd.core.llg_simple import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
import numpy as np
import matplotlib.pyplot as plt
import asd.mpi.mpi_tools as mt



# exchange following Phys. Rev. Lett. 122, 147202 (2019)
# exchange stiffness A = 13 pJ/m
# lattice constant = 2 nm
# Ms = 800 kA/m * 
# J = 13*1e-12/2e9 * e 
def gen_exchange_1D(A=13):
    J = 13*1e-12/2e9 * e_chg
    J1_iso = np.zeros(1)
    J1_sym = np.eye(3)*A
    

def build_Walker_DW(sites,latt,width=10,show=False):
    X = nx/2.
    sp_lat = np.zeros((nx,ny,nat,3))
    sites_cart = np.dot(sites,latt)
    sp_lat[...,0] = - np.tanh((sites[...,0]-X)/width*latt[0,0])
    sp_lat[...,1] = 1/np.cosh((sites[...,0]-X)/width*latt[0,0])

    sites_plot = np.swapaxes(np.dot(sites,latt),0,1)
    spins_plot = np.swapaxes(sp_lat,0,1)

    quiver_kws = dict(units='x',pivot='mid',scale=0.8,headwidth=6)

    plot_spin_2d(sites_plot, spins_plot, scatter_size=10,
    colorbar_orientation='horizontal',show=show,height_ratios=(4,1),quiver_kws=quiver_kws)

    return sp_lat

def plot_spinwave(Kx=47,Kz=50,Ms=800,A=13,):
    k=np.linspace(-30,30,201)
    f = (gamma_e/np.pi/Ms)*np.sqrt((Kx+A*k**2)*(Kx+Kz+A*k**2))
    fig, ax = plt.subplots(1,1)
    ax.plot(k,f)
    plt.show()
    return f

nx=24
ny=1
latt,sites = build_latt('square',nx,ny,1,return_neigh=False)
nat=sites.shape[-2]


Bfield=np.zeros(3)
S_values = np.array([1./2])
SIA = np.zeros(1)
J1_iso = np.zeros(1)
J1_sym = np.eye(3)
J1_sym_xyz = np.array([[J1_sym,J1_sym]])
D=-0.2
DM1_xyz = np.array([[[0,0,-D],[0,0,D]]])
neigh_idx[0] = np.array([[[-1,0,0],[1,0,0]]])

#b=1/muB/(S_values[0]*2)*3
#H = np.array([0,0,1])*b
exch_1 = exchange_shell(neigh_idx[0], J1_iso, J1_sym_xyz, DM1_xyz, shell_name = '1NN')

ham =  spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_exch=[exch_1],boundary_condition=[0,1,0])

LLG = llg_solver(nstep=50000,log_handle=log_handle)

#sp_lat = build_Walker_DW(sites,latt,show=show)
sp_lat = np.zeros((nx,ny,nat,3))
nn=nx//3
sp_lat[:nn,...,0] = 1.
sp_lat[nn:nn*2,...,1] = 1.
sp_lat[nn*2:,...,0] = -1.

if __name__=='__main__':
    LLG.mpi_llg_simulation(ham,sp_lat)
