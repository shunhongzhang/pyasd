#!/usr/bin/env python3

import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.data_base.exchange_for_NiI2 import *
from asd.core.geometry import build_latt
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt
from a2sk import build_multi_a2sk

nx=24
ny=24
lat_type='triangular'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[2]
Bfield=np.array([0,0,0])

log_handle = log_general(
outdir='Spin_dynamics',
n_log_conf=500,
n_log_magn=100,
)

llg_kws=dict(
S_values=S_values,
alpha=0.1,
dt=5e-3,
nstep=50000,
temperature=0,
conv_ener=1e-8,
log_handle=log_handle,
start_conf='from_input',
)

if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    sp_lat = np.zeros((nx,ny,nat,3),float)
    #if not rank:  sp_lat = build_multi_a2sk(nx,ny,2.8)
    #sp_lat = comm.bcast(sp_lat,root=0)

    data = np.loadtxt('../spins_A2SK.dat1',skiprows=1)[:,3:].reshape(24,24,-1)
    a2sk_conf = np.swapaxes(data,0,1).reshape(nx,ny,nat,3)
    sp_lat = a2sk_conf

    ham = spin_hamiltonian(
    Bfield=Bfield,
    S_values=S_values,
    BL_SIA=[SIA],
    BL_exch = [exch_1, exch_2, exch_3],
    exchange_in_matrix = True)

    #en = ham.calc_total_E(a2sk_conf)
    #print ('Energy of A2sk configuration = {:10.5f} meV/site'.format(en))

    LLG = llg_solver(**llg_kws)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation_shared_memory(ham,sp_lat)
