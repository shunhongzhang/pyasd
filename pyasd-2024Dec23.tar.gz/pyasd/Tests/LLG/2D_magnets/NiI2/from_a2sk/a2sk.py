#!/usr/bin/env python

#=================================
#
# This example demonstrates
# how to create multiple
# topological magnetic solitons
# in a single supercell
# some tricky use of function
# init_spin_latt_skyrmion
# is shown by the plots
# MIND the overlape of two 
# anti-biskyrmions (a2sk)
#
#==================================
#
# Shunhong Zhang
# shang2@ustc.edu.cn
#
#==================================

import numpy as np
from asd.core.spin_configurations import *
from asd.core.topological_charge import calc_topo_chg
from asd.core.geometry import *
from asd.utility.spin_visualize_tools import *


nx=8
ny=8
radius=2.8


def build_multi_a2sk(nx,ny,radius,show=False):
    latt,sites = build_latt('triangular',nx,ny,1,return_neigh=False)
    nat = sites.shape[2]
    sites_cart = np.dot(sites,latt)

    sp_lat0 = np.zeros((nx,ny,nat,3))
    kwargs = dict(winding=-2,vorticity=1,helicity=0,return_skyr_idx=True)
    sp_lat1,idx1 = init_spin_latt_skyrmion(sp_lat0,latt,sites,radius,center_pos=[-1.5,1.5],**kwargs)
    sp_lat2,idx2 = init_spin_latt_skyrmion(sp_lat0,latt,sites,radius,center_pos=[1.5,-1.5],**kwargs)

    sp_lat = np.zeros((nx,ny,nat,3))
    sp_lat[...,2] = 1.
    for ii in idx1: sp_lat[tuple(ii)] = sp_lat1[tuple(ii)]
    for ii in idx2: sp_lat[tuple(ii)] = sp_lat2[tuple(ii)]

    Q=calc_topo_chg(sp_lat,sites_cart)
    print ('Q={:4.2f}'.format(Q))
    kws = dict(show=False, 
    superlatt = np.dot(np.diag([nx,ny]),latt),
    scatter_size=30, 
    colorbar_axes_position=[0.8,0.6,0.02,0.2],
    colorbar_orientation='vertical')

    plot_spin_2d(sites_cart,sp_lat1,title='sp_lat: 1',   **kws)
    plot_spin_2d(sites_cart,sp_lat2,title='sp_lat: 2',   **kws)
    plot_spin_2d(sites_cart,sp_lat ,title='sp_lat: 1+2', **kws)

    if show: plt.show()
    return sp_lat


if __name__=='__main__':
    build_multi_a2sk(nx,ny,radius,show=True)
