#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from asd.core.geometry import build_latt
from asd.utility.spin_visualize_tools import *


nx=24
ny=24
lat_type='triangular'

latt,sites = build_latt(lat_type, nx,ny,1,return_neigh=False,vacuum=True)
sites_cart = np.dot(sites, latt)

fil = 'spins_A2SK.dat1'
data = np.loadtxt(fil,skiprows=1)[:,3:].reshape(ny,nx,-1)
sp_lat = np.swapaxes(data,0,1)

print (sp_lat.shape)

spin_plot_kws=dict(
superlatt=np.dot(np.diag([nx,ny,1]),latt),
scatter_size=30,
colorbar_axes_position=[0.7,0.6,0.02,0.2],
colorbar_orientation='vertical',
title='anti-biskyrmion of NiI2',
show=True)

plot_spin_2d(sites_cart, sp_lat, **spin_plot_kws)

