#!/usr/bin/env python3

import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.log_general import log_general
from asd.core.llg_simple import *
from asd.data_base.exchange_for_MnI2 import *
from asd.core.geometry import build_latt
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
import asd.mpi.mpi_tools as mt

nx=9
ny=9
lat_type='triangular'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[2]
Bfield=np.array([0,0,1])

log_handle = log_general(
n_log_conf=1000,
n_log_magn=500,
log_topo_chg=True,
outdir='MnI2',
)


if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    sp_lat = np.zeros((nx,ny,nat,3),float)
    if not rank:  sp_lat = init_random(sp_lat)
    sp_lat = comm.bcast(sp_lat,root=0)

    ham_kws = dict(
    Bfield=Bfield,
    S_values=S_values,
    BL_SIA=[SIA],
    BL_exch = [exch_1,exch_2,exch_3],
    exchange_in_matrix = True)

    #ham = spin_hamiltonian(**ham_kws)
    ham = build_ham(Bfield=Bfield)

    kwargs = dict(alpha=0.1,
    dt=5e-3,
    nstep=500,
    S_values=S_values,
    temperature=0,
    lat_type=lat_type,
    conv_ener=1e-8, damping_only=False,latt=latt,sites=sites,
    log_handle=log_handle)

    LLG = llg_solver(**kwargs)
    
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
