#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from asd.core.hamiltonian import spin_hamiltonian
from asd.data_base.exchange_for_RuCl3 import *


theta_step=60
phi_step=60
thetas,phis = np.mgrid[0:180.01:theta_step,0:360.01:phi_step]
ntheta,nphi = thetas.shape
thetas = thetas.flatten()
phis    = phis.flatten()
nn = len(thetas)
ens_map = np.zeros(nn,float)

c1 = np.cos(np.deg2rad(thetas))
s1 = np.sin(np.deg2rad(thetas))
c2 = np.cos(np.deg2rad(phis))
s2 = np.sin(np.deg2rad(phis))
Rvec = np.array([s1*c2,s1*s2,c1]).T
J3=0


sp_lat = np.zeros((2,2,2,3))

for ian in range(nn):
    J1,K1,Gamma1  = Rvec[ian]
    analytic_E = get_analytic_E(J1,K1,Gamma1,J3)
    conf_names = analytic_E.keys()

    exch_1,exch_3 = gen_shell_exchange(J1,K1,Gamma1,J3)
    ham = spin_hamiltonian(Bfield=np.zeros(3),S_values=S_values,BL_SIA=[SIA],
    BL_exch = [exch_1],
    exchange_in_matrix=True,spin_coord=Kitaev_XYZ)

    kwargs=dict(show=False,display_mode=None)

    for conf_name in conf_names:
        if 'FM' not in conf_name: continue
        magmom = gen_collinear_magmom(conf_name)
        #min_theta,min_phi,min_en = ham.map_MAE_3d(sp_lat,collinear_magmom=magmom,**kwargs)
        min_en = 0
        print (('{:10.5f} '*4+'{:>15s}').format(J1,K1,Gamma1,min_en,conf_name))
