#!/usr/bin/env python

from __future__ import print_function
import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.log_general import *
from asd.core.geometry import build_latt

def analytic_solution(alpha,H,t):
    H_mag = np.linalg.norm(H)
    phi = gamma_e/(1+alpha**2)*H_mag*t
    n_z = np.tanh(alpha*gamma_e/(1+alpha**2)*H_mag*t)
    n_x = np.cos(phi)*np.sqrt(1-n_z**2)
    return n_x,n_z

def plot_spin_evolve(alpha,llg_time,spin_evolve,H):
    import matplotlib.pyplot as plt
    n_x,n_z=analytic_solution(alpha,H,llg_time)
    fig,ax=plt.subplots(1,1)
    ax.plot(llg_time,spin_evolve[:,0],label='$n_x$')
    ax.plot(llg_time,spin_evolve[:,2],label='$n_z$')
    ax.plot(llg_time,n_x,'m-',lw=10,alpha=0.4,zorder=-1,label='$n_x^{analytic}$')
    ax.plot(llg_time,n_z,'g-',lw=10,alpha=0.4,label='$n_z^{analytic}$')
    ax.axhline(0,c='gray',ls='--',alpha=0.5,zorder=-1)
    ax.axhline(1,c='gray',ls='--',alpha=0.5,zorder=-1)
    ax.set_xlabel('Time (ps)')
    ax.legend()
    plt.show()
    return fig


nx=1
ny=1
nz=1
nat=1

Bfield=np.array([0,0,10])
S_values=np.array([0.5])
SIA=np.zeros(1)

alpha=0.1
lat_type='square'
dt=1e-3
nstep=50000

log_handle = log_general(
n_log_conf=500,
n_log_magn=500,
)

latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)

nat=sites.shape[2]

if __name__=='__main__':
    ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_SIA=[SIA])

    LLG = llg_solver(alpha=alpha,dt=dt,nstep=nstep,S_values=S_values,
    conv_ener=1e-14,
    temperature=0,lat_type=lat_type,
    damping_only=True,
    log_handle=log_handle)

    sp_lat=np.zeros((nx,ny,nat,3),float)
    sp_lat[...,0]=1.

    # run one of the following three lines
    #log_time,log_ener,log_conf = LLG.llg_simulation(ham,sp_lat)
    #log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)


    spin_evolve = np.average(log_conf,axis=(1,2))[:,0]
    fig = plot_spin_evolve(alpha,log_time,spin_evolve,H)
