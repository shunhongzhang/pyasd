#!/usr/bin/env python

# this script is still under test

import numpy as np
import asd.mpi.mpi_tools as mt
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.log_general import *
from asd.core.llg_simple import *
from asd.core.spin_configurations import *
from asd.core.topological_charge import get_tri_simplices
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *

nx=4
ny=4
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]

S_values=np.array([1])
SIA=np.array([0])
J1_iso = np.array([0.1])
Bfield=np.array([0,0,0])

alpha=0.1
temp=0
dt=1e-2

log_handle = log_general(
n_log_conf=1000,
n_log_magn=500,
log_topo_chg=True,
tri_simplices = get_tri_simplices(np.dot(sites,latt)),
)

nstep=40000


exch_1 = exchange_shell( neigh_idx[0], J1_iso, shell_name = '1NN')


if __name__=='__main__':
    sp_lat = np.zeros((nx,ny,nat,3))
    comm,size,rank,node = mt.get_mpi_handles()

    if not rank:    
        pinned_idx = np.array([[1,1,0],[1,2,0],[2,1,0],[2,2,0]])
        sp_lat = init_random(sp_lat)
        for (ix,iy,iat) in pinned_idx: 
            sp_lat[ix,iy,iat] = [0,0,1]
    else:
        pinned_idx = None
    pinned_idx = comm.bcast(pinned_idx)
    sp_lat = comm.bcast(sp_lat)

    ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_SIA=[SIA],
    BL_exch=[exch_1],iso_only=True)

    kwargs = dict(
    S_values=S_values,
    alpha=alpha,dt=dt,nstep=nstep,
    temperature=temp,
    lat_type=lat_type,
    conv_ener=1e-8,
    latt=latt, sites=sites,
    log_handle = log_handle)

    LLG = llg_solver(**kwargs)

    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat,pinned_idx=pinned_idx)
