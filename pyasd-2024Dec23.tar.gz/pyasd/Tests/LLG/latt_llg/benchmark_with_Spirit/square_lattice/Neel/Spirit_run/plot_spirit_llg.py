#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import *
from spirit import state,system,geometry
import glob
import matplotlib.pyplot as plt

with state.State('output_square.cfg',quiet=True) as p_state:
    pos=geometry.get_positions(p_state)
    nx,ny,nz=geometry.get_n_cells(p_state)
    nat=geometry.get_n_cell_atoms(p_state)
    latt=geometry.get_bravais_vectors(p_state)


outdir='output'
fil_en = glob.glob('{}/*Energy-archive.txt'.format(outdir))[0]
lines = open(fil_en).readlines()[3:]
en = np.array([line.split()[::2] for line in lines],float)
fil_ovf=glob.glob('{}/*initial.ovf'.format(outdir))[0]
spins_init=parse_ovf(fil_ovf)[1]
fil_ovf=glob.glob('{}/*final.ovf'.format(outdir))[0]
spins_final=parse_ovf(fil_ovf)[1]

kwargs = dict(scatter_size=30,quiver_kws=quiver_kws,colorful_quiver=False)
#plot_spin_2d(pos,spins_init, title='initial',**kwargs)
#plot_spin_2d(pos,spins_final,title='final'  ,show=True,**kwargs)

time_step=0.001
n_log_iteration=2000

print ('Energy of final conf = {:10.5f} meV'.format(en[-1,1]))
llg_times = time_step*en[:,0]
fig,ax=plt.subplots(1,1)
ax.plot(llg_times,en[:,1])
ax.set_xlabel('t (ps)')
ax.set_ylabel('E (meV)')
fig.tight_layout()
plt.show()

fil = glob.glob('{}/*Spins-archive.ovf'.format(outdir))[0]
confs = parse_ovf(fil,parse_params=False)[1]
times = np.arange(len(confs))*time_step*n_log_iteration
titles=['t = {:5.2f} ps'.format(tt) for tt in times]
make_ani(pos,confs,scatter_size=30,titles=titles)
