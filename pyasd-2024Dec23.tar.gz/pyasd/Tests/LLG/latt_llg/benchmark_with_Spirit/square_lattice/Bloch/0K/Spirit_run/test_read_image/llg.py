#!/usr/bin/env python

import os
import sys
import numpy as np

from spirit import state,io,log,system,parameters
from spirit import geometry,configuration,hamiltonian
from spirit import simulation,quantities
from asd.utility.spirit_tool import verbose_quantities

nx=20
ny=nx

skyr_name="skyrmion-Neel"
phase=90

achiral=False
quiet=False

if __name__=='__main__':
    os.system('rm -r output* Log.txt 2>/dev/null')
    os.mkdir('output')

    with state.State(quiet=quiet) as p_state:
        geometry.set_n_cells(p_state,[nx,ny,1])
        geometry.set_mu_s(p_state,2)

        io.image_read(p_state,'../output/sqr_skyrmion_Image-00_Spins-final.ovf')

        hamiltonian.set_boundary_conditions(p_state, [1,1,0])
        hamiltonian.set_anisotropy(p_state, 0.5, [0,0,1])
        hamiltonian.set_exchange(p_state, 1, [1])
        hamiltonian.set_dmi(p_state, 1, [0.6], chirality=-1)
        hamiltonian.set_field(p_state, 0, [0,0,1])

        parameters.llg.set_iterations(p_state, 80000, 1000)
        parameters.llg.set_output_tag(p_state,'sqr_skyrmion')
        parameters.llg.set_output_folder(p_state, 'output')
        parameters.llg.set_output_configuration(p_state, False, True, 3)
        parameters.llg.set_output_general(p_state,1,1,1)
        parameters.llg.set_output_energy(p_state,0,1,0,1,1)

        system.update_data(p_state)
        verbose_quantities(p_state,'output/'+skyr_name+'-initial')

        ### LLG dynamics simulation
        LLG = simulation.METHOD_LLG
        DEPONDT = simulation.SOLVER_DEPONDT
        simulation.start(p_state, LLG, DEPONDT)
        state.to_config(p_state,'output_square.cfg')
        verbose_quantities(p_state,'output/'+skyr_name+'-final')

