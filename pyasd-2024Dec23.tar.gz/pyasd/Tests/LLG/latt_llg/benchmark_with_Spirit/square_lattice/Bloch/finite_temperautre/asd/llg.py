#!/usr/bin/env python3

import numpy as np
from asd.core.log_general import log_general
from asd.core.hamiltonian import *
from asd.core.llg_simple import *
from asd.core.geometry import build_latt
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.spin_configurations import *
import asd.mpi.mpi_tools as mt

lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,1,1,1)
S_values = np.ones(1)*0.5 # S=1/2, M = 1 muB
SIA = np.ones(1)*0.1

# in our convention, negative for AFM, positive for FM
J1_iso = np.ones(1)

exch_1 = exchange_shell( neigh_idx[0], J1_iso, shell_name='1NN')

H = np.zeros(3)

nx=20
ny=20
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[2]

log_handle = log_general(
n_log_conf=1000,
n_log_magn=1000,
)


if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    sp_lat = np.zeros((nx,ny,nat,3),float)
    if not rank:  sp_lat = init_random(sp_lat)
    sp_lat = comm.bcast(sp_lat,root=0)

    ham = spin_hamiltonian(Bfield=np.zeros(3),
    S_values=S_values,
    BL_SIA=[SIA],
    BL_exch = [exch_1],
    iso_only=True)

    kwargs = dict(alpha=0.1,
    dt=1e-2,
    nstep=20000,
    S_values=S_values,
    temperature=2,
    lat_type=lat_type,
    conv_ener=1e-8,damping_only=False,
    log_handle = log_handle,)

    LLG = llg_solver(**kwargs)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
