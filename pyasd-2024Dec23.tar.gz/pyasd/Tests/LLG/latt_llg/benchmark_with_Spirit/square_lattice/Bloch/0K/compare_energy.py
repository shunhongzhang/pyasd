#!/usr/bin/env python

import os
import sys
import numpy as np

from spirit import state,io,log,system,parameters
from spirit import geometry,configuration,hamiltonian
from spirit import simulation,quantities
from asd.utility.spirit_tool import verbose_quantities
from llg import *

nx=12
ny=nx

skyr_name="skyrmion-Neel"
phase=90

achiral=False
quiet=True

if __name__=='__main__':
    os.system('rm -r output* Log.txt 2>/dev/null')
    os.mkdir('output')

    with state.State(quiet=quiet) as p_state:
        geometry.set_n_cells(p_state,[nx,ny,1])
        geometry.set_mu_s(p_state,2)
        io.image_read(p_state, 'Spirit_init.ovf1')

        hamiltonian.set_boundary_conditions(p_state, [1,1,0])
        hamiltonian.set_anisotropy(p_state, 0.5, [0,0,1])
        hamiltonian.set_exchange(p_state, 1, [1])
        hamiltonian.set_dmi(p_state, 1, [0.6], chirality=-1)
        hamiltonian.set_field(p_state, 0, [0,0,1])
        system.update_data(p_state)
        sites = geometry.get_positions(p_state)
        nsites=len(sites)
        en0 = system.get_energy(p_state)/nsites

    spins = parse_ovf('Spirit_init.ovf1')[1]
    sp_lat = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)
    en1 = ham.calc_total_E(sp_lat)/np.prod(sp_lat.shape[:-1])
    print ('\nCompare energy between Spirit and this code')
    print ('En from Spirit: {:16.10f} meV/site'.format(en0))
    print ('En from pyasd : {:16.10f} meV/site'.format(en1))


