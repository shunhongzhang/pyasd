#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import plot_spin_2d, make_ani, quiver_kws
from asd.utility.ovf_tools import parse_ovf
from spirit import state,system,geometry
import glob
import copy
import matplotlib.pyplot as plt

with state.State('output_square.cfg',quiet=True) as p_state:
    nx,ny,nz=geometry.get_n_cells(p_state)
    nat=geometry.get_n_cell_atoms(p_state)
    latt=geometry.get_bravais_vectors(p_state)
    geometry.set_n_cells(p_state,(nx,ny,nz))
    pos=geometry.get_positions(p_state)
 

    quiver_kws.update(width=0.1)
 
    try:
        fil_ovf=glob.glob('output/*initial.ovf')[0]
        spins_init=parse_ovf(fil_ovf)[1]
        plot_spin_2d(pos,spins_init, scatter_size=30,title='initial',quiver_kws=quiver_kws,colorbar_shrink=0.3)
    except:
        print ('ovf file containing initial config not found')
 
    try:
        fil_ovf=glob.glob('output/*final.ovf')[0]
        spins_final=parse_ovf(fil_ovf)[1]
        plot_spin_2d(pos,spins_final,scatter_size=30,title='final'  ,quiver_kws=quiver_kws,colorbar_shrink=0.3)
    except:
        print ('ovf file containing final config not found, job not yet completed?')
 
    plt.show()

    time_step=0.001
    n_log_iteration=2000
    fil = glob.glob('output/*Spins-archive.ovf')[0]
    confs = parse_ovf(fil,parse_params=False)[1]

    print ('Calculating the topological charge, this may take several minutes')
    from asd.core.topological_charge import calc_topo_chg
    Qs = [calc_topo_chg(conf,pos[:,:2]) for conf in confs]


    times = np.arange(len(confs))*time_step*n_log_iteration
    titles=['t = {:5.2f} ps, Q = {:7.3f}'.format(tt,Q) for (tt,Q) in zip(times,Qs)]
    make_ani(pos,confs,scatter_size=30,titles=titles,colorbar_shrink=0.3)
