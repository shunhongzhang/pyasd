#!/usr/bin/env python

# this script is test the Hamiltonian by constructing several configurations
# and calculate the total spin energy from Spirit and from the current code

import numpy as np
from asd.core.hamiltonian import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *
import os

def get_spirit_confs_energies(nx,ny,J1,DM,SIA,nconf=15):
    from spirit import state,geometry,configuration,hamiltonian,system,io,quantities
    if os.path.isdir('confs')==False: os.mkdir('confs')
    with state.State(quiet=True) as p_state:
        geometry.set_n_cells(p_state,[nx,ny,1])
        geometry.set_mu_s(p_state,2)

        configuration.plus_z(p_state)
        configuration.skyrmion(p_state, radius=6, phase=0, achiral=False)

        hamiltonian.set_boundary_conditions(p_state, [1,1,0])
        hamiltonian.set_anisotropy(p_state, SIA, [0,0,1])
        hamiltonian.set_exchange(p_state, 1, [J1])
        hamiltonian.set_dmi(p_state, 1, [DM], chirality=-1)
        hamiltonian.set_field(p_state, 1, [0,0,1])

        nos = system.get_nos(p_state)
        en_spirit = []
        mags = []
        for iconf in range(nconf):
            configuration.plus_z(p_state)
            if iconf<5: configuration.skyrmion(p_state,radius=iconf+2.)
            else:       configuration.random(p_state)
            system.update_data(p_state)
            en_spirit.append(system.get_energy(p_state))
            mags.append(quantities.get_magnetization(p_state))
            io.image_write(p_state,'confs/spin_{0}.ovf'.format(iconf))
    en_spirit = np.array(en_spirit)/nos
    mags = np.array(mags)
    return en_spirit,mags


def test_conf_energy(ham):
    import glob
    print ('\n\n')
    print ('='*120)
    print ('Spirit'.center(33)+' | '+'pyasd'.center(33)+' | ',end='')
    print ('Spirit'.center(13)+' | '+'pyasd'.center(13))
    print ('-'*120)
    print (('{:>10s} '*3).format('Mx','My','Mz'),end=' | ')
    print (('{:>10s} '*3).format('Mx','My','Mz'),end=' | ')
    print (('{:12s} | {:12s}').format('en'.center(13),'en'.center(13)),end=' ')
    print ('{:>16s}'.format('diff_E'))
    print ('-'*120)

    fils = glob.glob('confs/*.ovf')
    nconf = len(fils)

    for iconf in range(nconf):
        spins = parse_ovf('confs/spin_{}.ovf'.format(iconf))[1]
        sp_lat = np.swapaxes(spins.reshape(ny,nx,nat,3),0,1)
        mm = np.average(spins,axis=0)
        en = ham.calc_total_E(sp_lat)
        print (('{:10.5f} '*3).format(*tuple(mags[iconf])),end = ' | ')
        print (('{:10.5f} '*3).format(*tuple(mm)),end = ' | ')
        print (('{:12.5f}  | {:12.5f}'+'  {:16.8e}').format(en_spirit[iconf],en,en_spirit[iconf]-en))
    print ('='*120)


J1=1
DM=0.6
SIA=0.5

nx=15
ny=15
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]

S_values=np.array([1])
SIA=np.array([SIA])
J1_iso = np.ones(1)*J1

DM1_rpz = np.array([[-DM,0,0]]) # for chirality=-1
#DM1_rpz = np.array([[4,0,0]])  # for chirality=1

DM1_xyz = get_exchange_xyz(DM1_rpz,rotvecs[0])

Bfield=np.array([0,0,1])

exch_1 = exchange_shell( neigh_idx[0], J1_iso, DM_xyz = DM1_xyz, shell_name = '1NN')

if __name__=='__main__':
    en_spirit,mags = get_spirit_confs_energies(nx,ny,J1,DM,SIA)

    ham = spin_hamiltonian(Bfield=Bfield,
    S_values=S_values,
    BL_SIA=[SIA],
    BL_exch=[exch_1])

    test_conf_energy(ham)
