#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import *
from spirit import state,system,geometry,parameters
import glob
import os
import matplotlib.pyplot as plt

with state.State('output_two_site.cfg',quiet=True) as p_state:
    pos=geometry.get_positions(p_state)
    nx,ny,nz=geometry.get_n_cells(p_state)
    nat=geometry.get_n_cell_atoms(p_state)
    latt=geometry.get_bravais_vectors(p_state)
    nos = system.get_nos(p_state)
    latt = np.array(latt)[:2,:2]
    dt=parameters.llg.get_timestep(p_state)

print ('time step = ',dt)
dt = 1e-3
fil_ovf=glob.glob('output/*Spins-archive.ovf')[0]
get_iter = os.popen('grep Iteration {}'.format(fil_ovf)).readlines()
iteration = np.array([line.split()[-1] for line in get_iter],float)
llg_time = iteration*dt

fil_ovf=glob.glob('output/*initial.ovf')[0]
spins_init=parse_ovf(fil_ovf)[1]
spins_init = np.swapaxes(spins_init.reshape(nx,ny,nos//nx//ny,3),0,1)
fil_ovf=glob.glob('output/*final.ovf')[0]
spins_final=parse_ovf(fil_ovf)[1]
spins_final = np.swapaxes(spins_final.reshape(nx,ny,nos//nx//ny,3),0,1)

sites_cart = np.swapaxes(pos.reshape(nx,ny,nos//nx//ny,3)[...,:2],0,1)

# move sites to the center of lattice for better visualization
sites_cart[...,:2] += 0.5

superlatt=np.dot([[nx,0],[0,ny]],latt)
kws=dict(save=True,colorful_quiver=True,colorbar_orientation='horizontal',superlatt=superlatt)
plot_spin_2d(sites_cart,spins_init, title='initial',**kws)
plot_spin_2d(sites_cart,spins_final,title='final',  **kws)
plt.show()

titles=['{:8.4f} ps'.format(dt) for dt in llg_time]
fil = glob.glob('output/*Spins-archive.ovf')[0]
confs = parse_ovf(fil,parse_params=False)[1]
kws=dict(colorful_quiver=True,colorbar_orientation='horizontal',superlatt=superlatt)
make_ani(sites_cart,confs,titles=titles,jump=1,**kws)
