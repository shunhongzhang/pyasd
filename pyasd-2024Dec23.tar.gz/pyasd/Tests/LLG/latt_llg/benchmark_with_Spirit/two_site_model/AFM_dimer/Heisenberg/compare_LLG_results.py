#!/usr/bin/env python

import numpy as np
from asd.utility.ovf_tools import parse_ovf
import matplotlib.pyplot as plt



def plot_Spirit_results(ax,outdir='pbc'):
    spirit_ovf = '{}/output/two_site_Image-00_Spins-archive.ovf'.format(outdir)
    spins2 = parse_ovf(spirit_ovf)[1]
    fil_ens = '{}/output/two_site_Image-00_Energy-archive.txt'.format(outdir)
    lines = open(fil_ens).readlines()[3:]
    ens2 = np.array([line.split('||')[1] for line in lines],float)
    n2 = spins2.shape[0]
    t2 = np.arange(n2)
    for iat in range(2): 
        ax[0].plot(t2,spins2[:,iat,2],label='Spirit: site {} $S_z$'.format(iat))
        ax[1].plot(t2,spins2[:,iat,0],label='Spirit: site {} $S_x$'.format(iat))
        ax[1].plot(t2,spins2[:,iat,1],label='Spirit: site {} $S_y$'.format(iat))
    ax[2].plot(t2,ens2,label='Spirit')
    return t2,n2,ens2


def compare_LLG_simulations(outdir='pbc',Spirit_outdir='Spirit_run',show=False):
    data = np.loadtxt('{}/M.dat'.format(outdir),skiprows=1)
    pyasd_ovf = '{}/spin_confs.ovf'.format(outdir)
    spins1 = parse_ovf(pyasd_ovf)[1]
    ens1 = data[:,1]

    n1 = spins1.shape[0]
    t1 = data[:,0]
    dirs = {0:'x',1:'y',2:'z'}
    fig,ax=plt.subplots(3,1,sharex=True,figsize=(6,10))
    t2,n2,ens2 = plot_Spirit_results(ax,Spirit_outdir)
    for iat in range(2):
        ax[0].plot(t1,spins1[:,iat,2],label='pyasd: Site {}, $S_z$'.format(iat))
        for ii in range(2): ax[1].plot(t1,spins1[:,iat,ii],label='pyasd: site {}, $S_{}$'.format(iat,dirs[ii]))
    ax[0].legend()
    ax[1].legend()
    ax[0].set_ylabel('$S_z$')
    ax[1].set_ylabel('$S_{x,y}$')
    ax[2].set_xlabel('time (ps)')
    ax[0].set_title(outdir)
    ax[2].set_ylabel('E (meV/site)')
    ax[2].plot(t1,ens1,label='pyasd')
    ax[2].legend()
    ax[0].set_title(outdir.split('/')[-1])
    ax[0].set_xlim(0,130)
    fig.tight_layout()
    if show: plt.show()


if __name__=='__main__':
    compare_LLG_simulations('serial')
    #compare_LLG_simulations('parallel')
    #compare_LLG_simulations('shared_mem')
    #compare_LLG_simulations('Spirit_run')
    plt.show()
