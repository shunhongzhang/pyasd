#!/usr/bin/env python

# this script is still under test

import numpy as np
from asd.core.log_general import log_general
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.llg_advanced import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *



def initialize_AFM_dimer(theta,phi):
    sp_lat = np.zeros((2,1,1,3))
    c1 = np.cos(np.deg2rad(theta))
    s1 = np.sin(np.deg2rad(theta))
    c2 = np.cos(np.deg2rad(phi))
    s2 = np.sin(np.deg2rad(phi))
    vec = np.array([s1*c2,s1*s2,c1])
    sp_lat[0,0,0] =  vec
    sp_lat[1,0,0] = -vec
    return sp_lat


nx=2
ny=1
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]

S_values=np.array([1])
SIA=np.array([0])
J1 = -np.diag([1,1,2])*0.3
J1_sym = np.array([[J1,J1,J1,J1]])
Bfield=np.array([0,0,0])

log_handle = log_general(
n_log_conf=1000,
n_log_magn=1000,
log_topo_chg=False,
)


exch_1 = exchange_shell( neigh_idx[0], np.zeros(1), J_sym_xyz = J1_sym, shell_name = '1NN')

llg_kws = dict(
S_values=S_values,
alpha=0.1,
dt=1e-3,
nstep=100000,
temperature=0,
lat_type=lat_type,
conv_ener=1e-8,
log_handle = log_handle)

theta = 60
phi = 50

if __name__=='__main__':
    sp_lat = initialize_AFM_dimer(theta,phi)

    ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,
    BL_exch=[exch_1],exchange_in_matrix=True,boundary_condition=[0,0,0])

    LLG = llg_solver(**llg_kws)

    log_handle.set_outdir('serial')
    LLG.set_log_handle(log_handle)
    log_time,log_ener,log_conf = LLG.llg_simulation(ham,sp_lat)

    log_handle.set_outdir('parallel')
    LLG.set_log_handle(log_handle)
    #log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)

    log_handle.set_outdir('share_mem')
    LLG.set_log_handle(log_handle)
    #log_time,log_ener,log_conf = LLG.mpi_llg_simulation_shared_memory(ham,sp_lat)
