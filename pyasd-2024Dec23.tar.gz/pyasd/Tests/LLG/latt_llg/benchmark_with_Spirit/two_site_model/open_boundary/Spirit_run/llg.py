#!/usr/bin/env python

import os
import sys
import numpy as np
import shutil

from spirit import state,io,log,system,parameters
from spirit import geometry,configuration,hamiltonian
from spirit import simulation,quantities
from asd.utility.spirit_tool import verbose_quantities

nx=2
ny=1
quiet=False
n_iteration = 100000
n_log_iteration = 1000
alpha=0.1


if __name__=='__main__':
    if os.path.isdir('output'): shutil.rmtree('output')
    if os.path.isfile('output_two_site.cfg'): os.remove('output_two_site.cfg')
    if os.path.isfile('Log.txt'): os.remove('Log.txt')
    if not os.path.isdir('output'): os.mkdir('output')

    with state.State(quiet=quiet) as p_state:
        geometry.set_n_cells(p_state,[nx,ny,1])
        geometry.set_mu_s(p_state,2)

        #configuration.plus_z(p_state)
        io.image_read(p_state,'initial')

        hamiltonian.set_boundary_conditions(p_state, [0,0,0])
        #hamiltonian.set_anisotropy(p_state, 4, [0,0,1])
        hamiltonian.set_exchange(p_state, 1, [0.1])
        #hamiltonian.set_dmi(p_state, 1, [4], chirality=-1)
        #hamiltonian.set_field(p_state, 1, [1,0,0])

        parameters.llg.set_damping(p_state, 0.1)
        parameters.llg.set_timestep(p_state, 0.001)
        parameters.llg.set_iterations(p_state, n_iteration, n_log_iteration)
        parameters.llg.set_output_tag(p_state,'two_site')
        parameters.llg.set_output_folder(p_state, 'output')
        parameters.llg.set_output_configuration(p_state, False, True, 3)
        parameters.llg.set_output_general(p_state,1,1,1)
        parameters.llg.set_output_energy(p_state,0,1,0,1,1)

        system.update_data(p_state)
        state.to_config(p_state,'output_two_site.cfg')
        #dt = parameters.llg.get_timestep(p_state)

        ### LLG dynamics simulation
        LLG = simulation.METHOD_LLG
        DEPONDT = simulation.SOLVER_DEPONDT
        simulation.start(p_state, LLG, DEPONDT)
