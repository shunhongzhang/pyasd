#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import *
#from llg import llg_kws



def plot_Spirit_results(ax,outdir='pbc'):
    spirit_ovf = '{}/Spirit_run/output/two_site_Image-00_Spins-archive.ovf'.format(outdir)
    assert os.path.isfile(spirit_ovf), '{} not found! Did you run LLG by Spirit?'.format(spirit_ovf)
    spins2 = parse_ovf(spirit_ovf)[1]
    fil_ens = '{}/Spirit_run/output/two_site_Image-00_Energy-archive.txt'.format(outdir)
    assert os.path.isfile(fil_ens), '{} not found! Did you run LLG by Spirit?'.format(fil_ens)
    lines = open(fil_ens).readlines()[3:]
    ens2 = np.array([line.split('||')[1] for line in lines],float)
    n2 = spins2.shape[0]
    t2 = np.arange(n2)
    for iat in range(2): ax[iat].plot(t2,spins2[:,iat,2],label='Spirit')
    ax[2].plot(t2,ens2,label='Spirit')
    return t2,n2,ens2


def compare_LLG_simulations(outdir='pbc'):
    fil_archive = '{}/M.dat'.format(outdir)
    assert os.path.isfile(fil_archive), '{} not found! Did you run LLG?'.format(fil_archive)
    pyasd_ovf = '{}/spin_confs.ovf'.format(outdir)
    assert os.path.isfile(pyasd_ovf), '{} not found! Did you run LLG?'.format(pyasd_ovf)
    spins1 = parse_ovf(pyasd_ovf)[1]
    data = np.loadtxt(fil_archive,skiprows=1)
    ens1 = data[:,1]

    n1 = spins1.shape[0]
    t1 = data[:,0]

    fig,ax=plt.subplots(3,1,sharex=True)
    t2,n2,ens2 = plot_Spirit_results(ax,outdir)
    for iat in range(2):
        ax[iat].plot(t1,spins1[:,iat,2],label='pyasd')
        ax[iat].legend()
        ax[iat].set_ylabel('$M_z:\ site\ {}$'.format(iat))
    ax[2].set_xlabel('time (ps)')
    ax[0].set_title(outdir)
    ax[2].set_ylabel('E (meV/site)')
    ax[2].plot(t1,ens1,label='pyasd')
    ax[2].legend()
    fig.tight_layout()
    plt.show()


if __name__=='__main__':
    compare_LLG_simulations('periodic_boundary')
    compare_LLG_simulations('open_boundary')
