#!/usr/bin/env python

from asd.core.spin_configurations import *
from asd.core.llg_simple import log_llg_data

nx=4
ny=4
nat=4

sp_lat = np.zeros((nx,ny,nat,3),float)
sp_lat = init_random(sp_lat)
log_llg_data([0],[0],[sp_lat],log_conf_file='random_spin.ovf',archive_file=None)
