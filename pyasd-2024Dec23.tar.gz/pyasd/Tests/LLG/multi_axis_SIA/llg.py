#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from asd.core.hamiltonian import *
from asd.core.geometry import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.llg_simple import *
from asd.core.shell_exchange import *

nx=6
ny=nx
nz=1
latt,sites,neigh_idx,rotvecs = build_latt('honeycomb',nx,ny,nz,return_neigh=True)
nat=sites.shape[-2]

sp_lat = np.zeros((nx,ny,nat,3))
sp_lat = init_random(sp_lat,verbosity=False)

Bfield=np.zeros(3)

S_values = np.array([1,2])
SIA = np.array([0.2,0.1])
SIA_bq = np.array([0,0])
SIA_axis = np.array([[1,1,2],[0,0,1]])
SIA_bq_axis = np.array([0,0,1])

J_sym_xyz = np.zeros((2,3,3,3))
J_iso = np.array([1,1])
DM_xyz = np.zeros((2,3,3))
Ki_mag = np.zeros(2)
Ki_xyz = np.zeros((2,3,3))
exch_1 = exchange_shell(neigh_idx[0],J1_iso,J_sym_xyz,DM_xyz,Ki_mag,Ki_xyz,'1NN')

ham = spin_hamiltonian(H,S_values,SIA,SIA_axis,
iso_only=False,exchange_in_matrix=False,BL_exch=[exch_1])


#sp_lat[...,:2]=1
#sp_lat[...,2]=2
#sp_lat /= np.sqrt(6)
#plot_spin_2d(np.dot(sites,latt),sp_lat,show=True,scatter_size=30,latt=latt)
#en = ham.calc_total_E(sp_lat)
#print (en/np.prod(sp_lat.shape[:-1]))


LLG = llg_solver(S_values=S_values,dt=1e-2,conv_ener=1e-10,temperature=0,n_log_magn=500,n_log_conf=500)

if __name__=='__main__':
    LLG.mpi_llg_simulation(ham,sp_lat)
