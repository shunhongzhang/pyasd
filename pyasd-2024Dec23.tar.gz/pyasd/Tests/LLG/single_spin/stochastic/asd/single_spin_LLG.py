#!/usr/bin/env python

from __future__ import print_function
import numpy as np
from asd.core.log_general import log_general
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.geometry import build_latt
import os
import matplotlib.pyplot as plt

def plot_spin_evolve(llg_time,spin_evolve,H,llg_time_Spirit=None,spins_Spirit=None):
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(1,1)
    ax.plot(llg_time,spin_evolve[:,2],label='$n_z$',zorder=1)
    if llg_time_Spirit is not None and spins_Spirit is not None:
        ax.plot(llg_time_Spirit,spins_Spirit[:,2], 'c-', lw=10, alpha=0.3, zorder=-2, label='$n_z^{Spirit}$')
    ax.axhline(0,c='gray',ls='--',alpha=0.5,zorder=-1)
    ax.axhline(1,c='gray',ls='--',alpha=0.5,zorder=-1)
    ax.set_xlabel('Time (ps)')
    ax.set_xlim(-10,600)
    ax.legend()
    plt.show()
    return fig,ax


def get_spirit_results(dt=0.001): # dt in ps
    import glob
    from asd.utility.ovf_tools import parse_ovf
    try:
        fil_ovf=glob.glob('Spirit_from_x.ovf1')[0]
        get_iter = os.popen('grep Iteration {}'.format(fil_ovf)).readlines()
        iteration = np.array([line.split()[-1] for line in get_iter],float)
        params,spins_Spirit = parse_ovf(fil_ovf)
        llg_time_Spirit = iteration*dt
        return llg_time_Spirit, spins_Spirit[:,0]
    except:
        return None,None

nx=1
ny=1
nz=1
nat=1

B=2
Bfield=np.array([0,0,1])*B
S_values=np.array([1./2])
SIA=np.zeros(1)
alpha=0.1

log_handle = log_general(
n_log_conf=200,
n_log_magn=200,
)

kws=dict(
S_values=S_values,
lat_type='square',
alpha=alpha,
dt=1e-2,
nstep=30000,
temperature=0.1,
conv_ener=1e-11,
log_handle =log_handle,
)

latt,sites,neigh_idx,rotvecs = build_latt('square',nx,ny,nz)

nat=sites.shape[2]

if __name__=='__main__':
    llg_time_Spirit, spins_Spirit = get_spirit_results()

    LLG = llg_solver(**kws)

    ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_SIA=[SIA])

    sp_lat=np.zeros((nx,ny,nat,3),float)
    sp_lat[...,2]=1.

    # run one of the following three lines
    #log_time,log_ener,log_conf = LLG.llg_simulation(ham,sp_lat)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)

    spin_evolve = np.average(log_conf,axis=(1,2))[:,0]
    #fig,ax = plot_spin_evolve(log_time,spin_evolve,Bfield,llg_time_Spirit,spins_Spirit)
