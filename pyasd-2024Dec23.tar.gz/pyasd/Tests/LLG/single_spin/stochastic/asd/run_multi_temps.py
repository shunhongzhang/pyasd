#!/usr/bin/env python

import os
import numpy as np

temp_list = np.arange(0.1,0.9,0.1)
ntemp = len(temp_list)

if __name__=='__main__':
    for itemp in range(ntemp):
        cdir = 'temp_{}'.format(itemp)
        os.mkdir(cdir)
        os.system('cp single_spin_LLG.py {}'.format(cdir))
        os.chdir(cdir)
        repl = "sed -i 's/temperature=0.1/temperature={:4.2f}/g' single_spin_LLG.py".format(temp_list[itemp])
        os.system(repl)
        os.system('./single_spin_LLG.py > temp_{}.out &'.format(itemp))
        os.chdir('..')
