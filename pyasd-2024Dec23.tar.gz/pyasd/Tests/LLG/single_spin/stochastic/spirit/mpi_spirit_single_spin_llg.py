#!/usr/bin/env python

#===============================================
#
# Simulate the precession of a single spin
# in an external magnetic field
# to manifest the Spirit LLG solvers
# See Phys. Rev. B 99, 224414 (2019), Fig. 5
#
# Shunhong Zhang <szhang2@ustc.edu.cn>
# Oct 20, 2020
#
#================================================

import numpy as np
import asd.mpi.mpi_tools as mt
from spirit import io,log,state,geometry,system,hamiltonian,simulation,parameters,configuration

temp_list = np.arange(0.1,0.9,0.1)
ntemp = len(temp_list)
Bfield=2

def main():
    comm,size,rank,node = mt.get_mpi_handles()
    start, last = mt.assign_task(ntemp,size,rank)
    for it in range(start,last):
        with state.State(quiet=(rank!=0)) as p_state:
            geometry.set_n_cells(p_state,[1,1,1])
            hamiltonian.set_field(p_state,Bfield,[0,0,1])
            parameters.llg.set_output_folder(p_state,'.')
            parameters.llg.set_damping(p_state,0.1)
            parameters.llg.set_timestep(p_state,0.01)
            parameters.llg.set_output_configuration(p_state, 0, 1 ,3)
            parameters.llg.set_output_general(p_state,1,0,0)
            parameters.llg.set_output_energy(p_state,0,1,0,1,1)
            parameters.llg.set_iterations(p_state, 200000, 500)
            parameters.llg.set_temperature(p_state,temp_list[it])
            parameters.llg.set_output_tag(p_state,'T_{:.2f}'.format(temp_list[it]))
            configuration.plus_z(p_state)
            system.update_data(p_state)
            simulation.start(p_state, simulation.METHOD_LLG, simulation.SOLVER_DEPONDT)

if __name__=='__main__':
    main()
