#!/usr/bin/env python

import os
import numpy as np

temp_list = np.arange(0.1,0.9,0.1)
ntemp = len(temp_list)
fil_run = 'spirit_llg_one_spin.py'

if __name__=='__main__':
    for itemp in range(ntemp):
        cdir = 'temp_{}'.format(itemp)
        os.mkdir(cdir)
        os.system('cp {} {}'.format(fil_run,cdir))
        os.chdir(cdir)
        repl = "sed -i 's/temperature=0.1/temperature={:4.2f}/g' {}".format(temp_list[itemp],fil_run)
        os.system(repl)
        os.system('./{} > temp_{}.out &'.format(fil_run,itemp))
        os.chdir('..')
