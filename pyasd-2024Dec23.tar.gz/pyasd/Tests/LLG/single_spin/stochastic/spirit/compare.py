#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import *

itemp=1
outdir='temp_{}'.format(itemp)
fil='T_0.20_Image-00_Spins-archive.ovf'
spins1 = parse_ovf(fil)[1]
spins2 = parse_ovf('{}/{}'.format(outdir,fil))[1]

print (np.allclose(spins1,spins2))
print (spins1.shape,spins2.shape)
m1 = np.average(spins1,axis=0)
m2 = np.average(spins2,axis=0)

print (m1,m2)
