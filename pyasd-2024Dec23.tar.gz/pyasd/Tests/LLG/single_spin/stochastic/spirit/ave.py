#!/usr/bin/env python3

import numpy as np
from asd.utility.spin_visualize_tools import *
import glob
import matplotlib.pyplot as plt
import os
from run_multi_temps import temp_list
from asd.core.constants import muB,kB

B=2
confs = []
ens = []
for it,temp in enumerate(temp_list):
    #cdir = 'temp_{}'.format(it)
    cdir='.'
    tag = 'T_{:.2f}'.format(temp)
    fil_ovf=glob.glob('{}/{}*Spins-*archive*'.format(cdir,tag))[0]
    print (fil_ovf)
    spins = parse_ovf(fil_ovf)[1]
    confs.append(spins)
    fil_en=glob.glob('{}/{}*Energy-*archive*'.format(cdir,tag))[0]
    en = np.array([line.split()[2] for line in open(fil_en).readlines()[3:]],float)
    ens.append(en)

start_idx=200
confs = np.array(confs)
print (confs.shape)
ens = np.array(ens)
ave_Mz = np.average(confs[:,start_idx:,0,2],axis=1)
err_Mz = [ave_Mz - np.min(confs[:,start_idx:,0,2],axis=1), np.max(confs[:,start_idx:,0,2],axis=1) - ave_Mz]

xx = kB*temp_list/muB/B

fig,ax=plt.subplots(1,1)
ax.plot(xx,ave_Mz,'o-',c='g')
#ax.errorbar(xx,ave_Mz,yerr=err_Mz,linewidth=2,capsize=6,fmt='o')
tax=ax.twinx()
tax.plot(xx,np.average(ens[:,start_idx:],axis=1),'s-',c='r')
ax.set_xlabel('$k_B T\ /\ \mu_\mathrm{B}B$')
ax.set_ylabel('$M\ /\ M_s$',c='g')
tax.set_ylabel('$E\ \mathrm{(meV/site)}$',color='r')
ax.set_ylim(-0.3,1.1)
fig.tight_layout()
plt.show()
