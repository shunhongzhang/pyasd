#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
import ovf.ovf as ovf
import glob


def gaussian(x,mu,sigma=1):
    g = np.exp(-(x-mu)**2/sigma**2/2)/np.sqrt(2*np.pi*sigma**2)
    return g

segments = []
spins = []
fil_ovf = glob.glob('*Spins-archive.ovf')[0]
print (fil_ovf)
with ovf.ovf_file(fil_ovf) as ovf_file:
    for iseg in range(ovf_file.n_segments):
        segment = ovf.ovf_segment()
        ovf_file.read_segment_header(iseg, segment)
        spin = np.zeros((segment.N,segment.valuedim))
        ovf_file.read_segment_data(iseg, segment, spin)
        segments.append(segment)
        spins.append(spin)

spins = np.array(spins)

nbins = 50
xx = np.linspace(0,2,300)
values,bins = np.histogram(spins[...,2],bins=nbins)
centers = (bins[1:] + bins[:-1])/2
sigma = 0.02
gf = np.array([gaussian(xx,center,sigma) for center in centers])
fac = np.sqrt(2*np.pi*sigma**2)
conv = np.einsum('nm,n->m',gf,values)/nbins

fig,ax=plt.subplots(1,1)
#ax.plot(spins[:,0,2])
#for ib in range(nbins): ax.plot(xx,gf[ib]*values[ib]*fac)
ax.hist(spins[...,2],bins=nbins,fc='none',ec='C1')
ax.plot(xx,conv,c='C0',label='convolution')
ax.legend()
plt.show()
