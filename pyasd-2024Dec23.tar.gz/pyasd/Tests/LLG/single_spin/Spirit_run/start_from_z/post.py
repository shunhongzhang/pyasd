#!/usr/bin/env python3

import numpy as np
from asd.utility.spin_visualize_tools import *
import glob
import matplotlib.pyplot as plt
import os


def analytic_solution(alpha,H,t):
    H_mag = np.linalg.norm(H)
    phi = gamma_e/(1+alpha**2)*H_mag*t
    n_z = np.tanh(alpha*gamma_e/(1+alpha**2)*H_mag*t)
    n_x = np.cos(phi)*np.sqrt(1-n_z**2)
    return n_x,n_z

def plot_spin_evolve(llg_time,spin_evolve,H):
    n_x,n_z=analytic_solution(alpha,H,llg_time)
    fig,ax=plt.subplots(1,1)
    ax.plot(llg_time,spin_evolve[:,0],label='$n_x$')
    ax.plot(llg_time,spin_evolve[:,2],label='$n_z$')
    ax.plot(llg_time,n_x,'g-',lw=5,alpha=0.4,zorder=-1,label='$n_x^{analytic}$')
    ax.plot(llg_time,n_z,'m-',lw=5,alpha=0.4,label='$n_z^{analytic}$')
    #ax.axvline(2*np.pi/(gamma_e*np.linalg.norm(H)/(1+alpha**2)),c='gray',ls='--')
    ax.axhline(0,c='gray',ls='--',alpha=0.5,zorder=-1)
    ax.axhline(1,c='gray',ls='--',alpha=0.5,zorder=-1)
    ax.set_xlabel('Time (ps)')
    ax.set_xlim(-1,500)
    ax.legend()
    plt.show()
    return fig


alpha=0.1
gamma_e = 0.1760859644  # electron gyromagnetic ratio, in rad/T/ps
dt = 0.01  # time step in ps

outdir='.'
fil_ovf=glob.glob('{}/*Spins-*archive*'.format(outdir))[0]
get_iter = os.popen('grep Iteration {}'.format(fil_ovf)).readlines()
iteration = np.array([line.split()[-1] for line in get_iter],float)
params,spins = parse_ovf(fil_ovf)
llg_time = iteration*dt
Bfield=np.array([0,0,1])

plot_spin_evolve(llg_time,spins[:,0],H)
