#!/usr/bin/env python

#===============================================
#
# Simulate the precession of a single spin
# in an external magnetic field
# to manifest the Spirit LLG solvers
# See Phys. Rev. B 99, 224414 (2019), Fig. 5
#
# Shunhong Zhang <szhang2@ustc.edu.cn>
# Oct 20, 2020
#
#================================================

import numpy as np
import matplotlib.pyplot as plt
from spirit import io,log,state,geometry,system,hamiltonian,simulation,parameters,configuration
import os

with state.State() as p_state:
    parameters.llg.set_output_tag(p_state,'llg_single_spin')
    parameters.llg.set_output_folder(p_state,'.')
    parameters.llg.set_damping(p_state,0.1)
    parameters.llg.set_timestep(p_state,0.001)
    parameters.llg.set_output_configuration(p_state, 0, 1 ,3)
    parameters.llg.set_output_general(p_state,1,0,0)
    parameters.llg.set_output_energy(p_state,0,1,0,1,1)
    geometry.set_n_cells(p_state,[1,1,1])
    hamiltonian.set_field(p_state,1,[0,0,1])
    io.image_read(p_state,'initial_spin.ovf1')
    system.update_data(p_state)
    simulation.start(p_state, simulation.METHOD_LLG, simulation.SOLVER_DEPONDT)
