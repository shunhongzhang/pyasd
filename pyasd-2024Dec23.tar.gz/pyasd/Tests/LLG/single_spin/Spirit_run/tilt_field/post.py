#!/usr/bin/env python3

import numpy as np
from asd.utility.spin_visualize_tools import *
import glob
import matplotlib.pyplot as plt
import os


def find_maxima(arr):
    idx = [ii for ii in range(1,len(arr)-1) if arr[ii-1]<arr[ii]>arr[ii+1]]
    return idx

def plot_spin_evolve(llg_time,spins_set,tag_set):
    fig,ax=plt.subplots(1,1)

    shift=2
    for ii,(conf,tag) in enumerate(zip(spins_set,tag_set)):
        Sz = conf[:,2]
        idx = find_maxima(Sz)[:2]
        f= 1/(llg_time[idx[1]]-llg_time[idx[0]])
        ax.text(80,ii*shift,'f={:7.4f} THz'.format(f))
        ax.scatter(llg_time[idx],Sz[idx]+ii*shift,c='r')
        ax.plot(llg_time,Sz+ii*shift,label='anisotropy = {}'.format(tag))
        ax.axhline(ii*shift+1,c='gray',ls='--',alpha=0.5,zorder=-1)
    ax.set_ylabel('$M_z/M$')
    ax.set_xlabel('Time (ps)')
    ax.set_xlim(-1,np.max(llg_time))
    ax.set_title('single-ion anisotropy along z, H = 1T along [0,1,1]')
    ax.legend()
    plt.show()
    return fig


alpha=0.1
gamma_e = 0.1760859644  # electron gyromagnetic ratio, in rad/T/ps
dt = 0.002  # time step in ps

outdir='.'
tag='relax'
fils = glob.glob('{}/{}*Spins-*archive*'.format(outdir,tag))
fils = sorted(fils)
def get_one_set(fil_ovf):
    tag = fil_ovf.split('_')[1]
    get_iter = os.popen('grep Iteration {}'.format(fil_ovf)).readlines()
    iteration = np.array([line.split()[-1] for line in get_iter],float)
    spins = parse_ovf(fil_ovf)[1]
    return spins,tag


get_iter = os.popen('grep Iteration {}'.format(fils[0])).readlines()
iteration = np.array([line.split()[-1] for line in get_iter],float)

llg_time = iteration*dt
spins_set = [get_one_set(fil)[0][:,0] for fil in fils]
tag_set = [get_one_set(fil)[1] for fil in fils]

plot_spin_evolve(llg_time,spins_set,tag_set)
