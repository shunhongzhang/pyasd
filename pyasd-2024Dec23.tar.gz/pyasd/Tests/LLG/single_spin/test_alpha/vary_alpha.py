#!/usr/bin/env python

from __future__ import print_function
import numpy as np
from asd.core.log_general import log_general
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.geometry import build_latt
import os
import matplotlib.pyplot as plt


nx=1
ny=1
nz=1
nat=1

Bfield=np.array([0,0,1])
S_values=np.array([0.5])
SIA=np.zeros(1)

lat_type='square'
dt=1e-2
nstep=100000

log_handle = log_general(
n_log_conf=500,
n_log_magn=500,
)

temp=0

alpha_values=[0.01,0.1,0.5]

latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)

nat=sites.shape[2]

if __name__=='__main__':
    ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_SIA=[SIA])

    for alpha in alpha_values:
        log_handle._log_conf_file = 'alpha_{:.2f}_spins.ovf'.format(alpha)
        log_handle._archive_file = 'alpha_{:.2f}_M.dat'.format(alpha)

        LLG = llg_solver(alpha=alpha,
        dt=dt,nstep=nstep,
        S_values=S_values,
        conv_ener=1e-11,
        temperature=temp,lat_type=lat_type,
        log_handle = log_handle)

        sp_lat=np.zeros((nx,ny,nat,3),float)
        sp_lat[...,0]=1.
        log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
