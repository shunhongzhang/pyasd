#!/usr/bin/env python

import numpy
import matplotlib.pyplot as plt
from asd.utility.spin_visualize_tools import *
from vary_alpha import alpha_values

fig,ax=plt.subplots(2,1,sharex=True,figsize=(8,6))
for alpha in alpha_values:
    data = np.loadtxt('alpha_{:.2f}_M.dat'.format(alpha))
    time = data[:,0]
    M = data[:,-3:]
    ax[0].plot(time,M[:,2],label='$\\alpha={:.2f}$'.format(alpha))
    ax[1].plot(time,M[:,0],label='$\\alpha={:.2f}$'.format(alpha))
ax: ax[0].legend()
ax[1].set_xlabel('Time (ps)')
ax[0].set_ylabel('$M_z$')
ax[1].set_ylabel('$M_x$')
for axx in ax: axx.set_yticks([-1,0,1])
fig.tight_layout()
plt.show()
