#!/usr/bin/env python

from __future__ import print_function
import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.log_general import *
from asd.core.llg_simple import *
from asd.core.llg_advanced import *
from asd.core.geometry import build_latt
import os
import matplotlib.pyplot as plt

def analytic_solution(alpha,H,t):
    H_mag = np.linalg.norm(H)
    phi = gamma_e/(1+alpha**2)*H_mag*t
    n_z = np.tanh(alpha*gamma_e/(1+alpha**2)*H_mag*t)
    n_x = np.cos(phi)*np.sqrt(1-n_z**2)
    return n_x,n_z

def plot_spin_evolve(llg_time,spin_evolve,H):
    import matplotlib.pyplot as plt
    n_x,n_z=analytic_solution(alpha,H,llg_time)
    fig,ax=plt.subplots(1,1)
    ax.plot(llg_time,spin_evolve[:,0],label='$n_x$',lw=0.5,zorder=1)
    ax.plot(llg_time,spin_evolve[:,2],label='$n_z$',lw=0.5,zorder=1)

    ax.plot(llg_time,n_x,'m-',lw=5,alpha=0.4,zorder=-1,label='$n_x^{analytic}$')
    ax.plot(llg_time,n_z,'g-',lw=5,alpha=0.4,label='$n_z^{analytic}$')

    ax.axhline(0,c='gray',ls='--',alpha=0.5,zorder=-1)
    ax.axhline(1,c='gray',ls='--',alpha=0.5,zorder=-1)
    ax.set_xlabel('Time (ps)')
    ax.set_xlim(-10,500)
    ax.legend()
    ax.set_ylabel('S')
    ax.set_xlabel('t (ps)')
    fig.tight_layout()
    plt.show()
    return fig,ax


def get_spirit_results():
    import glob
    from asd.utility.ovf_tools import parse_ovf
    dt = 0.001  # time step in ps

    fil_ovf=glob.glob('benchmark/Spirit_run/start_from_x/output/*Spins-*archive*')
    assert len(fil_ovf)>0, 'Spirit results for benchmark not found!'
    fil_ovf = fil_ovf[0]
    get_iter = os.popen('grep Iteration {}'.format(fil_ovf)).readlines()
    iteration = np.array([line.split()[-1] for line in get_iter],float)
    params,spins_Spirit = parse_ovf(fil_ovf)
    llg_time_Spirit = iteration*dt
    return llg_time_Spirit, spins_Spirit[:,0]

nx=1
ny=1
nz=1
nat=1

Bfield=np.array([0,0,1])
S_values=np.array([0.5])
SIA=np.zeros(1)
lat_type='square'
alpha=0.1

ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_SIA=[SIA])
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)


log_handle=log_general(
n_log_conf=500,
n_log_magn=500,
log_force=True,
)

kws=dict(
S_values=S_values,
lat_type=lat_type,
alpha=alpha,
dt=2e-2,
nstep=10000,
conv_ener=1e-11,
log_handle=log_handle,
)


nat=sites.shape[2]

if __name__=='__main__':
    LLG = llg_solver(**kws)
    LLG_adv = llg_solver_adv(**kws)

    sp_lat=np.zeros((nx,ny,nat,3),float)
    sp_lat[...,0]=1.

    # run one of the following three lines
    #log_time,log_ener,log_conf = LLG.llg_simulation(ham,sp_lat)
    #log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
    log_time,log_ener,log_conf = LLG_adv.mpi_llg_simulation(ham,sp_lat)

    spin_evolve = np.average(log_conf,axis=(1,2))[:,0]
    fig,ax = plot_spin_evolve(log_time,spin_evolve,Bfield)
