#!/usr/bin/env python

import sys
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.geometry import build_latt

def get_ni_from_angle(theta,phi):
    return np.array([np.sin(theta)*np.cos(phi),np.sin(theta)*np.sin(phi),np.cos(theta)])


def make_3d_ani(time,spin_evolve,jump=20,gif_name='LLG_ani',gif_dpi=200):
    def update(i,scat,ld,qv,spin_evolve):
        new_segs = [[[0,0,0],[spin_evolve[i,0],spin_evolve[i,1],spin_evolve[i,2]]]]
        qv.set_segments(new_segs)
        scat._offsets3d = (spin_evolve[:i].T)
        ld.set_data(spin_evolve[:i,0],spin_evolve[:i,1])
        ld.set_3d_properties(spin_evolve[:i,2])

    fig = plt.figure()
    ax = Axes3D(fig)
    ax.quiver(0,0,0,0,0,1,length=1.5,color='k',normalize=True)
    ax.set_xlim(-1,1)
    ax.set_ylim(-1,1)
    ax.set_zlim(-1,1)
    #ax.set_aspect('equal')
    u,v=np.mgrid[0:2*np.pi:50j,0:np.pi:50j]
    x,y,z=get_ni_from_angle(v,u)
    ax.plot_surface(x,y,z,color='lightblue',alpha=0.3)
    qv = ax.quiver(0,0,0,spin_evolve[0,0],spin_evolve[0,1],spin_evolve[0,2],length=1,normalize=True)
    scat = ax.scatter([],[],[],s=10,color='m')
    ld, = ax.plot([],[],[],c='c')
    anim = FuncAnimation(fig, update, frames=range(len(spin_evolve[::jump])), interval=1, repeat=False,blit=False,
    fargs=[scat, ld, qv, spin_evolve[::jump]])
    if len(sys.argv)>1  and sys.argv[1]=='save': anim.save('{0}.gif'.format(gif_name), dpi=gif_dpi, writer='imagemagick')
    else: plt.show()


nx=1
ny=1
nz=1
nat=1

Bfield=np.array([0,0,1])
S_values=np.array([0.5])

lat_type='square'
alpha=0.1
dt=1e-2
nstep=30000
n_log_conf=500
n_log_magn=200
temp=0

latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)

nat=sites.shape[2]

if __name__=='__main__':
    LLG = llg_solver(alpha,dt,nstep,S_values,
    conv_ener=1e-11,
    temperature=temp,lat_type=lat_type,n_log_conf=n_log_conf,n_log_magn=n_log_magn)

    ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values)

    sp_lat=np.zeros((nx,ny,nat,3),float)
    sp_lat[...,0]=1.

    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
    spin_evolve = np.average(log_conf,axis=(1,2))[:,0]
    make_3d_ani(time,spin_evolve,jump=1,gif_name='LLG_ani',gif_dpi=200)
