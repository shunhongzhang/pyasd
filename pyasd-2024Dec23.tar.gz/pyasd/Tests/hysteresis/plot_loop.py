#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt


H_step=2
H_max=21
H0=np.arange(0,H_max,H_step)
H_loop = np.array([H0,H0[::-1],-H0,-H0[::-1],H0]).flatten()
start_idx=10
mags = []
for iH,H in enumerate(H_loop):
    data = np.loadtxt('mags/M_{}.dat'.format(iH))
    mag = np.average(data[start_idx:,2:5],axis=0)
    mags.append(mag) 

mags = np.array(mags)

fig,ax=plt.subplots(1,1)
ax.scatter(H_loop,mags[:,2],c=np.arange(len(H_loop)),cmap='rainbow')
ax.set_xlabel('H')
ax.set_ylabel('M')
plt.show()
