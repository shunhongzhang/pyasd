#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import *
from llg import *

def sketch_single_snapshot(confs_f,FM_nlayer=2,nlayer=4,show_confs=False,status='final'):
    nat = nlayer
    confs_f = confs_f.reshape(ny,nx,nat,3)
    xx,yy = np.mgrid[0:1:100j,0:1:100j]
    fig,ax=plt.subplots(figsize=(5,5))
    for iat in range(nlayer):
        cc = np.average(confs_f[:,:,iat,2])*np.ones_like(xx)
        cax = ax.imshow(cc,extent=[0,1,iat+0.52,iat+1.48],origin='lower',cmap='bwr',vmin=-1,vmax=1,aspect='auto')
    cbar=fig.colorbar(cax,shrink=0.6)
    cbar.ax.set_title('$M_z$')
    ax.set_ylim(0.5,nlayer+0.5)
    ax.axhline(FM_nlayer+0.5,ls='--',c='g',lw=4)
    ax.set_xticks([])
    ax.set_yticks(np.arange(1,nlayer+1))
    fig.tight_layout()
    fig.savefig('field_cool_conf_{}'.format(FM_nlayer),dpi=400)
    plt.show()


try:
    spins = parse_ovf('final_spin_confs.ovf')[1]
    sp_lat = np.transpose(spins.reshape(nz,ny,nx,nat,3),(2,1,0,3,4))
except:
    spins = parse_ovf('spin_confs.ovf')[1]
    sp_lat = np.transpose(spins[-1].reshape(nz,ny,nx,nat,3),(2,1,0,3,4))

mag = np.zeros((nat,3))
for iat in range(nat):
    mag[iat] = np.average(sp_lat[...,iat,:],axis=(0,1,2))

sketch_single_snapshot(sp_lat[:,:,0])
