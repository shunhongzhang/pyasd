#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.spin_configurations import *
from asd.core.llg_simple import llg_solver
import os
import asd.mpi.mpi_tools as mt

nx=1
ny=1
nz=1
nlayer=4

latt = np.array([[1,0,0],[0,1,0],[0,0,1]])
sites = np.array([[0.5,0.5,i/8.] for i in range(nlayer)])

neigh_idx[0] = np.zeros((nlayer,4,4),int)

for i in range(nlayer): neigh_idx[0][i,:,-1]=i
neigh_idx[0][:,0,0] = 1
neigh_idx[0][:,1,0] = -1
neigh_idx[0][:,2,1] = 1
neigh_idx[0][:,3,1] = -1

neigh_idx[1] = np.zeros((nlayer,1,4),int)
for i in range(nlayer):
    neigh_idx[1][i,0,-1]=(i-1)%nlayer
neigh_idx[1][ 0,0,2] = -1


neigh_idx[2] = np.zeros((nlayer,1,4),int)
for i in range(nlayer):
    neigh_idx[2][i,0,-1]=(i+1)%nlayer
neigh_idx[2][-1,0,2] = 1


nat = sites.shape[-2]
ndim=3
xx,yy,zz=np.mgrid[0:nx,0:ny,0:1]
sites_sc = np.zeros((nx,ny,nz,nat,ndim),float)
for iat in range(nat):
    sites_sc[...,iat,0] = sites[...,iat,0] + xx
    sites_sc[...,iat,1] = sites[...,iat,1] + yy

sites = sites_sc

J1_iso = np.array([1,1,1,1])
exch_1 = exchange_shell(neigh_idx[0],J1_iso,shell_name='1NN: in-plane')

J2_iso = np.array([0.,0.1,0.1,-0.5])
exch_2 = exchange_shell(neigh_idx[1],J2_iso,shell_name='1NN: out-of-plane - 1')

J3_iso = np.array([0.1,0.1,-0.5,0.])
exch_3 = exchange_shell(neigh_idx[2],J3_iso,shell_name='1NN: out-of-plane - 2')


Bfield=np.array([0,0,1])
S_values = np.array([1,1,1,1])
SIA=np.array([1,1,1,1])*0.2
SIA_axis = np.array([[0,0,1],[0,0,1],[0,1,1],[0,1,1]])
SIA_axis = np.array([0,0,1])

ham = spin_hamiltonian(H,S_values,BL_SIA=[SIA],SIA_axis=SIA_axis,
boundary_condition=[1,1,0],
BL_exch=[exch_1,exch_2,exch_3],
iso_only=True)

sp_lat = np.zeros((nx,ny,nz,nat,3),float)

LLG = llg_solver(S_values=S_values,
nstep=20000,
dt=5e-3,
n_log_conf=500,n_log_magn=500,
prefix='EB',
temperature=2)

#ham.verbose_reference_energy(sp_lat)
#sp_lat[...,:3,2] = 1
#sp_lat[...,3:,2] = -1
#print (ham.calc_total_E(sp_lat)/np.prod(sp_lat.shape[:-1]))

nloop=5

H_list = np.arange(6,-6.1,-0.1)
H_list = np.append(H_list,H_list[::-1][1:])
H_list = np.append(H_list,np.tile(H_list[1:],(nloop-1,1)).flatten())

outdir_ovf='ovfs'
outdir_dat='dats'

if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()
    if not rank: sp_lat = init_random(sp_lat)
    sp_lat = comm.bcast(sp_lat)
    for iH,Hz in enumerate(H_list):
        H = np.array([0,0,Hz])
        ham = spin_hamiltonian(H,S_values,BL_SIA=[SIA],SIA_axis=SIA_axis,
        boundary_condition=[1,1,0],
        BL_exch=[exch_1,exch_2,exch_3],
        iso_only=True)

        LLG = llg_solver(S_values=S_values,
        nstep=10000,
        dt=5e-3,
        n_log_conf=2000,
        n_log_magn=2000,
        prefix='EB',
        log_conf_file='{}/H_{}_S.ovf'.format(outdir_ovf,iH),
        archive_file='{}/H_{}_M.dat'.format(outdir_dat,iH),
        temperature=2)

        log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
        sp_lat = log_conf[-1]
