#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_simple import *
from asd.core.geometry import build_latt
from asd.core.spin_configurations import *
from asd.core.shell_exchange import *
from asd.utility.ovf_tools import parse_ovf
import asd.mpi.mpi_tools as mt
import os
import shutil

nx=5
ny=5
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,1)
nat=sites.shape[-2]


def calc_hysteresis(LLG,ham,nx,ny,nat,H_step=2,H_max=21):
    comm,size,rank,node=mt.get_mpi_handles()
    sp_lat=np.zeros((nx,ny,nat,3),float)
    if not rank: sp_lat=init_random(sp_lat)
    sp_lat = comm.bcast(sp_lat)
    H0=np.arange(0,H_max,H_step)
    H_loop = np.array([H0,H0[::-1],-H0,-H0[::-1],H0]).flatten()
    for iH,H in enumerate(H_loop):
        if not rank: print ('\nH={:10.4f} T'.format(H)); sys.stdout.flush()
        LLG._Bfield=np.array([0,0,H])
        LLG._log_conf_file='confs/spins_{0}.ovf'.format(iH)
        LLG._archive_file='mags/M_{0}.dat'.format(iH)
        log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat,verbosity=1)
        sp_lat = log_conf[-1]

temp=0.5
dt=5e-3
n_log_conf=100
n_log_magn=100
nstep=2000
alpha=0.1

S_values=np.array([1])
SIA=np.array([4])
J1_iso = np.array([6])
J1_sym_xyz = np.zeros((1,4,3,3))
DM1_rpz = np.array([[-4,0,0]])
DM1_xyz = get_exchange_xyz(DM1_rpz,rotvecs[0])
Kitaev1_xyz = np.zeros((1,4,3))
Kitaev1_mag = np.zeros(1)
Bfield=np.array([0,0,0])

exch_1 = exchange_shell( neigh_idx[0], J1_iso, J1_sym_xyz, DM1_xyz, Kitaev1_mag, Kitaev1_xyz, '1NN')

if __name__=='__main__':
    if os.path.isdir('mags'):  shutil.rmtree('mags')
    if os.path.isdir('confs'): shutil.rmtree('confs')
    os.mkdir('mags')
    os.mkdir('confs')

    ham = spin_hamiltonian(Bfield=Bfield,S_values=S_values,BL_SIA=[SIA],
    BL_exch=[exch_1],
    from_sym_mat = False, exchange_in_matrix = False, iso_only = True)

    LLG = llg_solver(alpha=alpha,dt=dt,nstep=nstep,S_values=S_values,
    temperature=temp,lat_type=lat_type,n_log_conf=n_log_conf,n_log_magn=n_log_magn,conv_ener=1e-8)

    calc_hysteresis(LLG,ham,nx,ny,nat)
