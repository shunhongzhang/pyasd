#!/usr/bin/env python

# A simple spin trimer system to modeling the HTST method
# Ref.: PR 85, 184409 (2012)

import numpy as np
import matplotlib.pyplot as plt
from asd.core.geometry import *
from asd.core.shell_exchange import *

def display_sites(sites,latt):
    sites_cart = np.dot(sites,latt)
    points = np.array([[0,0],[1,0],[1,1],[0,1],[0,0]])
    points = np.dot(points,latt)
    fig,ax=plt.subplots(1,1)
    ax.plot(*tuple(points.T),ls='--')
    ax.scatter(*tuple(sites_cart.T))
    ax.set_aspect('equal')
    fig.tight_layout()
    plt.show()


r3 = np.sqrt(3)
latt = np.array([[r3,0],[-r3/2,3/2]])
sites = np.array([[0,0],[2/3,1/3],[1/3,2/3]])
sites_cart = np.dot(sites,latt)

neigh_idx=np.zeros((3,2,3))
neigh_idx[0,0,2]=1
neigh_idx[0,1,2]=2
neigh_idx[1,1,2]=2
neigh_idx[2,1,2]=1

J1=10
SIA = 5
exch = exchange_shell(neigh_idx, J1, shell_name = '1NN')

