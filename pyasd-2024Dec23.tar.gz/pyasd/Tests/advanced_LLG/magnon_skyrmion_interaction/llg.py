#!/usr/bin/env python

import numpy as np
from asd.core.log_general import log_general
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.llg_advanced import *
from asd.core.spin_configurations import *
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *

def get_td_field(current_llg_time,x1,x2,B0,freq):
    my_field = np.zeros((nx,ny,nat,3))
    my_field[x1:x2,:,0,0] = B0*np.sin(2.*np.pi*current_llg_time*freq)
    return my_field


nx=40
ny=16
nz=1
lat_type='square'
latt,sites,neigh_idx,rotvecs = build_latt(lat_type,nx,ny,nz)
nat=sites.shape[-2]

S_values=np.array([1])
SIA=np.array([0.5])
J1=1
DM=0.6
J1_iso = np.ones(1)*J1
DM1_rpz = np.array([[DM,0,0]])
DM1_xyz = get_exchange_xyz(DM1_rpz,rotvecs[0])

freq=0.05  # in THz
B0=2
nstep=50000
dt=5e-3
idir=1

exch_1 = exchange_shell( neigh_idx[0], J1_iso, DM_xyz = DM1_xyz, shell_name = '1NN')
radius=4

bound=3
site_alpha=np.ones((nx,ny,nat))*0.1
site_alpha[:bound] =1
site_alpha[-bound:]=1
#map_alpha(np.dot(sites,latt),site_alpha,latt=latt)

log_handle = log_general(
n_log_conf=500,
n_log_magn=500,
log_topo_chg=True,
)


kws=dict(
nstep=nstep,
dt=dt,
alpha=site_alpha,
td_regional_field=get_td_field,
td_field_args=(x1,x2,B0,freq),
conv_ener=1e-12,
temperature=0,
latt=latt,
sites=sites,
log_handles = log_handles,
)

LLG = llg_solver_adv(**kws)

ham = spin_hamiltonian(
S_values=S_values,
BL_SIA=[SIA],
BL_exch=[exch_1],
boundary_condition=[0,1,0],
)


if __name__=='__main__':
    sp_lat = np.zeros((nx,ny,nat,3))
    sp_lat = init_spin_latt_skyrmion(sp_lat,latt,sites,radius,helicity=1,pos=[0,0,0],display=False)
    log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
