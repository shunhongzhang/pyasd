#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from asd.utility.spin_visualize_tools import *
from llg import *

params,spins = parse_ovf('spin_confs.ovf')
confs = np.swapaxes(spins.reshape(spins.shape[0],ny,nx,nat,3),1,2)

data=np.loadtxt('M.dat')
time = data[:,0]
ener = data[:,1]
diff_E = data[:,2]

dirs={0:'x',1:'y',2:'z'}
fig,ax=plt.subplots(1,1)
for i in [0,1]:
    for j in [0,2]:
        lab = 'site {}: n{}'.format(i,dirs[j])
        ax.plot(time,confs[:,i,0,0,j],label=lab)
ax.legend()
ax.set_xlabel('time (ps)')

fig,ax=plt.subplots(1,1)
ax.plot(time,ener)
ax.set_xlabel('time (ps)')
ax.set_ylabel('E (eV)')
plt.show()
