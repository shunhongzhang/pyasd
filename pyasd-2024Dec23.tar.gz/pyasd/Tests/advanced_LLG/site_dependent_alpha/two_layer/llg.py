#!/usr/bin/env python

import numpy as np
from asd.utility.spin_visualize_tools import *
from asd.core.geometry import build_latt
from asd.core.shell_exchange import *
from asd.core.hamiltonian import spin_hamiltonian
from asd.core.spin_configurations import *
from asd.core.llg_advanced import llg_solver_adv
import os
import asd.mpi.mpi_tools as mt

nx=3
ny=2
nz=1
nlayer=2

latt = np.array([[1,0,0],[0,1,0],[0,0,1]])
sites = np.array([[0.5,0.5,i/8.] for i in range(nlayer)])

neigh_idx = []
neigh_idx.append( np.zeros((nlayer,4,4),int) )

for i in range(nlayer): neigh_idx[0][i,:,-1]=i
neigh_idx[0][:,0,0] = 1
neigh_idx[0][:,1,0] = -1
neigh_idx[0][:,2,1] = 1
neigh_idx[0][:,3,1] = -1

neigh_idx.append( np.zeros((nlayer,1,4),int) )
for i in range(nlayer):
    neigh_idx[1][i,0,-1]=(i-1)%nlayer
neigh_idx[1][ 0,0,2] = -1


neigh_idx.append( np.zeros((nlayer,1,4),int) )
for i in range(nlayer):
    neigh_idx[2][i,0,-1]=(i+1)%nlayer
neigh_idx[2][-1,0,2] = 1


nat = sites.shape[-2]
ndim=3
xx,yy,zz=np.mgrid[0:nx,0:ny,0:1]
sites_sc = np.zeros((nx,ny,nz,nat,ndim),float)
for iat in range(nat):
    sites_sc[...,iat,0] = sites[...,iat,0] + xx
    sites_sc[...,iat,1] = sites[...,iat,1] + yy

sites = sites_sc

J1_iso = np.ones(2)*0.1
exch_1 = exchange_shell(neigh_idx[0],J1_iso,shell_name='1NN: in-plane')

J2_iso = np.ones(2)*0.01
exch_2 = exchange_shell(neigh_idx[1],J2_iso,shell_name='1NN: interlayer')

#J3_iso = np.array([0.1,0.1,-0.5,0.])
#exch_3 = exchange_shell(neigh_idx[2],J3_iso,shell_name='1NN: out-of-plane - 2')


Bfield=np.array([0,0,1])
S_values = np.ones(2)
SIA=np.ones(2)*0.1
SIA_axis = np.array([0,0,1])

ham = spin_hamiltonian(H,S_values,BL_SIA=[SIA],SIA_axis=SIA_axis,
boundary_condition=[1,1,0],
BL_exch=[exch_1,exch_2],
iso_only=True)

nloop=5

H_list = np.arange(2,-2.1,-0.05)
H_list = np.append(H_list,H_list[::-1][1:])
H_list = np.append(H_list,np.tile(H_list[1:],(nloop-1,1)).flatten())

outdir_ovf='ovfs'
outdir_dat='dats'


if __name__=='__main__':
    comm,size,rank,node = mt.get_mpi_handles()

    if not rank:
        for dd in [outdir_ovf,outdir_dat]:
            if os.path.isdir(dd): os.system('rm -r {}'.format(dd))
            os.mkdir(dd)

    sp_lat = np.zeros((nx,ny,nz,nat,3),float)
    comm,size,rank,node = mt.get_mpi_handles()
    #if not rank: sp_lat = init_random(sp_lat)
    #sp_lat = comm.bcast(sp_lat)
    sp_lat[...,2] = -1.

    alpha = np.zeros((nx,ny,nz,nat),float)
    alpha[...,0]=0.5
    alpha[...,1]=0.005

    for iH,Hz in enumerate(H_list):
        H = np.array([0,0,Hz])

        ham = spin_hamiltonian(H,S_values,BL_SIA=[SIA],SIA_axis=SIA_axis,
        boundary_condition=[1,1,0],
        BL_exch=[exch_1,exch_2],
        iso_only=True)

        LLG = llg_solver_adv(alpha=alpha,
        S_values=S_values,
        nstep=10000,
        dt=5e-2,
        n_log_conf=1000,
        n_log_magn=1000,
        prefix='EB',
        log_conf_file='{}/H_{}_S.ovf'.format(outdir_ovf,iH),
        archive_file='{}/H_{}_M.dat'.format(outdir_dat,iH),
        temperature=0.5)

        log_time,log_ener,log_conf = LLG.mpi_llg_simulation(ham,sp_lat)
        sp_lat = log_conf[-1]
