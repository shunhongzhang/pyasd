#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from asd.utility.spin_visualize_tools import *
from llg import *

iH=0
H = H_list[iH]
fil_ovf = 'ovfs/H_{}_S.ovf'.format(iH)
fil_dat = 'dats/H_{}_M.dat'.format(iH)

params,spins = parse_ovf(fil_ovf)
nconf = spins.shape[0]
confs = spins.reshape(nconf,nz,ny,nx,nat,3)
confs = np.transpose(confs,(0,3,2,1,4,5))

data=np.loadtxt(fil_dat)
time = data[:,0]
ener = data[:,1]
diff_E = data[:,2]

dirs={0:'x',1:'y',2:'z'}
fig,ax=plt.subplots(1,1)
for i in [0,1]:
    for idir in [0,2]:
        lab = 'site {}: n{}'.format(i,dirs[idir])
        mm = np.average(confs[:,:,:,:,i,idir],axis=(1,2,3))
        ax.plot(time,mm,label=lab)
ax.legend()
ax.set_xlabel('time (ps)')
if iH==0: sign=''
else: sign = {1:r'$\uparrow$',-1:r'$\downarrow$',0:''}[np.sign(H_list[iH]-H_list[iH-1])]
ax.set_title('H={:4.1f} T {}'.format(H,sign))

nH=len(H_list)
mm=np.zeros(nH)
for iH in range(nH):
    fil_ovf = 'ovfs/H_{}_S.ovf'.format(iH)

    params,spins = parse_ovf(fil_ovf)
    nconf = spins.shape[0]
    confs = spins.reshape(nconf,nz,ny,nx,nat,3)
    confs = np.transpose(confs,(0,3,2,1,4,5))
    mm[iH] = np.average(confs[-1,:,:,:,1,2])

fig,ax=plt.subplots(1,1)
ax.scatter(H_list[:nH],mm,c=range(nH),cmap='jet')
ax.plot(H_list[:nH],mm,zorder=-1,lw=0.5)
plt.show()
