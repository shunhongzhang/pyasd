#!/usr/bin/env python

from asd.data_base.rectangular_cell_U4 import *
from asd.core.llg_advanced import *
from asd.core.spin_configurations import *
import numpy as np
import matplotlib.pyplot as plt
import asd.mpi.mpi_tools as mt

ham = build_ham(nshell_bl=2)
nx=4
ny=3
nz=1
latt,sites,neigh_idx = rectangular_honeycomb_cell(nx,ny,nz)
nat=sites.shape[-2]

freq=0.5 # in THz
B0=2     # in T
nstep=5000
dt=5e-3
x1=25
x2=26
llg_time = np.arange(0,dt*(nstep+1),dt)
my_field = np.zeros((nstep+1,nx,ny,nat,3))
for it in range(nstep+1): 
    my_field[it,:,:,:,2] = B0*np.sin(2.*np.pi*llg_time[it]*freq)


kws=dict(nstep=nstep,dt=dt,
alpha=0.3,
td_regional_field=my_field,
n_log_conf=200,
n_log_magn=200,
conv_ener=1e-12)

LLG = llg_solver_adv(**kws)

if __name__=='__main__':
    sp_lat = np.zeros((nx,ny,nat,3))
    sp_lat[...,0] = 1.
    LLG.mpi_llg_simulation(ham,sp_lat)
