#!/usr/bin/env python

from llg import *
import numpy as np
import matplotlib.pyplot as plt

dirs={0:'x',1:'y',2:'z'}

def map_S_component(confs,llg_time,idir=0):
    fig,ax=plt.subplots(1,1)
    kwargs=dict(origin='lower',cmap='bwr',
    extent=[0,nx,0,np.max(llg_time)],aspect='auto')
    im = ax.imshow(confs[:,:,0,0,idir],**kwargs)
    ax.set_ylabel('t (ps)')
    ax.set_xlabel('x position')
    cbar=fig.colorbar(im,shrink=0.5)
    cbar.ax.set_title('$S_{}$'.format(dirs[idir]))
    fig.tight_layout()
    plt.show()


def anim_S_component(confs,titles,idir=0):
    from matplotlib.animation import FuncAnimation, PillowWriter

    def update(i,ln,tl,confs,titles,idir):
        ln.set_data(range(nx),confs[i,:,0,0,idir])
        tl.set_text(titles[i])
        
    fig,ax=plt.subplots(1,1)
    ln, = ax.plot(range(nx),confs[0,:,0,0,0])
    tl = ax.set_title('$S_x$ at {}'.format(titles[0]))
    ax.set_xlabel('x position')
    ax.set_ylabel('$S_{}$'.format(dirs[idir]))
    ax.set_ylim(-0.5,0.5)
    ax.axhline(0,ls='--',alpha=0.5)
    if abs(x1-x2)<=1: ax.axvline(x1,ls='--',alpha=0.5)
    else: ax.fill_between([x1-0.5,x2-0.5],*tuple(ax.get_ylim()),alpha=0.5,facecolor='g')
    ax.fill_between([0,bound],*tuple(ax.get_ylim()),alpha=0.5,facecolor='b')
    ax.fill_between([nx-bound,nx-1],*tuple(ax.get_ylim()),alpha=0.5,facecolor='b')
    fig.tight_layout()
    anim = FuncAnimation(fig, update, frames=range(len(confs)), interval=1e3, 
    repeat=False, fargs=[ln, tl, confs, titles, idir])

    plt.show()

def anim_confs(sites,latt,confs,titles,repeat_y=8):
    sites=get_repeated_sites(sites,1,repeat_y)
    confs=get_repeated_conf(confs,repeat_y,1)
    sites_cart = np.dot(sites,latt)
    superlatt=np.dot([[nx,0],[0,ny*repeat_y]],latt)
    quiver_kws.update(width=0.1,scale=0.4)
    print (confs.shape)
    kwargs=dict(colorbar_shrink=0.5,colorbar_orientation='horizontal',
    color_mapping='Sz',
    quiver_kws=quiver_kws,
    scatter_size=10,superlatt=superlatt,
    savegif=False,
    gif_dpi=100)
    make_ani(sites_cart,confs,titles=titles,**kwargs)


spins=parse_ovf('spin_confs.ovf')[1]
confs = np.swapaxes(spins.reshape(-1,ny,nx,nat,3),1,2)
data = np.loadtxt('M.dat')
llg_time = data[:,0]
titles=['t = {:6.2f} ps'.format(tt) for tt in llg_time]

if __name__=='__main__':
    #map_S_component(confs,llg_time)
    anim_S_component(confs,titles,idir=1)
    #anim_confs(sites,latt,confs,titles)
