#!/usr/bin/env python

from asd.core.shell_exchange import *
from asd.core.geometry   import *
from asd.core.hamiltonian import *
from asd.core.log_general import log_general
from asd.core.llg_advanced import *
from asd.core.spin_configurations import *
import numpy as np
import matplotlib.pyplot as plt
import asd.mpi.mpi_tools as mt


def get_td_field(current_llg_time,x1,x2,B0,freq):
    my_field = np.zeros((nx,ny,nat,3))
    my_field[x1:x2,:,0,0] = B0*np.sin(2.*np.pi*current_llg_time*freq)
    return my_field


nx=36
ny=1
latt,sites,neigh_idx,rotvecs = build_latt('square',nx,ny,1)
nat=sites.shape[-2]

S_values = np.array([1./2])
SIA = np.zeros(1)
J1_iso = np.ones(1)

DM = 0.5
DM1_rpz = np.array([[DM,0,0]])
DM1_xyz = get_exchange_xyz(DM1_rpz,rotvecs[0])

exch_1 = exchange_shell(neigh_idx[0], J1_iso, 
DM_xyz = DM1_xyz,
shell_name = '1NN')

ham = spin_hamiltonian(S_values=S_values,
BL_exch=[exch_1],iso_only=True,
boundary_condition=[0,1,0])

freq=0.5 # in THz
B0=2     # in T
nstep=5000
dt=5e-4
x1=17
x2=19

bound=3
site_alpha=np.ones((nx,ny,nat))*0.01
site_alpha[:bound] =1
site_alpha[-bound:]=1

log_handle = log_general(
n_log_conf=200,
n_log_magn=200,
)

kws=dict(
S_values = S_values,
nstep=nstep,
dt=dt,
alpha=site_alpha,
td_regional_field=get_td_field,
td_field_args = (x1,x2,B0,freq),
conv_ener=1e-12,
include_td_field_energy=True,
log_handle = log_handle)

LLG = llg_solver_adv(**kws)

if __name__=='__main__':
    sp_lat = np.zeros((nx,ny,1,3))
    sp_lat[...,2] = 1.
    LLG.mpi_llg_simulation(ham,sp_lat)
