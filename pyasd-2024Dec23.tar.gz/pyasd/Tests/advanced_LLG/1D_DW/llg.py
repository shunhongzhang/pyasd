#!/usr/bin/env python

# Phys. Rev. Lett. 122, 147202 (2019)
# See supplementary material for parameters
#
# lattice constant a = 2 nm
# wire length L = 8e-6 m = 8000 nm
# 4000 cells
#
# A = 13 pJ/m
# K = 47 kJ/m^3
# Ms = 800 kA/m = 800 kJ/T/m^3
# muB = 9.274e-24 J/T
# Ms = 8e5/9.274e-24/(1e9**3) = 86.3 muB/nm^3

from asd.core.shell_exchange import *
from asd.core.log_general import log_general
from asd.core.geometry   import *
from asd.core.hamiltonian import *
from asd.core.llg_advanced import *
from asd.core.spin_configurations import *
import numpy as np
import matplotlib.pyplot as plt
import asd.mpi.mpi_tools as mt

def get_td_field(current_llg_time,x1,x2,B0,freq):
    my_field = np.zeros((nx,ny,nat,3))
    my_field[x1:x2,:,0,0] = B0*np.sin(2.*np.pi*current_llg_time*freq)
    return my_field


nx=36
ny=1
latt,sites,neigh_idx,rotvecs = build_latt('square',nx,ny,1)
nat=sites.shape[-2]

S_values = np.array([1./2])
Kx=0.3
SIA1 = np.array([Kx])
SIA1_axis = np.array([1,0,0])
Kz=-0.1
SIA2 = np.array([Kz])
SIA2_axis = np.array([0,0,1])

J1_iso = np.ones(1)
DM=np.array([0,0,1])*0.1
DM1_xyz = np.array([[DM,-DM]])

exch_1 = exchange_shell(neigh_idx[0][:,::2], J1_iso, DM_xyz=DM1_xyz, shell_name='1NN')

ham = spin_hamiltonian(S_values=S_values,
BL_SIA=[SIA1,SIA2],
BL_SIA_axis=[SIA1_axis,SIA2_axis],
BL_exch=[exch_1],
boundary_condition=[0,0,0])

freq=0.3 # in THz
B0=1
nstep=20000
dt=5e-3
x1=25
x2=26

bound=4
site_alpha=np.ones((nx,ny,nat))*0.1
for ix in range(bound):
    site_alpha[ix] *= bound - ix
    site_alpha[-ix-1] *= bound - ix

log_handle = log_general(
n_log_conf=200,
n_log_magn=200,
)

kws=dict(
S_values=S_values,
nstep=nstep,dt=dt,
alpha=site_alpha,
td_regional_field=get_td_field,
td_field_args=(x1,x2,B0,freq),
conv_ener=1e-12,
log_handle=log_handle)

LLG = llg_solver_adv(**kws)

if __name__=='__main__':
    nn=nx//2
    sp_lat = np.zeros((nx,ny,1,3))
    for ix in range(nx): 
        sp_lat[ix,...,0] = -np.tanh(ix-nn)
        sp_lat[ix,...,1] = 1./np.cosh(ix-nn)
    LLG.mpi_llg_simulation_advanced(ham,sp_lat)
