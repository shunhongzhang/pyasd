#!/usr/bin/env python

from asd.data_base.exchange_for_Cr2I3X3 import *

if __name__=='__main__':
    test_CrI3()
    test_Cr2I3Br3()
    test_Cr2I3Cl3()
