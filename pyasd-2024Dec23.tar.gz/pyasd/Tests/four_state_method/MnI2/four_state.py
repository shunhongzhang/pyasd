#!/usr/bin/env python

import numpy as np
from asd.core.hamiltonian import spin_hamiltonian
import matplotlib.pyplot as plt
from asd.data_base.exchange_for_MnI2 import *
from asd.utility.four_state_tools import *

filmom = 'magmom_1NN'
lines = open(filmom).readlines()
conf_names = [line.split('/')[0] for line in lines if line!='\n']
lines = [line.split('=')[1].split()[:-1] for line in lines if line!='\n']

angles_list = np.arange(0,91,10)*np.pi/180
moms = np.array([np.cos(angles_list),np.zeros_like(angles_list),np.sin(angles_list)]).T
magmom_MAE = np.array([[m,m] for m in moms]).reshape(10,6)

magmom_SIA = np.sign(np.array(lines[:4],float))
magmom_J1  = np.sign(np.array(lines,float))
#magmom_J2a = np.sign(np.array(lines[44:80],float))
#magmom_J2b = np.sign(np.array(lines[80:116],float))
#magmom_J3  = np.sign(np.array(lines[116:152],float))
#magmom_others_along_y = np.sign(np.array(lines[152:154],float))
#magmom_some_along_z = np.sign(np.array(lines[154:162],float))
#magmom_three_along_z = np.sign(np.array(lines[162:165],float))
#magmom_sublat = np.sign(np.array(lines[165:172],float))


block_line_Jmat =  np.arange(0,36,4)
xticks_Jmat =      xx = np.arange(36)+0.5
xticklabels_Jmat = ['{0}{1}'.format(*tuple(item)) for item in component]
xticklabels_SIA  = ['Cr']

fil='total_energy_1NN'
lines=[line.split()[3] for line in open(fil).readlines() if line!='\n']
print (len(lines))
en_dft = np.array(lines,float)*1e3
dirs_dft = [line.split('/')[0] for line in open(fil).readlines() if line!='\n']
print (en_dft.shape)

#fil='total_energy/total_energy_MAE.dat'
#lines=[line.split()[3] for line in open(fil).readlines() if line!='\n']
#en_dft_mae = np.array(lines,float)*1e3


ham = spin_hamiltonian(
S_values=S_values,
BL_SIA=[SIA],
BL_exch=[exch_1,exch_2],
exchange_in_matrix = True)
nat=sites.shape[-2]

sp_lat = np.zeros((1,1,nat,3))
en_ref = ham.verbose_reference_energy(sp_lat)
E_xFM = en_ref[0,0]
E_zFM = en_ref[2,0]

#test_one_set(ham,magmom_MAE, en_dft_mae,     'MAE')
#test_one_set(ham,magmom_SIA, en_dft[:4],     'SIA')
test_one_set(ham,magmom_J1,  en_dft,   'J1',  block_line = block_line_Jmat, nat=1)

plt.show()
