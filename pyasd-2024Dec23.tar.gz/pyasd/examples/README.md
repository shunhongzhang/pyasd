# Examples for pyasd
Some examples to demonstrate usage of the pyasd package

copyright 2023 @ Shunhong Zhang

# example1. single spin in magnetic field

# example2. Ising ferromagnet in square/honeycomb lattice

# example3. Ising antiferromagnet in square/honeycomb lattice

# example4. XY ferromagnet in square/honeycomb lattice

# example5. XY antiferromagnet in square/honeycomb lattice

