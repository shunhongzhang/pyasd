# example 4
Same as example 2 but with a honeycomb (bipartite) lattice
